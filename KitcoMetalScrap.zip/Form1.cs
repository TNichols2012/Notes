﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace KitcoMetalScrap
{
    public partial class Form1 : Form
    {
        // Target Web Site
        static string url = @"http://www.kitco.com";
        static Stream stream;
        public static string goldlast;

        public Form1()
        {
            InitializeComponent();

            // Call scraper routine
            ScrapeKitcoForGold();
        }

        public void ScrapeKitcoForGold()
        {
            string s;
            string[] s2;
            using (WebClient webclient = new WebClient())
            {
                try
                {
                    // Open URL - will NOT work from Client computer (I put this in \\usrcappsrvr01\SIMS\Tools\Scraper, remoted into usrcappsrvr01 and it worked fine).
                    stream = webclient.OpenRead(url);
                }
                catch (Exception e)
                {
                    string[] sError = e.ToString().Split('\n');
                    string sErrTxt = "Error connecting to " + url;
                    MessageBox.Show(sError[0], sErrTxt);
                    return;
                }

                // Use stream reader to find what you want 
                using (StreamReader sr = new StreamReader(stream))
                {
                    do
                    {
                        s = sr.ReadLine();
                    }
                    while (s.Contains("Bid/Ask") == false);

                    s = sr.ReadLine();
                    s = sr.ReadLine();
                    s = s.Trim();
                    s = s.Replace("</td>", "");
                    s2 = s.Split('>');
                    goldlast = s2[1];

                    // update text box on UI
                    GoldTextBox.Text = goldlast;
                }
            }
        }
    }
}
