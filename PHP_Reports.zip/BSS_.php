<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Developer')
//IF ($securitygroup=='Sales')
IF ($securitygroup=='BSS' || $securitygroup=='Developer' || $securitygroup=='Administrator')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Business Support Services Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');


	echo ('<center>WELCOME to the Business Support Services (BSS) Toolsite.</center><br/>');
	echo ('<table align="center">');

	echo ('<tr><th COLSPAN=2>Available Options</th></tr>');

	echo ('<tr><td></td><td><a href="./BSS_Call_History_Campaign.php">Ad Code History: 800 Number</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_DNIS.php">Call History: 800 Number</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales ID</td></tr>');	
	echo ('<tr><td></td><td><a href="./BSS_Inventory_Status_Request.php">Inventory Status Request</td></tr>');	
	echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_Roster.php">Media Report: IB Team Reviews</td></tr>');
	echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_Roster_CVR.php">Media Report: OB Team Reviews</td></tr>');		
	echo ('<tr><td></td><td><a href="./BSS_Search_Order_ID_Approval_Codes.php">Order Approval Codes</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Rollover_Exceptions.php">Rollover Exception Report</td></tr>');	
	echo ('<tr><td></td><td><a href="./BSS_Spiff_Report.php">Spiff Report Request</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Team_Roster_Active.php">Team Roster Manager</td></tr>');	
	echo ('<tr><td></td><td><a href="./SalesRep_UPS_Tracking_Summary.php">UPS Order Tracking (All)</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Verification_List.php">Verification Follow-Up List</td></tr>');

	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
