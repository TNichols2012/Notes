<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


IF ($login=='SSM' || $login=='ssm' || $securitygroup=='Executive' || $securitygroup=='BSS' || $securitygroup=='Sales' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Marketing')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB0_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";

if ($debug==1){
	if (! $DB1_Conn) {
		DIE ("Could not connect to ".$DB0_Host."
			<bphpr/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to ".$DB0_Host." Database. <br />";
	}
}



function Get_Call_History ($DB_Conn, $in_LB_Search, $debug)
	{
        $sp = mssql_init ( "dbo.usp_PHP_Call_History_DNIS_Ad_Code", $DB_Conn ); //init stored procedure  
	mssql_bind ( $sp, '@in_DNIS', $in_LB_Search, SQLVARCHAR, false, false, 25);

	mssql_select_db("Data_Warehouse",$DB_Conn); 

	mssql_free_result($result);
	$result=mssql_execute($sp);

	$numrows=mssql_num_rows($result);
	$_SESSION['List_Count']=$numrows;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result)) {
		$answer[$i][0]=$row[0];
		$answer[$i][1]=$row[1];
		$answer[$i][2]=$row[2];
		$answer[$i][3]=$row[3];
		$answer[$i][4]=$row[4];
		$answer[$i][5]=$row[5];

		$i=$i+1;
	    }
	} while (mssql_next_result($result));


	if ($numrows == 0) {
		$answer[0][0]='';
		$answer[0][1]='';
		$answer[0][2]='';
		$answer[0][3]='';
		$answer[0][4]='';
		$answer[0][5]='';
	}


	if ($debug==1){
		echo ('<br>In Get_Call_History<br>'); 
		echo ('<br>stored procedure: '.$sp);
		echo ('<br>results: '.$result);
		echo ('<br>numrows: '.$numrows);
		echo ('<br>Searching for: '.$in_LB_Search);
		echo ('<br>database connection: '.$DB_Conn);

		if (! $DB_Conn) {
			DIE ("<br>Could not connect to USRCREP02 Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to USRCREP02 Database. <br />";
		}

	}
	Return $answer; 
} 

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" bgcolor="');
	$tbl_bgcolor=Yellow;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}

?>

<html>

<head>

</head>
<title>USRCBR Business Support Services: Call History Report (Ad Code)</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_LB_Search"]='';
}

if ($debug==1){
	echo ('<br>local enter Date : '.$in_enter_date);
}

/***************MAIN CODE STARTS HERE ********************/


if ($_POST["in_LB_Search"]==''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Business Support Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Business Support Services: Ad Code History Report - 800 Number</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>800 Number (DNIS) Search:<br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></tr></form></table><br><br>');


	echo ('	<table align="center" class="sortable">	<tr>');
	format_tbl_header("DNIS Number", 150, center);
	format_tbl_header("Ad Code", 150, center);
	format_tbl_header("Campaign", 150, center);
	format_tbl_header("Ad Run Date", 150, center);
	format_tbl_header("City", 150, center);
	format_tbl_header("State", 150, center);

	echo ('</tr></table>');


} // end if ($_POST["in_LB_Search"]=='')
else {
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Business Support Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Business Support Services: Ad Code History Report - 800 Number</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>800 Number (DNIS) Search:<br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center" value="'.$_POST["in_LB_Search"].'"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></tr></form></table><br><br>');

	$list=get_Call_History($DB1_Conn, $_POST["in_LB_Search"], $debug);
	$_SESSION['List']=$list;
	$_SESSION['Search_ID']=$_POST["in_LB_Search"];


	echo ('	<table align="center" class="sortable">	<tr>');
	format_tbl_header("DNIS Number", 150, center);
	format_tbl_header("Ad Code", 150, center);
	format_tbl_header("Campaign", 150, center);
	format_tbl_header("Ad Run Date", 150, center);
	format_tbl_header("City", 150, center);
	format_tbl_header("State", 150, center);

	echo (' </tr><tr>');

	for ($i=0; $i<$_SESSION['List_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	


//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');


	//format_tbl_content($i+1, 50, center, $row_bgcolor);		//Index
	format_tbl_content($list[$i][0], 150, center, $row_bgcolor);	//Call Start Time
	format_tbl_content($list[$i][1], 150, center, $row_bgcolor);	//Sales Rep
	format_tbl_content($list[$i][2], 150, center, $row_bgcolor);	//Contact Number
	format_tbl_content($list[$i][3], 150, center, $row_bgcolor);	//Call_Type
	format_tbl_content($list[$i][4], 150, center, $row_bgcolor);	//DNIS
	format_tbl_content($list[$i][5], 150, center, $row_bgcolor);	//Campaign

	echo ('</tr><tr>');

	}

	echo ('</tr></table>');









} //end else: if ($_POST["in_LB_Search"]=='')

	If ($debug==1) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB0_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB0_UserName.'</b><br>');
			echo ('Database: <b>'.$DB0_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>



