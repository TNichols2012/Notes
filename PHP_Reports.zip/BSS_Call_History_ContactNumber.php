<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


IF ($login=='SSM' || $login=='ssm' || $securitygroup=='Vault Returns Manager' || $securitygroup=='Marketing' || $securitygroup=='BSS' || $securitygroup=='Sales' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Executive' || $securitygroup=='Sales_Managers' || $securitygroup=='Sales_Operations')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";

if ($debug==1){
	if (! $DB1_Conn) {
		DIE ("Could not connect to USRCREP02 Database. 
			<bphpr/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to USRCREP02 Database. <br />";
	}
}



function Get_Call_History ($DB_Conn, $in_LB_Search, $debug)
	{
        $sp = mssql_init ( "dbo.usp_PHP_Call_History_ContactNumber", $DB_Conn ); //init stored procedure  
	mssql_bind ( $sp, '@in_Contact_Number', $in_LB_Search, SQLVARCHAR, false, false, 25);

	mssql_select_db("Data_Warehouse",$DB_Conn); 

	mssql_free_result($result);
	$result=mssql_execute($sp);

//while ($row = mssql_fetch_assoc($result))
//    print_r($row); 


	$numrows=mssql_num_rows($result);
	$_SESSION['List_Count']=$numrows;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result)) {
		    
		    $answer[$i][0]=$row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1]=$row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2]=$row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3]=$row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4]=$row[4];
//		    print_r($answer[$i][4]);

	 	$answer[$i][5]=$row[5];
	 	$answer[$i][6]=$row[6];
	 	$answer[$i][7]=$row[7];
	 	$answer[$i][8]=$row[8];
	 	$answer[$i][9]=$row[9];
		$answer[$i][10]=$row[10];
		$answer[$i][11]=$row[11];
//		print_r($answer);
		//print_r($row[0]);
		$i=$i+1;
	    }
	} while (mssql_next_result($result));




/*
	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 'CallStartTime');//custnum
		$answer[$i][1]=mssql_result($result, $i, 'Sales_Rep');//notes
		$answer[$i][2]=mssql_result($result, $i, 2);//fullname
		$answer[$i][3]=mssql_result($result, $i, 3);//fullname		
		$answer[$i][4]=mssql_result($result, $i, 4);//fullname
		$answer[$i][5]=mssql_result($result, $i, 5);//fullname
		$answer[$i][6]=mssql_result($result, $i, 6);//fullname
		$answer[$i][7]=mssql_result($result, $i, 7);//fullname
		$answer[$i][8]=mssql_result($result, $i, 8);//fullname
		$answer[$i][9]=mssql_result($result, $i, 9);//fullname
		$answer[$i][10]=mssql_result($result, $i, 10);//fullname
	}
 */


	if ($numrows == 0) {
		$answer[0][0]='0';
		$answer[0][1]='No Loadbook Notes Found.';
		$answer[0][2]='No Customer Record Found.';
	}


	if ($debug==1){
		echo ('<br>In Get_Call_History<br>'); 
		echo ('<br>stored procedure: '.$sp);
		echo ('<br>results: '.$result);
		echo ('<br>numrows: '.$numrows);
		echo ('<br>Searching for: '.$in_LB_Search);
		echo ('<br>database connection: '.$DB_Conn);

		if (! $DB_Conn) {
			DIE ("<br>Could not connect to USRCREP02 Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to USRCREP02 Database. <br />";
		}

	}
	Return $answer; 
} 

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" bgcolor="');
	$tbl_bgcolor=Yellow;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}

?>

<html>

<head>

</head>
<title>USRCBR Business Support Services: Call History Report (Contact Number)</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_LB_Search"]='';
}

if ($debug==1){
	echo ('<br>local enter Date : '.$in_enter_date);
}

/***************MAIN CODE STARTS HERE ********************/


if ($_POST["in_LB_Search"]==''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Sales'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="SalesRep_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Sales_Managers'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_SalesManagers_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Sales_Operations'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_SalesOperations_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Business Support Services: Call History Report - Contact Number</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>Contact Number Search:<br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></tr></form></table><br><br>');


	echo ('	<table align="center" class="sortable">	<tr>');
	format_tbl_header("Call Start Time", 150, center);
	format_tbl_header("Sales Rep", 200, center);
	format_tbl_header("Contact Number", 125, center);
	format_tbl_header("Call Type", 75, center);
	format_tbl_header("800 Number?", 100, center);
	format_tbl_header("Campaign?", 250, center);
	format_tbl_header("Talk Time (secs)", 75, center);
	format_tbl_header("Disposition", 150, center);
	format_tbl_header("Voicemail?", 75, center);
	format_tbl_header("Cellphone?", 75, center);
	format_tbl_header("Cust ID/Full Name", 250, center);
	echo ('</tr></table>');


} // end if ($_POST["in_LB_Search"]=='')
else {
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Sales'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="SalesRep_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Sales_Managers'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_SalesManagers_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Sales_Operations'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_SalesOperations_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}


	echo ('	<h2 align=center>Business Support Services: Call History Report - Contact Number</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>Contact Number Search:<br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center" value="'.$_POST["in_LB_Search"].'"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></tr></form></table><br><br>');

	$list=get_Call_History($DB1_Conn, $_POST["in_LB_Search"], $debug);
	$_SESSION['List']=$list;
	$_SESSION['Search_ID']=$_POST["in_LB_Search"];


	echo ('	<table align="center" class="sortable">	<tr>');
	format_tbl_header("Call Start Time", 150, center);
	format_tbl_header("Sales Rep", 200, center);
	format_tbl_header("Contact Number", 125, center);
	format_tbl_header("Call Type", 75, center);
	format_tbl_header("800 Number?", 100, center);
	format_tbl_header("Campaign?", 250, center);
	format_tbl_header("Talk Time (secs)", 75, center);
	format_tbl_header("Disposition", 150, center);
	format_tbl_header("Voicemail?", 75, center);
	format_tbl_header("Cellphone?", 75, center);
	format_tbl_header("Cust ID/Full Name", 250, center);
	echo (' </tr><tr>');

	for ($i=0; $i<$_SESSION['List_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	


//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');


	//format_tbl_content($i+1, 50, center, $row_bgcolor);		//Index
	format_tbl_content($list[$i][0], 150, center, $row_bgcolor);	//Call Start Time
	format_tbl_content($list[$i][1], 200, center, $row_bgcolor);	//Sales Rep
	format_tbl_content($list[$i][2], 125, center, $row_bgcolor);	//Contact Number
	format_tbl_content($list[$i][3], 75, center, $row_bgcolor);	//Call_Type
	format_tbl_content($list[$i][4], 100, center, $row_bgcolor);	//DNIS
	format_tbl_content($list[$i][6], 250, center, $row_bgcolor);	//Campaign
	format_tbl_content($list[$i][7], 75, center, $row_bgcolor);	//Talk Time Seconds
	format_tbl_content($list[$i][8], 150, center, $row_bgcolor);	//Disposition
	format_tbl_content($list[$i][9], 75, center, $row_bgcolor);	//Voicemail
	format_tbl_content($list[$i][10], 75, center, $row_bgcolor);	//Cellphone
	format_tbl_content($list[$i][11], 250, center, $row_bgcolor);	//Fullname
	echo ('</tr><tr>');

	}

	echo ('</tr></table>');









} //end else: if ($_POST["in_LB_Search"]=='')

	If ($debug==1) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB2_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB2_UserName.'</b><br>');
			echo ('Database: <b>'.$DB2_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>



