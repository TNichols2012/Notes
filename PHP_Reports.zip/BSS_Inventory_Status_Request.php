<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


IF ($securitygroup=='BSS' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $login=='PLV' || $login=='plv' || $login=='RDL' || $login=='rdl' || $login=='HCE' || $login=='hce')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////


require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRC_SIMSSERVER
//$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB0_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";


function get_Current_Inventory ($DB_Conn, $debug) {
 
	$query="
		SELECT     
		Stock_Description, 
		Unit_Retail_Value, 
		Unit_Retail_Value_UK, 
		Stock_Count, 
		[Year], 
		ISNULL(Mint, '') AS Mint, 
		Denomination, 
		[Type], 
		Condition, 
		Grade, 
		Tier,
		GetDate() AS Report_Date
		FROM         vw_Daily_Current_Inventory
		ORDER BY Tier, Stock_Description	
		";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Inventory_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);// Stock Desc
		$answer[$i][1]=mssql_result($result, $i, 1);// Unit Retail Value
		$answer[$i][2]=mssql_result($result, $i, 2);// Unit Retail Value UK
		$answer[$i][3]=mssql_result($result, $i, 3);// Stock Count
		$answer[$i][4]=mssql_result($result, $i, 4);// Year
		$answer[$i][5]=mssql_result($result, $i, 5);// Mint
		$answer[$i][6]=mssql_result($result, $i, 6);// Denomination
		$answer[$i][7]=mssql_result($result, $i, 7);// Type
		$answer[$i][8]=mssql_result($result, $i, 8);// Condition
		$answer[$i][9]=mssql_result($result, $i, 9);// Grade
		$answer[$i][10]=mssql_result($result, $i, 10);// Top Pick
		$answer[$i][11]=mssql_result($result, $i, 11);// Grade
		

	}

	if ($debug==1){
		if (! $DB_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Current Inventory Query Looks Like:<br><b> '.$query.'</b><br>');
		echo ('<br>Manager count is: '.$numrows);
		echo ('<br>Session Count is: '.$_SESSION['Inventory_Count'.$room]);
		echo ('<br>');
	}
	Return $answer;
}; //end function get_Curent_Inventory ($DB_Conn, $debug) 


function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}; //end function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor)


function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}; //end function format_tbl_content($content, $width, $alignment="left", $row_bgcolor)

?>
<html>

<head>
<script type="text/javascript">
</script>


<script src="JS_Sort_Table.js"></script>

</head>

<title>USMR SIMS Inventory Report</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Send']){
	echo ('	<h1 align=center>US Money Reserve</h1>');

	if($securitygroup=='Business Support Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Inventory'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Inventory_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>SIMS Inventory</h2>');
	echo (' <h3 align="center"> Current as of  <i>'.date("l g:i:s  a, F jS, Y  ",time()).'</i> </h3>');


	//echo (' <table align="center"><tr><td valign="top">Report Request Sent</td></tr></table>');
	//$command = "c:\\EXEC_Inve_Status.bat";
	//$output = shell_exec("$command");

	echo ('	<table align="center" class="sortable">	<tr>');
	format_tbl_header("Row", 25, center, $hdr_bgcolor);
	format_tbl_header("Stock Description", 250, center, $hdr_bgcolor);
	format_tbl_header("Retail Value", 100, center, $hdr_bgcolor);
	format_tbl_header("Retail Value UK", 100, center, $hdr_bgcolor);
	format_tbl_header("Stock Count", 50, center, $hdr_bgcolor);
	format_tbl_header("Year", 50, center, $hdr_bgcolor);
	format_tbl_header("Mint", 50, center, $hdr_bgcolor);
	format_tbl_header("Denom", 50, center, $hdr_bgcolor);
	format_tbl_header("Type", 50, center, $hdr_bgcolor);
	format_tbl_header("Condition", 50, center, $hdr_bgcolor);
	format_tbl_header("Grade", 50, center, $hdr_bgcolor);
	format_tbl_header("Tier", 50, center, $hdr_bgcolor);	
	echo ('</tr><br>');

	$inventory=get_Current_Inventory ($DB1_Conn, $debug);

	for ($i=0; $i<$_SESSION['Inventory_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');

	format_tbl_content($i+1, 25, center, $row_bgcolor);		//Index
	format_tbl_content($inventory[$i][0], 250, center, $row_bgcolor);	//Stock Desc

//	format_tbl_content($inventory[$i][1], 100, center, $row_bgcolor);	//Unit Retail
	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">$'.$inventory[$i][1].'</td> ');
	
	format_tbl_content($inventory[$i][2], 100, center, $row_bgcolor);	//Unit Retail UK
	format_tbl_content($inventory[$i][3], 50, center, $row_bgcolor);	//Stock Count
	format_tbl_content($inventory[$i][4], 50, center, $row_bgcolor);	//Year
	format_tbl_content($inventory[$i][5], 75, center, $row_bgcolor);	//Mint
	format_tbl_content($inventory[$i][6], 75, center, $row_bgcolor);	//
	format_tbl_content($inventory[$i][7], 75, center, $row_bgcolor);	//Denomination
	format_tbl_content($inventory[$i][8], 150, center, $row_bgcolor);	//Type
	format_tbl_content($inventory[$i][9], 75, center, $row_bgcolor);	//Condition
	format_tbl_content($inventory[$i][10], 75, center, $row_bgcolor);	//Grade
	
	echo ('</tr><tr>');
	}

	echo ('</tr></table>');




}
else{
	echo ('	<h1 align=center>US Money Reserve</h1>');

	if($securitygroup=='Business Support Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Inventory'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Inventory_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>SIMS Inventory</h2>');
//	echo (' <h3 align="center"> Current as of: <i>'.date("m/d/y h:i:s",time()).'</i> </h3>');
	echo (' <h3 align="center"> Current as of  <i>'.date("l g:i:s  a, F jS, Y  ",time()).'</i> </h3>');
	
//	echo (' <table align="center"><tr><td valign="top">
//		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
//		</td><td valign="bottom" align="center">
//		<input type="submit" name="Send" value="Send Report" />
//		</td><td></td></tr></table><br>');
	
//	echo (' <table align="center"><tr><td valign="top">Report Request Sent</td></tr></table>');
//	$command = "c:\\EXEC_Inve_Status.bat";
//	$output = shell_exec("$command");


//	echo (' <table align="center"><tr><td valign="top">
//		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
//		</td><td valign="bottom" align="center">
//		</td><td></td></tr></table><br>');
	
	echo ('<div id="header">');
	echo ('	<table align="center" class="sortable">	<tr>');
	format_tbl_header("Row", 25, center, $hdr_bgcolor);
	format_tbl_header("Stock Description", 250, center, $hdr_bgcolor);
	format_tbl_header("Retail Value", 100, center, $hdr_bgcolor);
	format_tbl_header("Retail Value UK", 100, center, $hdr_bgcolor);
	format_tbl_header("Stock Count", 50, center, $hdr_bgcolor);
	format_tbl_header("Year", 50, center, $hdr_bgcolor);
	format_tbl_header("Mint", 50, center, $hdr_bgcolor);
	format_tbl_header("Denom", 50, center, $hdr_bgcolor);
	format_tbl_header("Type", 50, center, $hdr_bgcolor);
	format_tbl_header("Condition", 50, center, $hdr_bgcolor);
	format_tbl_header("Grade", 50, center, $hdr_bgcolor);
	format_tbl_header("Tier", 50, center, $hdr_bgcolor);
	echo ('</tr>');
	echo ('</div><div id="body1">');

	$inventory=get_Current_Inventory ($DB1_Conn, $debug);

	for ($i=0; $i<$_SESSION['Inventory_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');

	format_tbl_content($i+1, 25, center, $row_bgcolor);		//Index
	format_tbl_content($inventory[$i][0], 250, center, $row_bgcolor);	//Stock Desc

//	format_tbl_content($inventory[$i][1], 100, center, $row_bgcolor);	//Unit Retail
	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">$'.$inventory[$i][1].'</td> ');
	
	format_tbl_content($inventory[$i][2], 100, center, $row_bgcolor);	//Unit Retail UK
	format_tbl_content($inventory[$i][3], 50, center, $row_bgcolor);	//Stock Count
	format_tbl_content($inventory[$i][4], 50, center, $row_bgcolor);	//Year
	format_tbl_content($inventory[$i][5], 50, center, $row_bgcolor);	//Mint
	format_tbl_content($inventory[$i][6], 50, center, $row_bgcolor);	//Mint
	format_tbl_content($inventory[$i][7], 50, center, $row_bgcolor);	//Denomination
	format_tbl_content($inventory[$i][8], 50, center, $row_bgcolor);	//Type
	format_tbl_content($inventory[$i][9], 50, center, $row_bgcolor);	//Condition
	format_tbl_content($inventory[$i][10], 50, center, $row_bgcolor);	//Grade
	echo ('</tr><tr>');
	}

	echo ('</tr></table>');
	echo ('</div>');
	} // end if ($in_sales_manager==='')

?>

</html>

