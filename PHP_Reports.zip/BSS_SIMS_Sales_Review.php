<?php
session_start();

$debug=0;

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRC_SIMSSERVER
$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRC_FILESERVER

function get_Managers($DB1_Conn) {

	$query="SELECT Manager FROM [SIMS].dbo.LoginTable
		WHERE (Manager IS NOT NULL) 
		AND (Manager <> 'Johnpaul Durham')
		AND (SecurityLevel Like '%sales')
		GROUP BY Manager";

//		AND (SecurityLevel <> 'C3 Sales'

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Manager_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Manager
	}

	if ($debug==1){
		echo ('<br>Manager Query Looks Like:<br> '.$query);
		IF (! $DB2_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Connected Fine to Login Database. <br />";}
	}

	Return $answer;

};

function get_SalesRep($DB1_Conn, $manager) {

	if ($manager=='') {
		$in_Sales_Manager=" 1=1 ";
	}
	else {
		$in_Sales_Manager=" Manager='".$manager."'";
	}

	$query="SELECT RealName FROM [SIMS].dbo.LoginTable
		WHERE ( RealName IS NOT NULL ) 
		AND ( RealName LIKE '%(%)' ) 
		AND ( ".$in_Sales_Manager." ) 
		AND ( RealName NOT LIKE '%Austin%' )
		AND ( RealName NOT LIKE '%Beaumont%' )
		GROUP BY RealName";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['SalesRep_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Rep
	}

	if ($debug==1){
		echo ('<br>Sales Rep query Looks Like:<br> '.$query);
		echo ('<br>Result is : '.$result);
		echo ('<br>Numrows are: '.$numrows);
	}

	Return $answer;

}; // end function get_SalesRep()

function get_History($DB1_Conn, $in_Manager, $in_SalesRep, $in_DateEntered){

	if($in_SalesRep=='All Sales Reps'){
		$SQL_sales_rep=" 1=1 ";
	}
	else {
		$SQL_sales_rep=" TT.Username='".$in_SalesRep."'";
	}
	
	$query="SELECT 
		[DateTime], 
		ConfirmationCode, 
		TT.Username, 
		Recipient, 
		SUM(Retail * Quantity) AS Subtotal, 
		MOMOrderNumber, 
		MOMStatus 
		FROM [SIMS].dbo.TransactionTable TT
		INNER JOIN [SIMS].dbo.LoginTable LT
		ON TT.Username=LT.RealName
		WHERE ( ".$SQL_sales_rep." ) 
		AND ( LT.Manager='".$in_Manager."' )
		AND (Action = 'Acquired') 
		AND (Confirmed = 'True') 
		AND (Released = 'False') 
		AND ([DateTime] >= '".$in_DateEntered."')
		AND ([DateTime] < DateAdd(dd, 1, '".$in_DateEntered."'))
		AND (MOMStatus LIKE 'PCAP%' OR MOMStatus LIKE 'CK RECVD%' OR MOMStatus LIKE 'OP%')
		GROUP BY [DateTime], ConfirmationCode, TT.Username, Recipient, MOMOrderNumber, MOMStatus 
		ORDER BY TT.Username, [DateTime]";


	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['SalesRep_Order_Count']=$numrows;
	$_SESSION['SalesRep_Order_Total']=0;

	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result, $i, 0); //DateTime
		$answer[1][$i]=mssql_result($result, $i, 1); //Confirmation Code
		$answer[2][$i]=mssql_result($result, $i, 2); //Sales Rep
		$answer[3][$i]=mssql_result($result, $i, 3); //Customer
		$answer[4][$i]=mssql_result($result, $i, 4); //Order Value
		$answer[5][$i]=mssql_result($result, $i, 5); //MOM Order ID
		$answer[6][$i]=mssql_result($result, $i, 6); //MOM Order Status
		$_SESSION['SalesRep_Order_Total']=$_SESSION['SalesRep_Order_Total']+$answer[4][$i];
	}

	if ($debug==1){
		echo ('<br>Order query Looks Like:<br> '.$query);
		echo ('<br>Result is : '.$result);
		echo ('<br>Anwser is :'.$answer);
		echo ('<br>Numrows are: '.$numrows);
	}

	Return $answer;
};

function show_History($good_money){

	for($i=0;$i<$_SESSION['SalesRep_Order_Count'];$i+=1){
		echo ('<tr>');
		echo ('<td align="left">'.$good_money[0][$i].'</td>'); // DateTime
		echo ('<td>'.$good_money[1][$i].'</td>'); // Confirmation Code
		echo ('<td>'.$good_money[2][$i].'</td>'); // Sales Rep
		echo ('<td>'.$good_money[3][$i].'</td>'); // Customer
		echo ('<td align="right">$'.number_format($good_money[4][$i], 2).'</td>'); // Order Value
		echo ('<td>'.$good_money[5][$i].'</td>'); // MOM Order ID
		echo ('<td>'.$good_money[6][$i].'</td>'); // MOM Order Status
		echo ('</tr>');
	} // end for loop
}; // end function show_History()


?>
<html>

<head>
</head>

<title>USRCBR SIMS Sales Report</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_Manager"]="";
	$_POST["in_SalesRep"]="";
	$_POST["in_Enter_Date"]="";
	$_SESSION['$in_sales_manager']="";
	$_SESSION['$in_sales_rep']="";
	$_SESSION['$in_enter_date']="";
}

$in_sales_manager=htmlentities($_POST["in_Manager"]);
$in_sales_rep=htmlentities($_POST["in_SalesRep"]);
$in_enter_date=htmlentities($_POST["in_Enter_Date"]);

$_SESSION['$in_sales_manager']=$in_sales_manager;
$_SESSION['$in_sales_rep']=$in_sales_rep;
$_SESSION['$in_enter_date']=$in_enter_date;

if ($debug==1){
	echo ('<br>Posted Sales Manager : '.$_POST["in_Manager"]);
	echo ('<br>Posted Sales Rep : '.$_POST["in_SalesRep"]);
	echo ('<br>Posted enter date : '.$_POST["in_Enter_Date"]);
	echo ('<br>Session Sales Manager : '.$_SESSION['$in_sales_manager']);
	echo ('<br>Session Sales Rep : '.$_SESSION['$in_sales_rep']);
	echo ('<br>Session enter date : '.$_SESSION['$in_enter_date']);
	echo ('<br>local Sales Manager : '.$in_sales_manager);
	echo ('<br>local Sales Rep : '.$in_sales_rep);
	echo ('<br>local enter Date : '.$in_enter_date);
}

if ($_POST["in_Manager"]==''){
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Customer Service: SIMS Sales Review</h2>');

	$managers=get_Managers($DB1_Conn);
	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<label>Sales Manager:<br>
		<select name="in_Manager" onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>');

	for($i=0;$i<$_SESSION['Manager_Count'];$i+=1){
		echo ('<option value="'.$managers[$i].'">'.$managers[$i].'</option>  ');
	}
	echo ('	</td>');

	echo (' <td valign="top">
		<label>Sales Representative: <br>
		<select name="in_SalesRep" >
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		
		</option></td>');

	echo (' <td align="center" valign="top">
		<label>Enter Date: <br>
		<input type="text" style="text-align:center" name="in_Enter_Date" align="center"');
	echo ('	</td></tr>');
			
	echo (' <tr><td></td><td valign="bottom" align="center">
		<input type="submit" value="Show Me" />
		<input type="submit" name="Clear" value="Clear All" />
		</td><td align="center"><i>(MM/DD/YYYY)</i></td>
		</tr></form></table><br><br>');

} // end if ($in_sales_manager==='')
else {
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Customer Service: SIMS Sales Review</h2>');
	$managers=get_Managers($DB1_Conn);
	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<label>Sales Manager:<br>
		<select name="in_Manager" onChange="submit()">
		<option>'.$_SESSION['$in_sales_manager'].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>');

	for($i=0;$i<$_SESSION['Manager_Count'];$i+=1){
		echo ('<option value="'.$managers[$i].'">'.$managers[$i].'</option>  ');
	}
	echo ('	</td>');

	$sales_reps=get_SalesRep($DB1_Conn, $_SESSION['$in_sales_manager']);
	echo (' <td valign="top">
		<label>Sales Representative: <br>
		<select name="in_SalesRep" onChange="submit()">
		<option>'.$_SESSION['$in_sales_rep'].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option><option value="All Sales Reps">All Sales Reps</option>');
		
	for($i=0;$i<$_SESSION['SalesRep_Count'];$i+=1){
		echo ('<option value="'.$sales_reps[$i].'">'.$sales_reps[$i].'</option>  ');
	}
			
			echo ('	</td>');

	echo (' <td align="center" valign="top">
		<label>Enter Date: <br>
		<input type="text" style="text-align:center" 
		align="center" name="in_Enter_Date" value="'.$_SESSION['$in_enter_date'].'" >');
	echo ('	</td></tr>');

	echo (' <tr><td></td><td valign="top" align="center">
		<input type="submit" value="Show Me" />
		<input type="submit" name="Clear" value="Clear All" />
		</td><td valign="top" align="center"><i>( MM/DD/YYYY )</i></td>
		</tr></form></table><br>');

	if ($_POST["in_Enter_Date"]<>''){
	
		if(isDate($_POST["in_Enter_Date"])){
			
			if($debug==1){
				echo ('<br>Valid Date<br><br>');
			}

			$good_money=get_History($DB1_Conn, $_POST['in_Manager'], $_POST['in_SalesRep'], $_POST["in_Enter_Date"]);
			echo ('<h3 align="center">'.$_SESSION['SalesRep_Order_Count'].' Total Orders,');
			echo (' $'.number_format($_SESSION['SalesRep_Order_Total'], 2).' Total Value</h3>');
			echo ('<table border =1  align="center">');
			echo ('<tr><td align="center">Order Date</td>');
			echo ('<td align="center">Confirmation Code</td>');
			echo ('<td align="center">Sales Rep</td>');
			echo ('<td align="center">Customer</td>');
			echo ('<td align="center">Order Value</td>');
			echo ('<td align="center">MOM Order ID</td>');
			echo ('<td align="center">MOM Order Status</td></tr>');
			show_History($good_money);
			echo ('</table>');
		}
		else {
			echo ('<h3 align="center">INVALID DATE ENTERED. Please re-enter a valid date.</h3><br>');
		}  // end else:	if ($_POST["in_Enter_Date"]<>'')
	
	} // end if ($_POST["in_Enter_Date"]<>'')

} //end else: if ($in_sales_manager==='')


	If ($debug==1) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB1_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB1_UserName.'</b><br>');
			echo ('Database: <b>'.$DB1_Database.'</b><br>');
			echo ('Manager is: <b>'.$managers.'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>
