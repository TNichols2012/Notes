<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Vault Returns Manager')
//IF ($securitygroup=='Administration')
IF ($securitygroup=='Executive' || $securitygroup=='Administrator' || $securitygroup=='Developer' || $login=='SDK' || $login=='sdk')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}
/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB3_Conn = mssql_connect ( $DB5_Host, $DB5_UserName, $DB5_Password, TRUE ); //connect to USRC_AMCATSQL
mssql_select_db ( $DB5_Database, $DB5_Conn );


define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";


if ($debug==1){
	if (! $DB3_Conn) {
		DIE ("Could not connect to USRCAPPSRVR01 Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to USRCAPPSRVR01 Database. <br />";
	}
}

function get_Loadbook($DB_Conn, $Lookup, $debug) {
	 
	$query="SELECT
		Custnum,
		FirstName,
		LastName,
		Gross,
		Sales_ID,
		Act_Date
		FROM [Cust]
		WHERE Sales_ID ='".$Lookup."' 
		ORDER BY Gross DESC";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Loadbook_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result, $i, 0);// Cust_ID
		$answer[1][$i]=mssql_result($result, $i, 1);// First_Name
		$answer[2][$i]=mssql_result($result, $i, 2);// Last_Name
		$answer[3][$i]=mssql_result($result, $i, 3);// Gross
		$answer[4][$i]=mssql_result($result, $i, 4);// Sales ID
		$answer[5][$i]=mssql_result($result, $i, 5);// Activity
	}

	if ($debug==1){
		if (! $DB_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Query Looks Like:<br> '.$query);
		echo ('<br>Manager count is: '.$numrows);
		echo ('<br>Session Count is: '.$_SESSION['Roster_Count_'.$room]);

		echo ('<br>');
	}
	Return $answer;
}; //end function get_Loadbook($DB_Conn, $Loadbook, $debug)


function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" bgcolor="'.Yellow.'"');
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}




?>

<html>

<head>

<script type="text/javascript">
	function show_notes(Index_ID){
	<!--
	str_redirect1='./VaultMgmt_Search_Loadbook_Update.php?$orig_index='+Index_ID
	window.open (str_redirect1, 'Notes_Window_'+Index_ID, config='height=800, width=800, toolbar=yes, menubar=yes, scrollbars=yes, resizable=yes, location=yes, directories=no, status=no')
	-->
	}


</script>

<script src="JS_Sort_Table.js"></script>

</head>
<title>USRCBR Loadbook Search Tool</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_LB_Search"]='';
}

if ($debug==1){
	echo ('<br>local enter Date : '.$in_enter_date);
}

 

/***************MAIN CODE STARTS HERE ********************/


if ($_POST["in_LB_Search"]==''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Business Support Services: Loadbook Search</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>Loadbook Search: <br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></form></table><br><br>');

echo ('	<div id="header">
	<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Cust ID", 75, center, $hdr_bgcolor);
	format_tbl_header("First Name", 200, center, $hdr_bgcolor);
	format_tbl_header("Last Name", 200, center, $hdr_bgcolor);
	format_tbl_header("Gross", 100, center, $hdr_bgcolor);
	format_tbl_header("Sales ID", 75, center, $hdr_bgcolor);
	format_tbl_header("Activity Date", 150, center, $hdr_bgcolor);
	echo ('</tr></div><div ID="body1">');

	echo ('</table></div>');	





} // end if ($_POST["in_LB_Search"]=='')
else {
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	
	echo ('	<h2 align=center>Business Support Services: Loadbook Search</h2>');

	echo (' <table align="center"><tr><td align="center" valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<label>Loadbook Search: <br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center" value="'.$_POST["in_LB_Search"].'"><br/>
		<input type="submit" name="Search" value="Search" /></td>');
	echo ('	</tr></form></table><br><br>');

/*
	echo ('<table align="center" class="sortable" width=100><tr>');
//	format_tbl_header("Index", 50, center);
	format_tbl_header("Customer ID", 100, center);
//	format_tbl_header("Notes", 450, center);

	echo ('</tr>');

	$list=get_Loadbook($DB3_Conn, $_POST["in_LB_Search"], $debug);
	$_SESSION['Notes_List']=$list;

	for ($i=0; $i<$_SESSION['List_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}



	echo ('<tr onClick="show_notes('.($i).')">');
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index
	format_tbl_content($list[0][$i], 100, center, $row_bgcolor);	//Cust_ID
//	format_tbl_content($list[1][$i], 450, left, $row_bgcolor);	//Cust_ID

	echo ('</tr>');
	}

	echo ('	</table>');
 */


echo ('	<div id="header">
	<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Cust ID", 75, center, $hdr_bgcolor);
	format_tbl_header("First Name", 200, center, $hdr_bgcolor);
	format_tbl_header("Last Name", 200, center, $hdr_bgcolor);
	format_tbl_header("Gross", 100, center, $hdr_bgcolor);
	format_tbl_header("Sales ID", 75, center, $hdr_bgcolor);
	format_tbl_header("Activity Date", 150, center, $hdr_bgcolor);
	echo ('</tr></div><div ID="body1">');


	$list=get_Loadbook($DB3_Conn, $_POST["in_LB_Search"], $debug);
	$_SESSION['Notes_List']=$list;

	for ($i=0; $i<$_SESSION['Loadbook_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}


	//	echo ('<tr onClick="show_detail('.($i).')">');		
	echo ('<tr>');	
	format_tbl_content($i+1, 50, center, $row_bgcolor);		//Index	
	format_tbl_content($list[0][$i], 75, center, $row_bgcolor);	//Cust ID
	format_tbl_content($list[1][$i], 200, center, $row_bgcolor);	//First Name
	format_tbl_content($list[2][$i], 200, center, $row_bgcolor);	//Last Name
	format_tbl_content($list[3][$i], 100, center, $row_bgcolor);	//Gross
	format_tbl_content($list[4][$i], 75, center, $row_bgcolor);	//Sales ID
	format_tbl_content($list[5][$i], 150, center, $row_bgcolor);	//Activity Date

	echo ('</tr>');
	}	
	echo ('</table></div>');	







} //end else: if ($_POST["in_LB_Search"]=='')

	If ($debug==1) {
		IF (! $DB3_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB3_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB3_UserName.'</b><br>');
			echo ('Database: <b>'.$DB3_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>



