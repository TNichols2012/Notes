<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


IF ($securitygroup=='BSS' || $securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB5_Host, $DB5_UserName, $DB5_Password, TRUE ); //connect to USRC_SIMSSERVER
//$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB5_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";


function get_Pending_Summary ($DB_Conn, $debug) {
	$query="
		WITH cte_PS AS 
		(
		SELECT     TOP (100) PERCENT 
		CONVERT(date, CMS.ODR_DATE) AS Order_Date, 
		CMS.ORDERNO AS Order_ID, 
		Stock.Number AS Stock_ID, 
		Stock.DESC1 Stock_Desc1, 
		Items.QUANTO AS Quantity_Ordered, 
		'$' + CONVERT(varchar(25), (CONVERT(money, ISNULL((Items.IT_UNLIST * Items.QUANTO), 0.00))), 1) AS Value_Ordered,
		CMS.Sales_ID
		FROM         CMS 
		LEFT OUTER JOIN CMS_Status 
		ON CMS.ORDER_ST2 = CMS_Status.Status_Code 
		LEFT OUTER JOIN Items_Status 
		RIGHT OUTER JOIN Items 
		ON Items_Status.Status_Code = Items.Item_State 
		ON CMS.Orderno = Items.Orderno
		LEFT OUTER JOIN Stock 
		ON Items.ITEM = Stock.NUMBER
		WHERE     (Items.ITEM <> '') 
		AND (CMS.OrderType <> 'CXL') 
		AND (Stock.NUMBER <> '') 
		AND (Items.Item_State = 'PS') 
		AND (CMS.ORDER_ST2 IN ('CA', 'PS'))
		ORDER BY CMS.Odr_Date DESC
		)
		
		SELECT 
		Stock_ID,
		SUM (Quantity_Ordered) AS Ttl
		FROM cte_PS
		GROUP BY 
		Stock_ID,
		Stock_Desc1
		ORDER BY Stock_ID
		";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Inventory_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);// Order Date
		$answer[$i][1]=mssql_result($result, $i, 1);// Order ID
	}

	if ($debug==1){
		if (! $DB_Conn) {
			DIE ("Could not connect to Data Warehouse Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Data Warehouse Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Current Inventory Query Looks Like:<br><b> '.$query.'</b><br>');
		echo ('<br>Manager count is: '.$numrows);
		
		echo ('<br>');
	}
	Return $answer;
}; //end function get_Curent_Inventory ($DB_Conn, $debug) 


function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}; //end function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor)


function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}; //end function format_tbl_content($content, $width, $alignment="left", $row_bgcolor)

?>
<html>

<head>
</head>

<title>USRCBR Spiff Report</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Send']){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='BSS'){
/*
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
*/
		header('Location: ./BSS_.php');
	}

	if($securitygroup=='Administrator'){
		/*
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
		 */
		header('Location: ./Administrator_.php');
	}
	if($securitygroup=='Developer'){
		/*
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
		 */
		header('Location: ./Developer_.php');
	}

	if($securitygroup=='Executive'){
		/*
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
		 */
		header('Location: ./Executive_.php');
	}

	if($securitygroup=='Inventory'){
		/*
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Inventory_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
		 */
		header('Location: ./Inventory_.php');
	}

	if($securitygroup=='Marketing'){
		/*
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
		 */
		header('Location: ./Marketing_.php');
	}

	if($securitygroup=='Vault Returns Manager'){
		/*
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
		 */
		header('Location: ./VaultMgmt_.php');
	}

	echo ('	<h2 align=center>Business Support Services: Spiff Report</h2>');

	echo (' <table align="center"><tr><td valign="top">Report Request Sent</td></tr></table>');

	$command = "c:\\EXEC_Spiff_Report.bat";
	$output = shell_exec("$command");

//	echo ('	<table align="center" class="sortable">	<tr>');
//	format_tbl_header("Index", 50, center, $hdr_bgcolor);
//	format_tbl_header("Stock Number", 300, center, $hdr_bgcolor);
//	format_tbl_header("Total", 100, center, $hdr_bgcolor);
	echo ('</tr>');

//	$inventory=get_Pending_Summary ($DB1_Conn, $debug);

//	for ($i=0; $i<$_SESSION['Inventory_Count']; $i+=1){
//		if ($i%2){
//			$row_bgcolor=LightGreen;
//		}
//		else {
//			$row_bgcolor=LightGrey;
//		}
	
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');

//	format_tbl_content($i+1, 50, center, $row_bgcolor);		//Index
//	format_tbl_content($inventory[$i][0], 300, left, $row_bgcolor);	//Order Date

//	format_tbl_content(number_format($inventory[$i][1]), 100, center, $row_bgcolor);	//Order ID
//	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">$'.$inventory[$i][1].'</td> ');

//	echo ('</tr><tr>');

//}
//	echo ('</tr></table>');




}
else{
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Inventory'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Inventory_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Business Support Services: Spiff Report</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		</td><td valign="bottom" align="center">
		<input type="submit" name="Send" value="Send Report" />
		</td><td></td></tr></table><br>');

	echo (' <h3 align=center>Request will take a few seconds to complete.</h3>');
/*
	echo ('	<table align="center" class="sortable">	<tr>');
	
	//format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Stock Number", 300, center, $hdr_bgcolor);
	format_tbl_header("Total", 100, center, $hdr_bgcolor);
	echo ('</tr>');

	$inventory=get_Pending_Summary ($DB1_Conn, $debug);

	for ($i=0; $i<$_SESSION['Inventory_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');

//	format_tbl_content($i+1, 50, center, $row_bgcolor);		//Index
	format_tbl_content($inventory[$i][0], 300, left, $row_bgcolor);	//Order Date

	format_tbl_content(number_format($inventory[$i][1]), 100, center, $row_bgcolor);	//Order ID
//	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">$'.$inventory[$i][1].'</td> ');
	

	echo ('</tr><tr>');
	}

	echo ('</tr></table>');
 */
	} // end if ($in_sales_manager==='')

?>

</html>
