<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='BSS' || $securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator') //OR IF ($securitygroup=='Developer') 
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}

/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////
require ('DB_Login.php');
require ('PHP_Functions.php');


$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRC_SIMSSERVER
$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02

IF ($debug==2){
	IF (! $DB1_Conn) {
		DIE ("Could not connect to USRC_SIMSSERVER Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to USRC_SIMSSERVER Database. <br />";}
	IF (! $DB2_Conn) {
		DIE ("Could not connect to USRCREP02 Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to USRCREP02 Database. <br />";}

}

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
define("Green", "00CC33");
$hdr_bgcolor="Yellow";

function get_Team_Rosters($DB_Conn, $room, $debug) {

	if ($room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" Site='".$room."'";
	};
	 
	$query="SELECT
		[PKUsers],
		[Name],
		[Login],
		[Sales_Manager],
		[Site],
		[Payroll_Name],
		(CASE WHEN [Active] = 1 THEN 'Yes' ELSE 'No' END) AS [Active],
		CONVERT(varchar, [Hire_Date], 101) AS Hire_Date,
		[Category],
		(CASE WHEN Rollover_Rank IS NOT NULL THEN 'Yes' ELSE 'No' END) AS Rollovers_Above_10k,
		(CASE WHEN [Grouping] IS NOT NULL THEN 'Yes' ELSE 'No' END) AS Rollovers_Below_10k,
		Goal
		FROM [Data_Warehouse].[dbo].[tbl_Sales_Teams]
		WHERE [Name] NOT LIKE 'Z%'
		AND PKUsers NOT LIKE '999%'
		AND Sales_Manager IS NOT NULL
		AND [Site] <> 'Company'
		AND	".$SQL_Room." 
		AND [Active] = 1
		ORDER BY [Site], [Sales_Manager], [Name]";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Roster_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result, $i, 0);// PKUser
		$answer[1][$i]=mssql_result($result, $i, 1);// Name
		$answer[2][$i]=mssql_result($result, $i, 2);// Login
		$answer[3][$i]=mssql_result($result, $i, 3);// Sales Manager
		$answer[4][$i]=mssql_result($result, $i, 4);// Site
		$answer[5][$i]=mssql_result($result, $i, 5);// Payroll
		$answer[6][$i]=mssql_result($result, $i, 6);// Active
		$answer[7][$i]=mssql_result($result, $i, 7);// Hire Date
		$answer[8][$i]=mssql_result($result, $i, 8);// Category
		$answer[9][$i]=mssql_result($result, $i, 9);// Rollovers Above 10k
		$answer[10][$i]=mssql_result($result, $i, 10);// Rollovers Below 10k
		$answer[11][$i]=mssql_result($result, $i, 11);// Goal

	}

	if ($debug==2){
		if (! $DB_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Query Looks Like:<br> '.$query);
		echo ('<br>Manager count is: '.$numrows);
		echo ('<br>Session Count is: '.$_SESSION['Roster_Count_'.$room]);

		echo ('<br>');
	}
	Return $answer;
}; //end function get_Team_Rosters($DB_Conn, $room, $debug) 


function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}; //end function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor)


function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}; //end function format_tbl_content($content, $width, $alignment="left", $row_bgcolor)

?>
<html>

<head>

<script type="text/javascript">
	function show_detail(Index_ID){
	<!--
	str_redirect='./BSS_Team_Roster_Update.php?$Index_ID='+Index_ID
//	str_redirect='http://usrc_primary/inventorymatrixweb/default.htm?MOMCustNum='+Cust_ID
//	str_redirect='./SIMS_Sales_Returns_Review_Detail.php?$Index_ID='+Index_ID
//	str_redirect='http://tnichols/Inventory/Inventory_Change.php'//?$inve_asset_tag='"+Index_ID+"'"
	window.open (str_redirect, 'Asset_Window_'+Index_ID, config='height=300, width=700, toolbar=no, menubar=yes, scrollbars=no, resizable=yes, location=no, directories=no, status=no')
	-->

	}

</script>

<script src="JS_Sort_Table.js"></script>

</head>

<title>USRCBR Executive Management</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);


if ($debug==2){
	echo ('<br>Posted Sales Room : '.$_POST["in_Room"]);
	echo ('<br>Posted Sales Manager : '.$_POST["in_Manager"]);
	echo ('<br>Posted Sales Rep : '.$_POST["in_SalesRep"]);
	echo ('<br>Posted enter date : '.$_POST["in_Enter_Date"]);
}

/***************MAIN CODE STARTS HERE ********************/

echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='BSS'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

echo ('	<h2 align=center>Team Roster Manager</h2>');

echo ('<table align="center"><tr><td align="center" valign="top">
	<form action="BSS_Team_Roster_Inactive.php" method="POST">
	<input type="submit" name="Inactive" value="Inactive Roster" />
	</td></tr></form></table>');


$team_roster=get_Team_Rosters($DB2_Conn, 'All Sales Rooms', $debug);
$_SESSION['All_Sales_Reps']=$team_roster;

echo ('	<div id="header">
	<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep", 200, center, $hdr_bgcolor);
	format_tbl_header("Login", 50, center, $hdr_bgcolor);
	format_tbl_header("Manager", 125, center, $hdr_bgcolor);
	format_tbl_header("Room", 50, center, $hdr_bgcolor);
	format_tbl_header("Payroll Name", 200, center, $hdr_bgcolor);
	format_tbl_header("Active?", 50, center, $hdr_bgcolor);
	format_tbl_header("Hire Date", 125, center, $hdr_bgcolor);
	format_tbl_header("Category", 75, center, $hdr_bgcolor);
	format_tbl_header("Rollovers Above 10k+", 50, center, $hdr_bgcolor);
	format_tbl_header("Rollovers Below 10k", 50, center, $hdr_bgcolor);
	format_tbl_header("Goal", 100, center, $hdr_bgcolor);
	echo ('</tr></div><div ID="body1">');

	for ($i=0; $i<$_SESSION['Roster_Count']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	echo ('<tr onClick="show_detail('.($i).')">');		
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	format_tbl_content($team_roster[1][$i], 200, center, $row_bgcolor);//Sales Rep
	format_tbl_content($team_roster[2][$i], 50, center, $row_bgcolor);//Login
	format_tbl_content($team_roster[3][$i], 125, center, $row_bgcolor);//Manager
	format_tbl_content($team_roster[4][$i], 50, center, $row_bgcolor);//Room
	format_tbl_content($team_roster[5][$i], 200, center, $row_bgcolor);//Payroll
	format_tbl_content($team_roster[6][$i], 50, center, $row_bgcolor);//Active?
	format_tbl_content($team_roster[7][$i], 125, center, $row_bgcolor);//Hire Date
	format_tbl_content($team_roster[8][$i], 75, center, $row_bgcolor);//Category
	format_tbl_content($team_roster[9][$i], 50, center, $row_bgcolor);//Rollovers Above 10k
	format_tbl_content($team_roster[10][$i], 50, center, $row_bgcolor);//Rollover Below 10k	
	format_tbl_content(number_format($team_roster[11][$i]), 100, center, $row_bgcolor);//Goal	

	echo ('</tr>');
	}	
	echo ('</table></div>');	




?>

</html>
