<?php
session_start();
$debug=0;
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once ('DB_Login.php');

$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRCAPPSRVR01
mssql_select_db ( $DB0_Database, $DB1_Conn );

//$DB1_Conn = mssql_connect ( $DB00_Host, $DB00_UserName, $DB00_Password, TRUE ); //connect to USRCAPPSRVR01
//mssql_select_db ( $DB00_Database, $DB1_Conn );

$DB2_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB2_Conn );

//$DB3_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCSQLCLS1
//mssql_select_db ( $DB20_Database, $DB20_Conn );

if(isset($_GET['$Index_ID'])){
$orig_list			= $_SESSION['All_Sales_Reps'];
$orig_index			= $_GET['$Index_ID'];
$orig_PKUserID			= $orig_list[0][$_GET['$Index_ID']];
$orig_Sales_Rep			= $orig_list[1][$_GET['$Index_ID']];
$orig_Login			= $orig_list[2][$_GET['$Index_ID']];
$orig_Sales_Manager		= $orig_list[3][$_GET['$Index_ID']];
$orig_Super_Team		= $orig_list[4][$_GET['$Index_ID']];
$orig_Room			= $orig_list[5][$_GET['$Index_ID']];
$orig_Payroll_Name		= $orig_list[6][$_GET['$Index_ID']];
$orig_Active			= $orig_list[7][$_GET['$Index_ID']];
$orig_Hire_Date			= $orig_list[8][$_GET['$Index_ID']];
$orig_Category			= $orig_list[9][$_GET['$Index_ID']];
$orig_Rollovers_Above_10k	= $orig_list[10][$_GET['$Index_ID']];
$orig_Rollovers_Below_10k	= $orig_list[11][$_GET['$Index_ID']];
$orig_Goal			= $orig_list[12][$_GET['$Index_ID']];
}

If ($debug==1) {	

	if (! $DB1_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database ".$DB0_Host.". <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database ".$DB0_Host.". <br />";}

	if (! $DB2_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database ".$DB20_Host.". <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database ".$DB20_Host.". <br />";}
/*
	if (! $DB3_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database ".$DB20_Host.". <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database ".$DB20_Host.". <br />";}
 */
	echo ('<br>Session All Sales Reps: '.$_SESSION['All_Sales_Reps']);

	if(isset($_GET['$Index_ID'])){
		echo ('<br>GET index: '.$_GET['$Index_ID']);	
	}
	if(isset($orig_index)){
		echo ('<br>Orig index: '.$orig_index);	
	}
	if(isset($orig_PKUserID)){
		echo ('<br>Orig PKUserID: '.$orig_PKUserID);
	}
	if(isset($orig_Sales_Rep)){
		echo ('<br>Orig Sales Rep: '.$orig_Sales_Rep);
	}
	if(isset($orig_Login)){
	echo ('<br>Orig Login: '.$orig_Login);	
	}

	echo ('<br>DB1 Used: '.$DB0_Database);	
	echo ('<br>DB1 User_ID: '.$DB0_UserName);	
	echo ('<br>DB1 User_PW: '.$DB0_Password);	
	echo ('<br>DB2 Used: '.$DB20_Database);	
	echo ('<br>DB2 User_ID: '.$DB20_UserName);	
	echo ('<br>DB2 User_PW: '.$DB20_Password);	

	echo ('<br>**************************************************************************************');
};

function update_team_roster_1 ($db_conn, $pk_user_id, $sales_rep, $super_team, $manager, $room, $active, $category, $hire_date, $rollovers_above_10k, $rollovers_below_10k, $goal, $debug) {

	if(isset($DB20_Database)){
	mssql_select_db ( $DB20_Database, $db_conn );
	}

	if ($active =='Yes'){
		$SQL_active = ' [Active] = 1,';}
	else {
		$SQL_active = ' [Active] = 0,';}

	if ($category=='None'){
		$SQL_category =' Category = null, ';}
	else {
		$SQL_category =" Category ='".$category."',";
	}

	if ($rollovers_above_10k=='No'){
		$SQL_ranking1 =' Rollover_Rank = null, ';}
	else {
		$SQL_ranking1 =' Rollover_Rank = 60, ';
	}

	if ($rollovers_below_10k=='No'){
		$SQL_ranking2 =' [Grouping] = null, ';}
	else {
		$SQL_ranking2 =' [Grouping] = 4, ';
	}


	if ($goal==''){
		$SQL_goal =' Goal = null ';}
	else {
		$SQL_goal =" Goal =".$goal;
	}

	$query="UPDATE Data_Warehouse.dbo.tbl_Sales_Teams
		SET Sales_Manager = '".$manager."',
		Hire_Date = '".$hire_date."',
		[Site] = '".$room."', 
		Super_Team = '".$super_team."',
		".$SQL_active."
		".$SQL_category."
		".$SQL_ranking1."
		".$SQL_ranking2."
		".$SQL_goal."
		WHERE [Name] ='".$sales_rep."'
		AND PKUsers ='".$pk_user_id."'";

	$result=mssql_query($query, $db_conn);// or die(mysql_error()); ;//  or die('Query failed: '.$query);

If ($debug==1) {	
	if (! $db_conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database for tbl_Sales_Teams. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "<br>Debug Mode: ON <br> Successfully connected to USRCSQLCLS1 database. <br />";}

	echo ('<br>Query looks like: '.$query);
	echo ('<br>sales rep looks like: '.$sales_rep);
	echo ('<br>manager like: '.$manager);
	echo ('<br>room looks like: '.$room);
	echo ('<br>active looks like: '.$active);
	echo ('<br>category looks like: '.$category);

	If(isset($_GET['$Index_ID'])){
	echo ('<br>GET index: '.$_GET['$Index_ID']);	
	}
	echo ('<br>Query $result looks like: '.$result);
	echo ('<br>Query $db_conn looks like: '.$db_conn);	
	echo ('<br>**************************************************************************************');
}; //end If ($debug==2) 
}//end function update_team_roster_1 ($db_conn, $pk_user_id, $sales_rep, $manager, $room, $active, $category, $debug)

function update_team_roster_2 ($db_conn, $sales_rep, $super_team, $manager, $room, $active, $debug) {

	switch ($super_team) {
	    case "Ben Rollings":
	        $SQL_super_team = " Super_Team = 'Ben Rollings (BN)',";
		break;
	    case "Rollings":
	        $SQL_super_team = " Super_Team = 'Ben Rollings (BN)',";
	        break;		
	    case "Phillip Kitchens":
	        $SQL_super_team = " Super_Team = 'Phillip Kitchens (PEK)',";
		break;
	    case "Kitchens":
	        $SQL_super_team = " Super_Team = 'Phillip Kitchens (PEK)',";
		break;
	    case "Dominguez":
	        $SQL_super_team = " Super_Team = 'Steve Dominguez (SRD)',";
		break;	
	    case "Steve Dominguez":
	        $SQL_super_team = " Super_Team = 'Steve Dominguez (SRD)',";
		break;
	    case "Fowler":
	        $SQL_super_team = " Super_Team = 'Wayne Fowler (JF)',";
		break;		
	    case "Wayne Fowler":
	        $SQL_super_team = " Super_Team = 'Wayne Fowler (JF)',";
		break;		
	    case "Granger":
	        $SQL_super_team = " Super_Team = 'Lee Granger (CG)',";
		break;		
	    case "Lee Granger":
	        $SQL_super_team = " Super_Team = 'Lee Granger (CG)',";
		break;		
	    case "Ozen":
	        $SQL_super_team = " Super_Team = 'Kenan Ozen (KO)',";
		break;		
	    case "Kenan Ozen":
	        $SQL_super_team = " Super_Team = 'Kenan Ozen (KO)',";
		break;		
	    case "Shakespeare":
	        $SQL_super_team = " Super_Team = 'Steven Shakespeare (SLS)',";
	        break;		
	    case "Steven Shakespeare":
	        $SQL_super_team = " Super_Team = 'Steven Shakespeare (SLS)',";
	        break;		
	    case "Montoya":
	        $SQL_super_team = " Super_Team = 'Marcus Montoya (MLM)',";
	        break;	
	    case "Marcus Montoya":
	        $SQL_super_team = " Super_Team = 'Marcus Montoya (MLM)',";
	        break;	
	}

	switch ($manager) {
	    case "Ben Rollings":
	        $SQL_manager = " Manager = 'Ben Rollings (BN)',";
		break;
    	    case "Coy Wells":
	        $SQL_manager = " Manager = 'Coy Wells (CFW)',";
	        break;
	    case "Phillip Kitchens":
	        $SQL_manager = " Manager = 'Phillip Kitchens (PEK)',";
		break;
	    case "Steve Dominguez":
	        $SQL_manager = " Manager = 'Steve Dominguez (SRD)',";
		break;
	    case "Wayne Fowler":
	        $SQL_manager = " Manager = 'Wayne Fowler (JF)',";
		break;		
	    case "Lee Granger":
	        $SQL_manager = " Manager = 'Lee Granger (CG)',";
		break;		
	    case "Kenan Ozen":
	        $SQL_manager = " Manager = 'Kenan Ozen (KO)',";
		break;		
	    case "Steven Shakespeare":
	        $SQL_manager = " Manager = 'Steven Shakespeare (SLS)',";
	        break;		
	    case "Marcus Montoya":
	        $SQL_manager = " Manager = 'Marcus Montoya (MLM)',";
	        break;	
	}

	if ($active =='Yes'){
		$SQL_active = ' Populate = 1,';}
	else {
		$SQL_active = ' Populate = 0,';}


	switch ($room) {
	    case "Austin":
	        $SQL_room = " RoomCode = 'AU' ";
		break;
	    case "AU":
	        $SQL_room = " RoomCode = 'AU' ";
	        break;
	    case "Beaumont":
	        $SQL_room = " RoomCode = 'BM' ";
		break;
	    case "BM":
	        $SQL_room = " RoomCode = 'BM' ";
	        break;
	    case "C3":
	        $SQL_room = " RoomCode = 'C3' ";
	        break;
	    case "D4":
	        $SQL_room = " RoomCode = 'D4' ";
	        break;
	}

	$query="UPDATE [SIMS].dbo.LoginTable
		SET ".$SQL_super_team." ".$SQL_manager." ".$SQL_active." ".$SQL_room."  
		WHERE RealName = '".$sales_rep."'";

	$result1 = mssql_query("SET ANSI_NULLS ON", $db_conn) OR DIE(mssql_get_last_message());
	$result1 = mssql_query("SET ANSI_PADDING ON", $db_conn) OR DIE(mssql_get_last_message());
	$result1 = mssql_query("SET ANSI_WARNINGS ON", $db_conn) OR DIE(mssql_get_last_message());
	$result1 = mssql_query("SET QUOTED_IDENTIFIER ON", $db_conn) OR DIE(mssql_get_last_message());
	$result1 = mssql_query("SET CONCAT_NULL_YIELDS_NULL ON", $db_conn) OR DIE(mssql_get_last_message());

	$result=mssql_query($query, $db_conn);

If ($debug==1) {	
	if (! $db_conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to USRCAPPSRVR01 database for SIMS update. <br />";}

	echo ('<br>Query looks like: '.$query);
	echo ('<br>sales rep looks like: '.$sales_rep);
	echo ('<br>manager like: '.$manager);
	echo ('<br>room looks like: '.$room);
	echo ('<br>active looks like: '.$active);
	//echo ('<br>category looks like: '.$category);
	
	if(isset($_GET['$Index_ID'])){
	echo ('<br>GET index: '.$_GET['$Index_ID']);	
	}
	echo ('<br>Query $result looks like: '.$result);
	echo ('<br>Query $db_conn looks like: '.$db_conn);	

	echo ('<br>**************************************************************************************');
}; //end If ($debug==2) 
}//end function update_team_roster_1 ($db_conn, $pk_user_id, $sales_rep, $manager, $room, $active, $category, $debug)

function get_Sales_Managers($DB1_Conn, $debug) {

	 $query="SELECT Sales_Manager FROM Data_Warehouse.dbo.tbl_Sales_Teams
		 WHERE Sales_Manager IS NOT NULL
		 AND Sales_Manager <> 'Remmy Castillo'
 		 AND Sales_Manager <> ''
		 AND Active = 1
		GROUP BY Sales_Manager";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Sales_Manager_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Manager
	}

	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Query Looks Like:<br> '.$query);
		echo ('<br>');
	}//	if ($debug==1)
	Return $answer;
};//	function get_Sales_Managers($DB1_Conn, $room, $debug) 

function get_Super_Teams($DB1_Conn, $debug) {

	 $query="SELECT Super_Team FROM Data_Warehouse.dbo.tbl_Sales_Teams
		WHERE (Super_Team IS NOT NULL AND Super_Team <> '')
		GROUP BY Super_Team";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Super_Team_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Super_Team
	}

	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Super Team Query Looks Like:<br> '.$query);
		echo ('<br>');
	}//	if ($debug==1)
	Return $answer;
};//	function get_Super_Teams($DB1_Conn, $debug) 

function get_Rooms($DB1_Conn, $debug) {

	 $query="SELECT [Site] FROM Data_Warehouse.dbo.tbl_Sales_Teams
		 WHERE ([Site] IS NOT NULL AND [Site] <> '')
		 AND [Site] <> 'Company'
		GROUP BY [Site]";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Room_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Super_Team
	}

	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Room Query Looks Like:<br> '.$query);
		echo ('<br>');
	}//	if ($debug==1)
	Return $answer;
};//	function get_Rooms($DB1_Conn, $debug) 

function strToDateTime($date, $format) {
    if(!($date = strToDate($date, $format))) return;
    $dateTime = array('sec' => 0, 'min' => 0, 'hour' => 0, 'day' => 0, 'mon' => 0, 'year' => 0, 'timestamp' => 0);
    foreach($date as $key => $val) {
        switch($key) {
            case 'd':
            case 'j': $dateTime['day'] = intval($val); break;
            case 'D': $dateTime['day'] = intval(date('j', $val)); break;
           
            case 'm':
            case 'n': $dateTime['mon'] = intval($val); break;
            case 'M': $dateTime['mon'] = intval(date('n', $val)); break;
           
            case 'Y': $dateTime['year'] = intval($val); break;
            case 'y': $dateTime['year'] = intval($val)+2000; break;
           
            case 'G':
            case 'g':
            case 'H':
            case 'h': $dateTime['hour'] = intval($val); break;
           
            case 'i': $dateTime['min'] = intval($val); break;
           
            case 's': $dateTime['sec'] = intval($val); break;
        }
    }
    $dateTime['timestamp'] = mktime($dateTime['hour'], $dateTime['min'], $dateTime['sec'], $dateTime['mon'], $dateTime['day'], $dateTime['year']);
    return $dateTime;
} // strToDateTime($date, $format) 




?>

<html>
<title>USRCBR Executive Management: Team Roster Manager</title>
<head>


</head>

<body>
<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);


if(isset($_POST['Update'])){


//	$orig_Payroll_Name		= $orig_list[6][$_GET['$Index_ID']];

	if(isset($_SESSION["in_PK_User_ID"]) && isset($_SESSION["in_Sales_Rep"]) && isset($_POST["in_Super_Team"]) && isset($_POST["in_Sales_Manager"]) && 
	isset($_POST["in_Room"]) && isset($_POST["in_Active"]) && isset($_POST["in_Category"]) && isset($_POST["in_Hire_Date"]) && isset($_POST["in_Rollovers_Above_10k"]) && 
	isset($_POST["in_Rollovers_Below_10k"]) && isset($_POST["in_Goal"])) {
		update_team_roster_1 ($DB2_Conn, $_SESSION["in_PK_User_ID"], $_SESSION["in_Sales_Rep"], $_POST["in_Super_Team"], $_POST["in_Sales_Manager"], $_POST["in_Room"], $_POST["in_Active"], $_POST["in_Category"], $_POST["in_Hire_Date"], $_POST["in_Rollovers_Above_10k"], $_POST["in_Rollovers_Below_10k"], $_POST["in_Goal"], $debug);
}


	if(isset($_SESSION["in_Sales_Rep"]) && isset($_POST["in_Sales_Manager"]) && isset($_POST["in_Room"]) && isset($_POST["in_Active"])) {
		update_team_roster_2 ($DB1_Conn, $_SESSION["in_Sales_Rep"], $_POST["in_Super_Team"], $_POST["in_Sales_Manager"], $_POST["in_Room"], $_POST["in_Active"], $debug);
}

echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Team Roster (Updated)</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>
	<h3 align=center>'.$_SESSION["in_Payroll_Name"].'</h3>

	<table align=center>
	<tr>
	<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">

	<td style="width=150px" align=left valign=top>
	<label>Super Team<br></label><b>'.$_POST["in_Super_Team"].'</b>
	</td>
	<td style="width=150px" align=left valign=top>');

	if(isset($_POST["in_Sales_Manager"])){
	echo ('	<label>Sales Manager<br><b>'.$_POST["in_Sales_Manager"].'</b></label>');
	}

	echo ('</td>

	<td style="width=50px" align=left valign=top>
	<label>Room<br><b>'.$_POST["in_Room"].'</b></label>
	</td>

	<td style="width=50px" align=left valign=top>
	<label>Active?<br><b>'.$_POST["in_Active"].'</b></label>
	</td>

	<td style="width=75px" align=left valign=top>
	<label>Category<br><b>'.$_POST["in_Category"].'</b></label>
	</td>

	<td style="width=75px" align=left valign=top>
	<label>Hire Date<br><b>'.$_POST["in_Hire_Date"].'</b></label>
	</td>

	<td style="width=25px" align=left valign=top>
	<label>Rollovers Above 10k<br><b>'.$_POST["in_Rollovers_Above_10k"].'</b></label>
	</td>

	<td style="width=25px" align=left valign=top>
	<label>Rollovers Below 10k<br><b>'.$_POST["in_Rollovers_Below_10k"].'</b></label>
	</td>

	<td style="width=35px" align=left valign=top>
	<label>Goal<br><b>'.$_POST["in_Goal"].'</b></label>
	</td>

	</tr>

	<tr><td colspan=9 valign="top" align="center">
	<input type="submit" name="Update" value="Update" />
	
	</table>');

} // end if($_POST['Update'])

else {

$_SESSION["in_Sales_Rep"]=$orig_Sales_Rep;
$_SESSION["in_Super_Team"]=$orig_Super_Team;
$_SESSION["in_PK_User_ID"]=$orig_PKUserID;
$_SESSION["in_Payroll_Name"]=$orig_Payroll_Name;

//$Super_Teams=get_Sales_Managers($DB2_Conn, $debug);
$Super_Teams=get_Super_Teams($DB2_Conn, $debug);
$Sales_Managers=get_Sales_Managers($DB2_Conn, $debug);
$Rooms=get_Rooms($DB2_Conn, $debug);

echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Team Roster (Original)</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>
	<h3 align=center>'.$_SESSION["in_Payroll_Name"].'</h3>

	<table align=center>
	<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
	<tr>
	<td style="width=200px" align=left valign=top>
	<label>Super Team:<br>
	<select name="in_Super_Team">
	<option>'.$orig_Super_Team.'</option>
	<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</option>');

	for($i=0;$i<$_SESSION['Super_Team_Count'];$i+=1){
		echo ('<option value="'.$Super_Teams[$i].'">'.$Super_Teams[$i].'</option>  ');
	}
			
echo ('	</td>
	<td style="width=150px" align=left valign=top>

	<label>Sales Manager:<br>
	<select name="in_Sales_Manager">
	<option>'.$orig_Sales_Manager.'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>');

	for($i=0;$i<$_SESSION['Sales_Manager_Count'];$i+=1){
		echo ('<option value="'.$Sales_Managers[$i].'">'.$Sales_Managers[$i].'</option>  ');
	}

echo ('	</td>
	<td style="width=50px" align=left valign=top>

	<label>Room:<br>
	<select name="in_Room">
	<option>'.$orig_Room.'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>');

	for($i=0;$i<$_SESSION['Room_Count'];$i+=1){
		echo ('<option value="'.$Rooms[$i].'">'.$Rooms[$i].'</option>  ');
	}


echo ('	</td>

	<td style="width=50px" align=left valign=top>
	<label>Active?<br></label>
	<select name="in_Active">
	<option>'.$orig_Active.'</option>
	<option value="Yes">Yes</option>
	<option value="No">No</option>
	</td>

	<td style="width=75px" align=left valign=top>
	<label>Category<br></label>
	<select name="in_Category">
	<option>'.$orig_Category.'</option>
	<option value="None">None</option>
	<option value="Team">Team</option>
	<option value="Trainee">Trainee</option>
	<option value="Inbound">Inbound</option>
	<option value="Outbound">Outbound</option>
	</td>

	<td style="width=75px" align=left valign=top>
	<label>Hiring Date<br></label>
	<input type="text" name="in_Hire_Date" size=8 align=center value="'.$orig_Hire_Date.'">
	</td>

	<td style="width=25px" align=left valign=top>
	<label>Rollovers Above 10k<br></label>
	<select name="in_Rollovers_Above_10k">
	<option>'.$orig_Rollovers_Above_10k.'</option>
	<option value="Yes">Yes</option>
	<option value="No">No</option>
	</td>

	<td style="width=25px" align=left valign=top>
	<label>Rollovers Below 10k<br></label>
	<select name="in_Rollovers_Below_10k">
	<option>'.$orig_Rollovers_Below_10k.'</option>
	<option value="Yes">Yes</option>
	<option value="No">No</option>
	</td>

	<td style="width=35px" align=left valign=top>
	<label>Goal<br></label>
	<input type="text" name="in_Goal" size=5 align=center value="'.$orig_Goal.'">
	</td>

	</tr>

	<tr><td colspan=9 valign="top" align="center">
	<input type="submit" name="Update" value="Update" />
	</td>
	</tr>
	</table>');
}; //end else if($_POST['Update'])

	If ($debug==1) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database ".$DB0_Host."<br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine to ".$DB0_Host."<br> First Pass. <br>";}


		IF (! $DB2_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database ".$DB20_Host."<br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine to  ".$DB20_Host."<br> First Pass. <br>";}
/*
		IF (! $DB3_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine to USRCSQLCLS1. <br> First Pass. <br>";}
*/			

		echo "in Sales Reps: '<b>".$_SESSION["in_Sales_Rep"]."</b>'<br>";
		echo "PK User ID: '<b>".$_SESSION["in_PK_User_ID"]."</b>'<br>";



		//echo "Suggestions to Sales Reps: '<b>".$_POST["in_Comments"]."</b>'<br>";

	};

?>
</body>
</html>

