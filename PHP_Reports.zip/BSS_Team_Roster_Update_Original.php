<?php
session_start();
$debug=0;

require_once ('DB_Login.php');

$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRC_SIMSSERVER
mssql_select_db ( $DB0_Database, $DB1_Conn );
$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB2_Database, $DB2_Conn );

$orig_list		= $_SESSION['All_Sales_Reps'];
$orig_index		= $_GET['$Index_ID'];
$orig_PKUserID		= $orig_list[0][$_GET['$Index_ID']];
$orig_Sales_Rep		= $orig_list[1][$_GET['$Index_ID']];
$orig_Login		= $orig_list[2][$_GET['$Index_ID']];
$orig_Manager		= $orig_list[3][$_GET['$Index_ID']];
$orig_Room		= $orig_list[4][$_GET['$Index_ID']];
$orig_Payroll_Name	= $orig_list[5][$_GET['$Index_ID']];
$orig_Active		= $orig_list[6][$_GET['$Index_ID']];
$orig_Hire_Date		= $orig_list[7][$_GET['$Index_ID']];
$orig_Category		= $orig_list[8][$_GET['$Index_ID']];
$orig_Rollover_Rank	= $orig_list[9][$_GET['$Index_ID']];

If ($debug==2) {	
	if (! $DB2_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database. <br />";}

	echo ('<br>Session All Sales Reps: '.$_SESSION['All_Sales_Reps']);
	echo ('<br>GET index: '.$_GET['$Index_ID']);	
	echo ('<br>Orig index: '.$orig_index);	
	echo ('<br>Orig PKUserID: '.$orig_PKUserID);
	echo ('<br>Orig Sales Rep: '.$orig_Sales_Rep);
	echo ('<br>Orig Login: '.$orig_Login);	
	echo ('<br>DB Used: '.$DB2_Database);	
	echo ('<br>DB User: '.$DB2_UserName);	
	echo ('<br>**************************************************************************************');
};

function update_team_roster_1 ($db_conn, $pk_user_id, $sales_rep, $manager, $room, $active, $category, $ranking, $debug) {

	if ($active =='Yes'){
		$SQL_active = ' [Active] = 1,';}
	else {
		$SQL_active = ' [Active] = 0,';}

	if ($category=='None'){
		$SQL_category =' Category = null, ';}
	else {
		$SQL_category =" Category ='".$category."',";
	}

	if ($ranking==''){
		$SQL_ranking =' Rollover_Rank = null ';}
	else {
		$SQL_ranking =" Rollover_Rank =".$ranking;
	}


	$query="UPDATE tbl_Sales_Teams
		SET Sales_Manager = '".$manager."',
		[Site] = '".$room."', 
		".$SQL_active."
		".$SQL_category."
		".$SQL_ranking."
		WHERE [Name] ='".$sales_rep."'
		AND PKUsers ='".$pk_user_id."'";

	$result=mssql_query($query, $db_conn);

If ($debug==1) {	
	if (! $db_conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to USRCREP02 database. <br />";}

	echo ('<br>Query looks like: '.$query);
	echo ('<br>sales rep looks like: '.$sales_rep);
	echo ('<br>manager like: '.$manager);
	echo ('<br>room looks like: '.$room);
	echo ('<br>active looks like: '.$active);
	echo ('<br>category looks like: '.$category);
	echo ('<br>GET index: '.$_GET['$Index_ID']);	
	echo ('<br>**************************************************************************************');
}; //end If ($debug==2) 
}//end function update_team_roster_1 ($db_conn, $pk_user_id, $sales_rep, $manager, $room, $active, $category, $debug)

function update_team_roster_2 ($db_conn, $sales_rep, $manager, $room, $debug) {

	switch ($manager) {
	    case "Ben Rollings":
	        $SQL_manager = " Manager = 'Ben Rollings (BN)',";
	        break;
	    case "Brad Remington":
	        $SQL_manager = " Manager = 'Brad Remington (RBC)',";
	        break;
	    case "Robert Raben":
	        $SQL_manager = " Manager = 'Robert Raben (RN)',";
		break;
	    case "Phillip Kitchens":
	        $SQL_manager = " Manager = 'Phillip Kitchens (PEK)',";
		break;
	    case "Steve Dominguez":
	        $SQL_manager = " Manager = 'Steve Dominguez (SRD)',";
		break;
	    case "Johnpaul Durham":
	        $SQL_manager = " Manager = 'Johnpaul Durham (JP)',";
		break;
	    case "Wayne Fowler":
	        $SQL_manager = " Manager = 'Wayne Fowler (JF)',";
		break;		
	    case "Lee Granger":
	        $SQL_manager = " Manager = 'Lee Granger (CG)',";
	        break;		
	    case "Marcus Montoya":
	        $SQL_manager = " Manager = 'Marcus Montoya (MLM)',";
	        break;	
	}

	switch ($room) {
	    case "Austin":
	        $SQL_room = " SecurityLevel = 'Austin Sales' ";
	        break;
	    case "Beaumont":
	        $SQL_room = " SecurityLevel = 'Beaumont Sales' ";
	        break;
	    case "C3":
	        $SQL_room = " SecurityLevel = 'C3 Sales' ";
	        break;
	}

	$query="UPDATE [SIMS].dbo.LoginTable
		SET ".$SQL_manager." ".$SQL_room."  
		WHERE RealName = '".$sales_rep."'";

	$result=mssql_query($query, $db_conn);

If ($debug==1) {	
	if (! $db_conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to USRCREP02 database. <br />";}

	echo ('<br>Query looks like: '.$query);
	echo ('<br>sales rep looks like: '.$sales_rep);
	echo ('<br>manager like: '.$manager);
	echo ('<br>room looks like: '.$room);
	echo ('<br>active looks like: '.$active);
	echo ('<br>category looks like: '.$category);
	echo ('<br>GET index: '.$_GET['$Index_ID']);	
	echo ('<br>**************************************************************************************');
}; //end If ($debug==2) 
}//end function update_team_roster_1 ($db_conn, $pk_user_id, $sales_rep, $manager, $room, $active, $category, $debug)


?>

<html>
<title>USRCBR Executive Management: Team Roster Manager</title>
<head>


</head>

<body>
<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);


if ($_POST['Update']){

update_team_roster_1 ($DB2_Conn, $_SESSION["in_PK_User_ID"], $_SESSION["in_Sales_Rep"], $_POST["in_Sales_Manager"], $_POST["in_Room"], $_POST["in_Active"], $_POST["in_Category"], $_POST["in_Rollover_Rank"], $debug);

update_team_roster_2 ($DB1_Conn, $_SESSION["in_Sales_Rep"], $_POST["in_Sales_Manager"], $_POST["in_Room"], $debug);

	//echo ('<br>post-update');

	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Team Roster (Updated)</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>

	<table align=center>
	<tr>
	<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
	<td style="width=200px" align=left valign=top>
	<label>Sales Rep:<br><b>'.$_SESSION["in_Sales_Rep"].'</b></label>
	</td>
	
	<td style="width=150px" align=left valign=top>
	<label>Sales Manager<br></label>
	<select name="in_Sales_Manager">
	<option>'.$_POST["in_Sales_Manager"].'</option>
	<option value="Ben Rollings">Ben Rollings</option>
	<option value="Lee Granger">Lee Granger</option>
	<option value="Marcus Montoya">Marcus Montoya</option>
	<option value="Phillip Kitchens">Phillip Kitchens</option>
	<option value="Robert Raben">Robert Raben</option>
	<option value="Steve Dominguez">Steve Dominguez</option>
	<option value="Wayne Fowler">Wayne Fowler</option>
	</td>

	<td style="width=50px" align=left valign=top>
	<label>Room<br></label>
	<select name="in_Room">
	<option>'.$_POST["in_Room"].'</option>
	<option value="Austin">Austin</option>
	<option value="Beaumont">Beaumont</option>
	<option value="C3">C3</option>
	</td>

	<td style="width=50px" align=left valign=top>
	<label>Active?<br></label>
	<select name="in_Active">
	<option>'.$_POST["in_Active"].'</option>
	<option value="Yes">Yes</option>
	<option value="No">No</option>
	</td>

	<td style="width=75px" align=left valign=top>
	<label>Category<br></label>
	<select name="in_Category">
	<option>'.$_POST["in_Category"].'</option>
	<option value="None">None</option>
	<option value="Team">Team</option>
	<option value="Trainee">Trainee</option>
	</td>

	<td style="width=25px" align=left valign=top>
	<label>Ranking<br></label>
	<input type="text" name="in_Rollover_Rank" size=5 align=left value="'.$_POST["in_Rollover_Rank"].'"></label>
	</td>


	</tr>

	<tr><td colspan=6 valign="top" align="center">
	<input type="submit" name="Update" value="Update" />
	
	</table>');




} // end if($_POST['Update'])
else {
//echo ('<br>pre-update');

$_SESSION["in_Sales_Rep"]=$orig_Sales_Rep;
$_SESSION["in_PK_User_ID"]=$orig_PKUserID;

echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Team Roster (Original)</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>

	<table align=center>
	<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
	<tr>
	<td style="width=200px" align=left valign=top>
	<label>Sales Rep:<br><b>'.$orig_Sales_Rep.'</b></label>
	</td>
	
	<td style="width=150px" align=left valign=top>
	<label>Sales Manager<br></label>
	<select name="in_Sales_Manager">
	<option>'.$orig_Manager.'</option>
	<option value="Ben Rollings">Ben Rollings</option>
	<option value="Marcus Montoya">Marcus Montoya</option>
	<option value="Lee Granger">Lee Granger</option>
	<option value="Phillip Kitchens">Phillip Kitchens</option>
	<option value="Robert Raben">Robert Raben</option>
	<option value="Steve Dominguez">Steve Dominguez</option>
	<option value="Wayne Fowler">Wayne Fowler</option>
	</td>

	<td style="width=50px" align=left valign=top>
	<label>Room<br></label>
	<select name="in_Room">
	<option>'.$orig_Room.'</option>
	<option value="Austin">Austin</option>
	<option value="Beaumont">Beaumont</option>
	<option value="C3">C3</option>
	</td>

	<td style="width=50px" align=left valign=top>
	<label>Active?<br></label>
	<select name="in_Active">
	<option>'.$orig_Active.'</option>
	<option value="Yes">Yes</option>
	<option value="No">No</option>
	</td>

	<td style="width=75px" align=left valign=top>
	<label>Category<br></label>
	<select name="in_Category">
	<option>'.$orig_Category.'</option>
	<option value="None">None</option>
	<option value="Team">Team</option>
	<option value="Trainee">Trainee</option>
	</td>

	<td style="width=25px" align=left valign=top>
	<label>Ranking<br></label>
	<input type="text" name="in_Rollover_Rank" size=5 align=center value="'.$orig_Rollover_Rank.'">
	</td>


	</tr>

	<tr><td colspan=6 valign="top" align="center">
	<input type="submit" name="Update" value="Update" />
	</td>
	</tr>
	</table>');
}; //end else if($_POST['Update'])

	If ($debug==2) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine. <br> First Pass. <br>";}


		echo "in Sales Reps: '<b>".$_SESSION["in_Sales_Rep"]."</b>'<br>";
		echo "PK User ID: '<b>".$_SESSION["in_PK_User_ID"]."</b>'<br>";



		echo "Suggestions to Sales Reps: '<b>".$_POST["in_Comments"]."</b>'<br>";

	};

?>
</body>
</html>

