<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


IF ($securitygroup=='BSS' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Vault Returns Manager')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}
 

/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////


require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB5_Host, $DB5_UserName, $DB5_Password, TRUE ); //connect to USRC_SIMSSERVER
//$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB5_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";


function get_Verification_List ($DB_Conn, $debug) {
 
	$query="
		SELECT
		CMS.ORDERNO AS Order_ID,
		CMS.CUSTNUM AS Cust_ID,
		RTRIM(CUST.FIRSTNAME) + ' ' + RTRIM(CUST.LASTNAME) AS Full_Name,
		CMS.SHIPLIST AS Shipping_Type,
		CONVERT(date, CMS.SHIP_DATE) AS Shipped_Date,
		CMS.TB_MERCH AS Order_Value,
		CUST.PHONE AS Primary_Phone,
		CUST.PHONE2 AS Alternate_Phone
		FROM CMS 
		INNER JOIN CUST
		ON CMS.CUSTNUM=CUST.CUSTNUM
		WHERE SHIP_DATE >= dbo.Get_TheDate(GETDATE()-1)
		AND CMS.TB_MERCH > 0
		ORDER BY  
		CMS.TB_MERCH DESC
		";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Inventory_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);// Order_ID
		$answer[$i][1]=mssql_result($result, $i, 1);// Cust_ID
		$answer[$i][2]=mssql_result($result, $i, 2);// Full_Name
		$answer[$i][3]=mssql_result($result, $i, 3);// Shipping_Type
		$answer[$i][4]=mssql_result($result, $i, 4);// Shipped_Date
		$answer[$i][5]=mssql_result($result, $i, 5);// Order_Value	
		$answer[$i][6]=mssql_result($result, $i, 6);// Order_Value			
		$answer[$i][7]=mssql_result($result, $i, 7);// Order_Value	
	}

	if ($debug==1){
		if (! $DB_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Current Inventory Query Looks Like:<br><b> '.$query.'</b><br>');
		echo ('<br>Manager count is: '.$numrows);
		echo ('<br>Session Count is: '.$_SESSION['Inventory_Count'.$room]);
		echo ('<br>');
	}
	Return $answer;
}; //end function get_Curent_Inventory ($DB_Conn, $debug) 


function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}; //end function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor)


function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}; //end function format_tbl_content($content, $width, $alignment="left", $row_bgcolor)

?>
<html>

<head>

<script src="JS_Sort_Table.js"></script>

</head>

<title>USRCBR SIMS Sales Report</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Business Support Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Inventory'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Inventory_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Business Support Services: Verification List</h2>');

	//echo (' <table align="center"><tr><td valign="top">Report Request Sent</td></tr></table>');
	//$command = "c:\\EXEC_Inve_Status.bat";
	//$output = shell_exec("$command");


	echo ('	<table align="center" class="sortable">	<tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Order ID", 100, center, $hdr_bgcolor);
	format_tbl_header("Cust ID", 100, center, $hdr_bgcolor);
	format_tbl_header("Full Name", 250, center, $hdr_bgcolor);
	format_tbl_header("Shipping Type", 150, center, $hdr_bgcolor);
	format_tbl_header("Shipping Date", 150, center, $hdr_bgcolor);
	format_tbl_header("Order Value", 100, center, $hdr_bgcolor);
	format_tbl_header("Primary Phone", 150, center, $hdr_bgcolor);
	format_tbl_header("Alternate Phone", 150, center, $hdr_bgcolor);

	echo ('</tr><tr>');

	$inventory=get_Verification_List ($DB1_Conn, $debug);

	for ($i=0; $i<$_SESSION['Inventory_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');

	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index
	format_tbl_content($inventory[$i][0], 100, center, $row_bgcolor);	//Order_ID
	format_tbl_content($inventory[$i][1], 100, center, $row_bgcolor);	//Cust_ID
//	format_tbl_content($inventory[$i][1], 100, center, $row_bgcolor);	//Unit Retail

	
	format_tbl_content($inventory[$i][2], 250, center, $row_bgcolor);	//
	format_tbl_content($inventory[$i][3], 150, center, $row_bgcolor);	//
	format_tbl_content($inventory[$i][4], 150, center, $row_bgcolor);	//
//	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">'.$inventory[$i][4].'</td> ');
	format_tbl_content($inventory[$i][5], 100, center, $row_bgcolor);	//
	format_tbl_content($inventory[$i][6], 150, center, $row_bgcolor);	//
	format_tbl_content($inventory[$i][7], 150, center, $row_bgcolor);	//


	echo ('</tr><tr>');
	}

	echo ('</tr></table>');





?>

</html>
