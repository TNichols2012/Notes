<?php

//header('Location: ./Login.php');


// PHP_Reports Database on USRCAPPSRVR01 
$DB0_Host="USRCAPPSRVR01";
$DB0_Database="SIMS";
$DB0_UserName="SQL_Admin";
$DB0_Password="killjoy79";

// PHP_Reports Database on USRCAPPSRVR01 
$DB00_Host="USRCDATASRVR01";
$DB00_Database="SIMSTest1";
$DB00_UserName="SQL_Admin";
$DB00_Password="killjoy79";

// SIMS Database on USRC_SIMSSERVER
$DB1_Host="USRC_SIMSSERVER";
$DB1_Database="SIMS";
$DB1_UserName="SQL_Admin";
$DB1_Password="killjoy79";

// Data_Warehouse Database on USRCREP02
$DB2_Host="USRCREP02";
$DB2_Database="DATA_WAREHOUSE";
$DB2_UserName="SQL_Admin";
$DB2_Password="killjoy79";

// Data_Warehouse Database on USRCSQLCLS1
$DB20_Host="USRCSQLCLS1";
$DB20_Database="DATA_WAREHOUSE";
$DB20_UserName="SQL_Admin";
$DB20_Password="killjoy79";

// USRC_Main Database on USRC_AmcatSQL
$DB3_Host="USRC_AMCATSQL";
$DB3_Database="USRC_Main";
$DB3_UserName="SQL_Admin";
$DB3_Password="killjoy79";

// CallCenter Database on USRC_AmcatSQL
$DB4_Host="USRC_AMCATSQL";
$DB4_Database="CallCenter";
$DB4_UserName="SQL_Admin";
$DB4_Password="killjoy79";

// MOM Database on USRCAPPSRVR01
$DB5_Host="USRCAPPSRVR01";
$DB5_Database="MailOrderManager";
$DB5_UserName="SQL_Admin";
$DB5_Password="killjoy79";

// PHP_Reports Database on USRC_FILESERVER
$DB10_Host="USRCDATASRVR01";
$DB10_Database="SIMSTest2";
$DB10_UserName="SQL_Admin";
$DB10_Password="killjoy79";

?>
