<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Developer')
//IF ($securitygroup=='Sales')
IF ($securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Executive')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Executive Management Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');

	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<center>WELCOME to the Executive Toolsite. The currently options available are: </center><br/>');
	echo ('<table align="center">');
	echo ('<tr><th COLSPAN=2>Executive Report Options</th></tr>');
	echo ('<tr><td></td><td><a href="./SalesRep_UPS_Tracking_Summary.php">UPS Order Tracking (All)</td></tr>');
	echo ('<tr><td></td><td><a href="./SalesRep_UPS_Tracking_Manager.php">UPS Order Tracking Manager</td></tr>');
	//echo ('<tr><td>3.</td><td><a href="./Acctg_SIMS_Orders.php">SIMS Order List</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Team_Roster_Active.php">Team Roster Manager</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_DNIS.php">Call History: 800 Number</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales ID</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_Campaign.php">Ad Code History: 800 Number</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Search_Order_ID_Approval_Codes.php">Order Approval Codes</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Verification_List.php">Verification Follow-Up List</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Search_Loadbook_Sales_ID.php">Loadbook Lookup</td></tr>');
	echo ('<tr><td></td><td><a href="./VaultMgmt_Search_Cust_ID.php">Loadbook Editor using Customer IDs</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Inventory_Status_Request.php">Inventory Status Request</td></tr>');
	echo ('<tr><td></td><td><a href="./Marketing_Customer_Count.php">Marketing Customer Counts</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Rollover_Exceptions.php">Rollover Exception Report</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Spiff_Report.php">Spiff Report Request</td></tr>');	
	echo ('<tr><td></td><td>Pending Shipment <a href="./Inventory_Pending_Shipment_Detail.php">Detail</td></tr>');
	echo ('<tr><td></td><td><a href="./Inventory_Variance_Report.php">Variance Report</td></tr>');
	echo ('<tr><td></td><td><a href="./SalesRep_Gold_Report_Tracking.php">Gold Report Follow-Up</td></tr>');	
	echo ('<tr><td></td><td><a href="./VaultMgmt_Review.php">SIMS Sales Return Review</td></tr>');
	echo ('<tr><td></td><td><a href="./VaultMgmt_Returns.php">Issues Register</td></tr>');

//	IF(($login=='SSM' || $login=='TQN')  )
//	{
	echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_Roster.php">Media Report: IB Team Reviews</td></tr>');
	echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_Roster_CVR.php">Media Report: OB Team Reviews</td></tr>');		
	//echo ('<tr><td>6.</td><td><a href="./BSS_Call_History_Sales_Rep.php">Blah Blah: Blah ID</td></tr>');
//	}
	
	echo ('<tr><td></td><td><a href="./SalesRep_Gold_Report_Tracking.php">Gold Report Follow-Up</td></tr>');

	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
