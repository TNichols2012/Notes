<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Developer')
//IF ($securitygroup=='Sales')
IF ($securitygroup=='Inventory' || $securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Inventory Management Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');


	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table><br>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table><br>');
	}


	echo ('<center>WELCOME to Inventory Management Toolsite.</center><br/>');
	echo ('<table align="center">');


	echo ('<tr><th COLSPAN=2>Available Options</th></tr>');

	echo ('<tr><td>1.</td><td>Pending Shipment Report (
		<a href="./Inventory_Pending_Shipment_Summary.php">Summary </a>/ 
		<a href="./Inventory_Pending_Shipment_Detail.php">Detail </a>)</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./Inventory_Variance_Report.php">Variance Report</td></tr>');


	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
