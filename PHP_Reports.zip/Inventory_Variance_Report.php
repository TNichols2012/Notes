<?php
session_start();
$debug=0;


/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


IF ($securitygroup=='Inventory' || $securitygroup=='BSS' || $securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////


require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRC_SIMSSERVER
//$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB0_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";

//		ISNULL(MOM_Retail_Price, 0) AS MOM_Retail_Price,
//		ISNULL(SIMS_Retail_Price, 0) AS SIMS_Retail_Price,
//		ISNULL(MOM_Retail_Price, 0) - ISNULL(SIMS_Retail_Price, 0) AS Variance_Price,

function get_Variance_Details ($DB_Conn, $debug) {
	$query="
		SELECT     
		ISNULL(MOM_Stock_ID, 'Not Entered') AS MOM_Stock_ID,
		ISNULL(SIMS_Stock_Number, 'Not Entered') AS SIMS_Stock_Number,
		'$' + CONVERT(varchar(25), (CONVERT(money, ISNULL(MOM_Retail_Price, 0))), 1) AS MOM_Retail_Price,
		ISNULL(MOM_Units_On_Order, 0) AS MOM_Units_On_Order,
		ISNULL(MOM_Units_In_Stock, 0) AS MOM_Units_In_Stock,
		ISNULL(MOM_Units_Committed, 0) AS MOM_Units_Committed,
		ISNULL(MOM_Net_On_Shelf, 0) AS MOM_Net_On_Shelf,
		'$' + CONVERT(varchar(25), (CONVERT(money, ISNULL(SIMS_Retail_Price, 0))), 1) AS SIMS_Retail_Price,
		ISNULL(SIMS_Company_Stock, 0) AS SIMS_Company_Stock,
		ISNULL(SIMS_Inventory_Stock, 0) AS SIMS_Inventory_Stock,
		ISNULL(SIMS_Set_Stock, 0) AS SIMS_Set_Stock,
		ISNULL(SIMS_Package_Stock, 0) AS SIMS_Package_Stock,
		ISNULL(SIMS_Quantity_On_Hand, 0) AS SIMS_Quantity_On_Hand,
		ISNULL(SIMS_Unconfirmed_Stock, 0) AS SIMS_Unconfirmed_Stock,
		ISNULL(SIMS_Unconfirmed_Set_Stock, 0) AS SIMS_Unconfirmed_Set_Stock,
		ISNULL(SIMS_Unconfirmed_Package_Stock, 0) AS SIMS_Unconfirmed_Package_Stock,
		ISNULL(SIMS_Net_On_Shelf, 0) AS SIMS_Net_On_Shelf,
		'$' + CONVERT(varchar(25), (CONVERT(money, (ISNULL(MOM_Retail_Price, 0) - ISNULL(SIMS_Retail_Price, 0)))), 1) AS Variance_Price,
		ISNULL(MOM_Net_On_Shelf, 0)-ISNULL(SIMS_Net_On_Shelf, 0) AS Variance_Quantity,
		GetDate() AS Report_Time
		FROM vw_SIMS_Variance
		WHERE (MOM_Units_In_Stock > 0
			OR SIMS_Net_On_Shelf > 0)
		AND (MOM_Retail_Price <> SIMS_Retail_Price 
			OR MOM_Units_In_Stock <> SIMS_Net_On_Shelf)
		ORDER BY SIMS_Stock_Number, MOM_Stock_ID
		";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Inventory_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);//
		$answer[$i][1]=mssql_result($result, $i, 1);//
		$answer[$i][2]=mssql_result($result, $i, 2);//
		$answer[$i][3]=mssql_result($result, $i, 3);//
		$answer[$i][4]=mssql_result($result, $i, 4);//
		$answer[$i][5]=mssql_result($result, $i, 5);//
		$answer[$i][6]=mssql_result($result, $i, 6);//
		$answer[$i][7]=mssql_result($result, $i, 7);//
		$answer[$i][8]=mssql_result($result, $i, 8);//
		$answer[$i][9]=mssql_result($result, $i, 9);//
		$answer[$i][10]=mssql_result($result, $i, 10);//
		$answer[$i][11]=mssql_result($result, $i, 11);//
		$answer[$i][12]=mssql_result($result, $i, 12);//
		$answer[$i][13]=mssql_result($result, $i, 13);//
		$answer[$i][14]=mssql_result($result, $i, 14);//
		$answer[$i][15]=mssql_result($result, $i, 15);//
		$answer[$i][16]=mssql_result($result, $i, 16);//
		$answer[$i][17]=mssql_result($result, $i, 17);//
		$answer[$i][18]=mssql_result($result, $i, 18);//
		$answer[$i][19]=mssql_result($result, $i, 19);//
	}

	if ($debug==1){
		if (! $DB_Conn) {
			DIE ("Could not connect to Data Warehouse Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Data Warehouse Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Current Inventory Query Looks Like:<br><b> '.$query.'</b><br>');
		echo ('<br>Manager count is: '.$numrows);
		
		echo ('<br>');
	}
	Return $answer;
}; //end function get_Variance_Detail ($DB_Conn, $debug) 


function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}; //end function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor)


function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}; //end function format_tbl_content($content, $width, $alignment="left", $row_bgcolor)

?>
<html>

<head>
</head>

<title>USRCBR SIMS Sales Report</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Send']){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Business Support Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Inventory'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Inventory_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Inventory Department: Variance Report</h2>');

	echo (' <table align="center"><tr><td valign="top">Report Request Sent</td></tr></table><br>');
	$command = "c:\\EXEC_Inve_Variance.bat";
	$output = shell_exec("$command");

	echo ('	<table align="center" class="sortable">	<tr>');
	
	
//	format_tbl_header("", 50, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" rowspan=2><b>Index</b></td>');


	format_tbl_header("MOM", 300, center, $hdr_bgcolor);
	format_tbl_header("SIMS", 300, center, $hdr_bgcolor);

//	format_tbl_header("MOM Price", 250, center, $hdr_bgcolor);
//	format_tbl_header("MOM Quantity", 300, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" colspan=2><b>MOM</b></td>');
	
//	format_tbl_header("SIMS Price", 50, center, $hdr_bgcolor);
//	format_tbl_header("SIMS Quantity", 100, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" colspan=2><b>SIMS</b></td>');

//	format_tbl_header("Price", 75, center, $hdr_bgcolor);
//	format_tbl_header("Quantity", 75, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" colspan=2><b>Variance</b></td>');


	echo ('</tr><tr>');
//	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Stock ID", 300, center, $hdr_bgcolor);
	format_tbl_header("Stock ID", 300, center, $hdr_bgcolor);
	format_tbl_header("Price", 200, center, $hdr_bgcolor);
	format_tbl_header("Quantity", 100, center, $hdr_bgcolor);
	format_tbl_header("Price", 200, center, $hdr_bgcolor);
	format_tbl_header("Quantity", 100, center, $hdr_bgcolor);
	format_tbl_header("Price", 200, center, $hdr_bgcolor);
	format_tbl_header("Quantity", 100, center, $hdr_bgcolor);
	echo ('</tr>');



	$inventory=get_Variance_Details ($DB1_Conn, $debug);

	for ($i=0; $i<$_SESSION['Inventory_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');

	format_tbl_content($i+1, 50, center, $row_bgcolor);		//Index
	format_tbl_content($inventory[$i][0], 300, center, $row_bgcolor);	//MOM Stock ID
	format_tbl_content($inventory[$i][1], 300, center, $row_bgcolor);	//SIMS Stock ID
	
//	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">$'.$inventory[$i][1].'</td> ');
	format_tbl_content($inventory[$i][2], 200, center, $row_bgcolor);	//MOM Price
	format_tbl_content(number_format($inventory[$i][6]), 100, center, $row_bgcolor);	//MOM Quantity
	
//	format_tbl_content(number_format($inventory[$i][4]), 50, center, $row_bgcolor);	
	format_tbl_content($inventory[$i][7], 200, right, $row_bgcolor);	//SIMS Price
	format_tbl_content(number_format($inventory[$i][16]),100 , center, $row_bgcolor);	//SIMS Quantity

//	format_tbl_content($inventory[$i][2] - $inventory[$i][7], 200, right, $row_bgcolor);	//Variance Price
	echo ('<td align="center" bgcolor="'.$row_bgcolor.'" width="100">'.$inventory[$i][17].'</td>');


//	format_tbl_content(number_format($inventory[$i][6]-$inventory[$i][16]),100 , center, $row_bgcolor);	//Variance Quantity
	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">'.$inventory[$i][18].'</td>');


	echo ('</tr><tr>');
	}

	echo ('</tr></table>');




}
else{
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Business Support Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Inventory'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Inventory_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Inventory Department: Variance Report</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		</td><td valign="bottom" align="center">
		<input type="submit" name="Send" value="Send Report" />
		</td><td></td></tr></table><br>');


	echo ('	<table align="center" class="sortable">	<tr>');

//	format_tbl_header("", 50, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" rowspan=2><b>Index</b></td>');


	format_tbl_header("MOM", 300, center, $hdr_bgcolor);
	format_tbl_header("SIMS", 300, center, $hdr_bgcolor);

//	format_tbl_header("MOM Price", 250, center, $hdr_bgcolor);
//	format_tbl_header("MOM Quantity", 300, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" colspan=2><b>MOM</b></td>');
	
//	format_tbl_header("SIMS Price", 50, center, $hdr_bgcolor);
//	format_tbl_header("SIMS Quantity", 100, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" colspan=2><b>SIMS</b></td>');

//	format_tbl_header("Price", 75, center, $hdr_bgcolor);
//	format_tbl_header("Quantity", 75, center, $hdr_bgcolor);
	echo ('<td  align="center" bgcolor="'.$hdr_bgcolor.'" colspan=2><b>Variance</b></td>');


	echo ('</tr><tr>');
//	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Stock ID", 300, center, $hdr_bgcolor);
	format_tbl_header("Stock ID", 300, center, $hdr_bgcolor);
	format_tbl_header("Price", 200, center, $hdr_bgcolor);
	format_tbl_header("Quantity", 100, center, $hdr_bgcolor);
	format_tbl_header("Price", 200, center, $hdr_bgcolor);
	format_tbl_header("Quantity", 100, center, $hdr_bgcolor);
	format_tbl_header("Price", 200, center, $hdr_bgcolor);
	format_tbl_header("Quantity", 100, center, $hdr_bgcolor);
	echo ('</tr>');



	$inventory=get_Variance_Details ($DB1_Conn, $debug);

	for ($i=0; $i<$_SESSION['Inventory_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');

	format_tbl_content($i+1, 50, center, $row_bgcolor);		//Index
	format_tbl_content($inventory[$i][0], 300, center, $row_bgcolor);	//MOM Stock ID
	format_tbl_content($inventory[$i][1], 300, center, $row_bgcolor);	//SIMS Stock ID
	
//	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">$'.$inventory[$i][1].'</td> ');
	format_tbl_content($inventory[$i][2], 200, center, $row_bgcolor);	//MOM Price
	format_tbl_content(number_format($inventory[$i][6]), 100, center, $row_bgcolor);	//MOM Quantity
	
//	format_tbl_content(number_format($inventory[$i][4]), 50, center, $row_bgcolor);	
	format_tbl_content($inventory[$i][7], 200, right, $row_bgcolor);	//SIMS Price
	format_tbl_content(number_format($inventory[$i][16]),100 , center, $row_bgcolor);	//SIMS Quantity

//	format_tbl_content($inventory[$i][2] - $inventory[$i][7], 200, right, $row_bgcolor);	//Variance Price
	echo ('<td align="center" bgcolor="'.$row_bgcolor.'" width="100">'.$inventory[$i][17].'</td>');


//	format_tbl_content(number_format($inventory[$i][6]-$inventory[$i][16]),100 , center, $row_bgcolor);	//Variance Quantity
	echo ('<td align="center" bgcolor="'.$row_bgcolor.'">'.$inventory[$i][18].'</td>');


	echo ('</tr><tr>');
	}

	echo ('</tr></table>');

	} // end if ($in_sales_manager==='')

?>

</html>
