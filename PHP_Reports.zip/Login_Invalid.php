<?php
session_start();
$_SESSION['User_ID']='';
$_SESSION['Security_Level']='';
$_SESSION['Security_Group']='';

?>
<html>

<head>

</head>

<title>USRCBR Invalid Access</title>

<?php

?>

<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>
<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>

<center>Insufficient permissions. Please contact IT Department.</center>
<center><a href="./Login_Secure.php">Retry Login</center>


</html>
