<?php
session_start();
//ini_set("session.gc_maxlifetime", "3000");
require ('DB_Login.php');

$debug=0;

// Connection to USRC_SIMSSERVER
$DB_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to database  

IF ($debug==1){
	IF (! $DB_Conn) {
		DIE ("Could not connect to USRC_SIMSSERVER Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to USRC_SIMSSERVER Database. <br />";}
}

$login = htmlentities($_REQUEST["Login"]);
$password = htmlentities($_REQUEST["Password"]);
$self = htmlentities($_SERVER['PHP_SELF']);

IF ($login===''){
	echo (' <h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>
		<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>
		<form action="'.$self.'" method="POST" valign="center"><center>
		Please Enter a valid <b>SIMS</b> Username and Password.<br/><br/>
		<label>Login: <input type="text" name="Login" /></label>
		<label>Password: <input type="password" name="Password" /></label><br/>
		<input type="submit" value="Login" />
		<input type="reset" value="Clear"/></center>
		</form>
		');
}
ELSE {
	//echo "Authenticating $login<br />";
	$DB_Select= mssql_select_db('SIMS');
	IF (!$DB_Select){
		DIE ("Could not connect to Authentication (Login) Table. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		IF ($debug==1){
			echo ('Connected to Login Table <br/>');
			}
	}


	//clean login and password and defend against injection attack
	
	$clean_login = array();
	$escape_login= array();

	$clean_password = array();
	$length = strlen($login);

	IF (ctype_alnum($login) && $length > 1 && $length <= 5 )
	{
		$clean_login= strtoupper($login);
	}
	ELSE {
		$clean_login= 'Invalid_Login';
	}
	
	IF (ctype_alnum($password) )
	{
		$clean_password= $password;
		$encrypted_password = md5($clean_password);
	}

	$verify_login="Select Username, Password, SecurityLevel FROM dbo.LoginTable WHERE RTRIM(Username)='$clean_login' AND RTRIM(Password)='$encrypted_password'";
	$result=mssql_query($verify_login, $DB_Conn);
	$result_rows=mssql_num_rows($result);
	$result_Username=mssql_result($result, $i, 0);//Username
	$result_Password=mssql_result($result, $i, 1);//Password
	$result_SecurityLevel=mssql_result($result, $i, 2);//SecurityLevel

	switch ($result_SecurityLevel)
	{
		case "Austin Sales":
			$security_group='Sales';
			$security_site='';
		break;	
		case "Austin Sales Manager":
			$security_group='Sales';
			$security_site='Austin';
		break;
	
		case "Senior Sales Manager":
			$security_group='Sales';
			$security_site='Austin';
		break;

		case "Beaumont Sales":
			$security_group='Sales';
			$security_site='';
		break;	
		case "Beaumont Sales Manager":
			$security_group='Sales';
			$security_site='Beaumont';
		break;
		case "C3 Sales":
			$security_group='Sales';
			$security_site='';
		break;	
		case "C3 Sales Manager":
			$security_group='Sales';
			$security_site='C3';
		break;
		case "Business Support":
			$security_group='BSS';
		break;
		case "Business Support Manager":
			$security_group='BSS';
		break;

		default:
		$security_group=$result_SecurityLevel;
	}



	IF ($debug==1){
		echo ('Testing Login Query <br/>');
		echo $verify_login;
		echo ('<br/>encrypted password is: '.$encrypted_password);
		echo ('<br/>Security Group is: '.$security_group);
		echo ('<br/>Security Level is: '.$result_SecurityLevel);
			}

	IF ($result_rows<=0){
		echo (' <h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>
		<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>
		<form action="'.$self.'" method="POST" valign="center"><center>
		Invalid <b>SIMS</b> Username and/or Password. Please re-try.<br/><br/>
		<label>Login: <input type="text" name="Login" /></label>
		<label>Password: <input type="password" name="Password" /></label><br/>
		<input type="submit" value="Login" /><input type="reset" value="Clear"/></center>
		</form>
		');
	}
	ELSE {
		$_SESSION['User_ID']=$clean_login;
		$_SESSION['Cust_ID']='';
		$_SESSION['Index_ID']='';
		$_SESSION['Security_Level']=$result_SecurityLevel;
		$_SESSION['Security_Group']=$security_group;
		$_SESSION['Security_Site']=$security_site;

		IF ($debug==1){
			echo "<br>Session User ID is ".$_SESSION['User_ID'];
			echo "<br>Session Cust ID is ".$_SESSION['Cust_ID'];
			echo "<br>Session Index ID is ".$_SESSION['Index_ID'];
			echo "<br>Session Security Level is ".$_SESSION['Security_Level'];
			echo "<br>Session Security Level is ".$_SESSION['Security_Group'];

			echo "<br> Send to new page here. </br>";
		}
		//header('Location: ./GR_List_2.php');

		IF ($security_group=='BSS')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/BSS_.php\"></head>";
		echo "<BODY>";
		echo "Loading Business Support Services Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Sales')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/SalesRep_.php\"></head>";
		echo "<BODY>";
		echo "Loading Sales Rep Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Administrator')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Administrator_.php\"></head>";
		echo "<BODY>";
		echo "Loading Administrator Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Vault Returns Manager')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/VaultMgmt_.php\"></head>";
		echo "<BODY>";
		echo "Loading Vault Management Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Developer')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Developer_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Development Page..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Executive')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Executive_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Executive Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Marketing')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Marketing_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Marketing Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Inventory')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Inventory_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Inventory Management Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

	//	echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
	//	echo "<html>";
	//	echo "<head>";
	//	echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Login_Invalid.php\"></HEAD>";
	//	echo "<BODY>";
	//	echo "Permission Denied..........<br/>";
	//	echo "Administration Enabled..........<br/>";
	//	echo "Sales Enabled..........<br/>";
	//	echo "Vault Returns Enabled..........<br/>";


	//	echo "</BODY>";
	//	echo "</HTML>";
	}
}

?>

<html>
<head>
<title>PHP Login Authentication</title>

<style type="text/css" media="print">
BODY {display:none;visibility:hidden;}
</style>


</head>

</html>
