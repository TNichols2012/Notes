<?php
session_start();
//ini_set("session.gc_maxlifetime", "3000");
require ('DB_Login.php');

$debug=0;

// Connection to SIMS Database LoginTable
$DB_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to database USRCAPPSRVR01
mssql_select_db("SIMS", $DB_Conn);

//$DB_Conn = mssql_connect ( $DB10_Host, $DB10_UserName, $DB10_Password, TRUE ); //connect to database USRCAPPSRVR01
//mssql_select_db("SIMSTest2", $DB_Conn);


IF ($debug == 1){
	IF (! $DB_Conn) {
		DIE ("Could not connect to ".$DB10_Host." Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to ".$DB10_Host." Database. <br />";}

	$DB_Select1 = mssql_select_db('SIMSTest2', $DB_Conn);
	IF (!$DB_Select1){
		DIE ("Could not connect to Authentication (Login) Table on ".$DB10_Host.". <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo ("Connected to Login Table on ".$DB10_Host."<br/>");	
	}
}

$DB_Conn2 = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to database USRCREP02 
mssql_select_db("Data_Warehouse", $DB_Conn2); 

IF ($debug == 1){
	IF (! $DB_Conn2) {
		DIE ("Could not connect to ".$DB2_Host." Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to ".$DB2_Host." Database. <br />";}

	$DB_Select2 = mssql_select_db('Data_Warehouse', $DB_Conn2);
	IF (!$DB_Select2){
		DIE ("Could not connect to Data_Warehouse on ".$DB2_Host.". <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo ("Connected to Data_Warehouse on ".$DB2_Host."<br/>");	
	}
}

function Get_Login_Data ($DB_Conn2, $in_Sales_ID, $debug)
	{
        $sp = mssql_init ( "dbo.usp_Media_Report_Request_Team", $DB_Conn2 ); //init stored procedure  
	mssql_bind ( $sp, '@in_Sales_ID', $in_Sales_ID, SQLVARCHAR, false, false, 5);

	mssql_free_result($result);
	$result = mssql_execute($sp);

	$numrows = mssql_num_rows($result);
	$_SESSION['List_Count'] = $numrows;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][3]);

		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][3]);

//		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][3]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result));



	if ($debug==1){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp);
		echo ('<br>results: '.$result);
		echo ('<br>numrows: '.$numrows);
		echo ('<br>Searching for: '.$in_Sales_ID);
		echo ('<br>database connection: '.$DB_Conn2);

		if (! $DB_Conn2) {
			DIE ("<br>Could not connect to USRCREP02 Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to USRCREP02 Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Login_Data ($DB_Conn2, $in_Sales_ID, $debug)


$login 		= htmlentities($_REQUEST["Login"]);
$password 	= htmlentities($_REQUEST["Password"]);
$self 		= htmlentities($_SERVER['PHP_SELF']);

IF ($login===''){
	echo (' <h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>
		<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>
		<form action="'.$self.'" method="POST" valign="center"><center>
		Please Enter a valid <b>SIMS</b> Username and Password.<br/><br/>
		<label>Login: <input type="text" name="Login" /></label>
		<label>Password: <input type="password" name="Password" /></label><br/>
		<input type="submit" value="Login" />
		<input type="reset" value="Clear"/></center>
		</form>
		');
}
ELSE {

	//clean login and password and defend against injection attack
	
	$clean_login = array();
	$escape_login= array();

	$clean_password = array();
	$length = strlen($login);

	IF (ctype_alnum($login) && $length > 1 && $length <= 5 )
	{
		$clean_login= strtoupper($login);
	}
	ELSE {
		$clean_login= 'Invalid_Login';
	}
	
	IF (ctype_alnum($password) )
	{
		$clean_password		= $password;
		$encrypted_password 	= md5($clean_password);
	}

	$verify_login		= "Select Username, Password, SecurityRole, RoomCode FROM dbo.LoginTable WHERE RTRIM(Username)='$clean_login' AND RTRIM(Password)='$encrypted_password'";
	$result			= mssql_query($verify_login, $DB_Conn);
	$result_rows		= mssql_num_rows($result);
	$result_Username	= mssql_result($result, $i, 0); //Username
	$result_Password	= mssql_result($result, $i, 1); //Password
	$result_SecurityRole	= mssql_result($result, $i, 2); //SecurityLevel
	$result_RoomCode	= mssql_result($result, $i, 3); //RoomCode


	switch ($result_RoomCode)
	{
		case "AU":
			$security_site='Austin';
		break;	
		
		case "BM":
			$security_site='Beaumont';
		break;

		default:
		$security_group=$result_RoomCode;
	}


	switch ($result_SecurityRole)
	{
		case "Sales":
			$security_group='Sales';
		break;	
		
		case "Sales Manager":
			$security_group='Sales_Managers';
		break;
	
		case "Senior Sales Manager":
			$security_group='Sales_Operations';
		break;
		
		case "Business Support":
			$security_group='BSS';
		break;
		
		case "Business Support Manager":
			$security_group='BSS';
		break;
		
		case "Verification":
			$security_group='BSS';
			$security_site='';			
		break;

		default:
		$security_group=$result_SecurityRole;
	}

	$user_data 	= Get_Login_Data($DB_Conn2, $clean_login, $debug);
	$sales_rep_name	= $user_data[0][1];
	$sales_manager	= $user_data[0][2];
	$sales_team	= $user_data[0][3];
	$isManager	= $user_data[0][4];
	$myTeam		= $user_data[0][5];

	IF ($debug==1){
		echo ('Testing Login Query <br/>');
		echo $verify_login;
		echo ('<br/>encrypted password is: '.$encrypted_password);
		echo ('<br/>Security Group is: '.$security_group);
		echo ('<br/>Security Level is: '.$result_SecurityLevel);
			}

	IF ($result_rows<=0){
		echo (' <h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>
		<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>
		<form action="'.$self.'" method="POST" valign="center"><center>
		Invalid <b>SIMS</b> Username and/or Password. Please re-try.<br/><br/>
		<label>Login: <input type="text" name="Login" /></label>
		<label>Password: <input type="password" name="Password" /></label><br/>
		<input type="submit" value="Login" /><input type="reset" value="Clear"/></center>
		</form>
		');
	}
	ELSE {

		$_SESSION['User_ID']		= $clean_login;
		$_SESSION['Cust_ID']		= '';
		$_SESSION['Index_ID']		= '';
		$_SESSION['Security_Level']	= $result_SecurityLevel;
		$_SESSION['Security_Group']	= $security_group;
		$_SESSION['Security_Site']	= $security_site;


		$_SESSION['Sales_Manager']	= $sales_manager;
		$_SESSION['Sales_Team']		= $sales_team;
		$_SESSION['Sales_Rep_Name']	= $sales_rep_name;
		$_SESSION['isManager']		= $isManager;
		$_SESSION['myTeam']		= $myTeam;

		IF ($debug==2){
			echo "<br>Session User ID is ".$_SESSION['User_ID'];
			echo "<br>Session Cust ID is ".$_SESSION['Cust_ID'];
			echo "<br>Session Index ID is ".$_SESSION['Index_ID'];
			echo "<br>Session Security Level is ".$_SESSION['Security_Level'];
			echo "<br>Session Security Level is ".$_SESSION['Security_Group'];
			echo "<br>Session Sales Manager is ".$_SESSION['Sales_Manager'];
			echo "<br>Session Sales Team is ".$_SESSION['Sales_Team'];
			echo "<br>Session Sales Rep Name is ".$_SESSION['Sales_Rep_Name'];
			echo "<br>Session isManager? ".$_SESSION['isManager'];
			echo "<br>Session myTeam? ".$_SESSION['myTeam'];

			echo "<br> Send to new page here. </br>";
		}
		//header('Location: ./GR_List_2.php');

		IF ($security_group=='BSS')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/BSS_.php\"></head>";
		echo "<BODY>";
		echo "Loading Business Support Services Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Sales')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/_SalesReps_.php\"></head>";
		echo "<BODY>";
		echo "Loading Sales Rep Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Sales_Managers')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/_SalesManagers_.php\"></head>";
		echo "<BODY>";
		echo "Loading Sales Managers Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Sales_Operations')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/_SalesOperations_.php\"></head>";
		echo "<BODY>";
		echo "Loading Sales Operations Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}
	
		IF ($security_group=='Administrator')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Administrator_.php\"></head>";
		echo "<BODY>";
		echo "Loading Administrator Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Vault Returns Manager')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/VaultMgmt_.php\"></head>";
		echo "<BODY>";
		echo "Loading Vault Management Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Developer')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Developer_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Development Page..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Executive')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Executive_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Executive Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Marketing')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Marketing_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Marketing Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

		IF ($security_group=='Inventory')
		{
		echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
		echo "<html>";
		echo "<head>";
		echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Inventory_.php\"></HEAD>";
		echo "<BODY>";
		echo "Loading Inventory Management Tools..........";
		echo "</BODY>";
		echo "</HTML>";
		}

 
	//	echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
	//	echo "<html>";
	//	echo "<head>";
	//	echo "<meta http-equiv=\"REFRESH\" content=\"0;url=http://usrcrep01/php_reports/Login_Invalid.php\"></HEAD>";
	//	echo "<BODY>";
	//	echo "Permission Denied..........<br/>";
	//	echo "Administration Enabled..........<br/>";
	//	echo "Sales Enabled..........<br/>";
	//	echo "Vault Returns Enabled..........<br/>";


	//	echo "</BODY>";
	//	echo "</HTML>";
	}
}

?>

<html>
<head>
<title>PHP Login Authentication</title>

<style type="text/css" media="print">
BODY {display:none;visibility:hidden;}
</style>


</head>

</html>
