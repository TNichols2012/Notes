<html>

Pending Shipment Report Re-run, per request....<br><br>

Please use the file <br><br>
<b>USRCBR_2008Daily_Inventory_Report.xls</b> <br><br>found at: <br><br>

<a href="\\Usrc_fileserver\Inventory\Pending_Shipment\">\\Usrc_fileserver\Inventory\Pending_Shipment\  </a>
<br>
<br>

until IT has a chance to generate the main file. <br>
It should contain the current date/time.  
<br>
<br>
<br>
<br>
</html>

<?php
function call_Tool ($path,$file) {
	$call = $path.$file;
	shell_exec ($call);
	echo "Call has: ".$call;
}

$location = "c:\\";
$filename = "Run_PS_Report.bat";

$command = "c:\\Run_PS_Report.bat";
$output = shell_exec("$command");
//echo(nl2br($output)); 

//echo "Location string is: ".$location."<br>";
//echo "Filename string is: ".$filename."<br><br>";

//echo "Command string is: ".$command."<br><br>";

?>

