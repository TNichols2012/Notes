<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Developer')
//IF ($securitygroup=='Sales')
IF ($securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Executive' || $securitygroup=='Marketing')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Marketing Management Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');

	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<center>WELCOME to the Marketing Toolsite. The currently options available are: </center><br/>');
	echo ('<table align="center">');
	echo ('<tr><th COLSPAN=2>Marketing Report Options</th></tr>');
	echo ('<tr><td>1.</td><td><a href="./BSS_Call_History_DNIS.php">Call History: 800 Number</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td>3.</td><td><a href="./Marketing_Customer_Count.php">Customer Counts</td></tr>');



	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
