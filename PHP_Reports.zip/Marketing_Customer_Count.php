<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Vault Returns Manager')
//IF ($securitygroup=='Administration')
IF ($securitygroup=='Marketing' || $securitygroup=='Administrator' || $securitygroup=='Developer' || $securitygroup=='Executive')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}

/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB3_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB3_Conn );


define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";


if ($debug==1){
	if (! $DB3_Conn) {
		DIE ("Could not connect to $DB2_Host Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to $DB2_Host Database. <br />";
	}
}

function get_Mail_Count($DB3_Conn, $gross, $debug) {

	$query="
		SELECT
		Count(*) AS C	
		FROM vw_Request_Mailing_List
		WHERE Gross >='".$gross."'
		";

	$result=mssql_query($query, $DB3_Conn);
	$numrows=mssql_num_rows($result);

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);//custnum
	}

	if ($numrows == 0) {
		$answer[$i][0]='None Found.';
	}

	if ($debug==1){
		if (! $DB3_Conn) {
			DIE ("Could not connect to AmcatSQL USRC_Main Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "in get_Notes Function: Connected Fine to AmcatSQL USRC_Main Database. <br />";
		}
		echo ('<br>Loadbook Search Query Looks Like:<br> '.$query);
		echo ('<br>$numrows Looks Like:<br> '.$numrows);
		echo ('<br>$answer Looks Like:<br> '.$answer);
		echo ('<br>$i Looks Like:<br> '.$i);
		echo ('<br>$answer[$i][0] Looks Like:<br> '.$answer[$i][0]);
		echo ('<br>$answer[1][0] Looks Like:<br> '.$answer[1][0]);
		echo ('<br>$answer[0][0] Looks Like:<br> '.$answer[0][0]);

	}
	Return $answer;
};

function get_eMail_Count($DB3_Conn, $gross, $debug) {

	$query="
		SELECT
		Count(*) AS C	
		FROM vw_Request_eMail_List
		WHERE Gross >='".$gross."'
		";

	$result=mssql_query($query, $DB3_Conn);
	$numrows=mssql_num_rows($result);

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);//custnum
	}

	if ($numrows == 0) {
		$answer[$i][0]='None Found.';
	}

	if ($debug==1){
		if (! $DB3_Conn) {
			DIE ("Could not connect to AmcatSQL USRC_Main Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "in get_Notes Function: Connected Fine to AmcatSQL USRC_Main Database. <br />";
		}
		echo ('<br>Loadbook Search Query Looks Like:<br> '.$query);
		echo ('<br>$numrows Looks Like:<br> '.$numrows);
		echo ('<br>$answer Looks Like:<br> '.$answer);
		echo ('<br>$i Looks Like:<br> '.$i);
		echo ('<br>$answer[$i][0] Looks Like:<br> '.$answer[$i][0]);
		echo ('<br>$answer[1][0] Looks Like:<br> '.$answer[1][0]);
		echo ('<br>$answer[0][0] Looks Like:<br> '.$answer[0][0]);

	}
	Return $answer;
};


function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" bgcolor="');
	global $tbl_bgcolor;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}




?>

<html>

<head>


</head>
<title>USRCBR Loadbook Search Tool</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_LB_Search"]='';
}

if ($debug==1){
	echo ('<br>local enter Date : '.$in_enter_date);
}

 

/***************MAIN CODE STARTS HERE ********************/


if ($_POST["in_LB_Search"]==''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	
	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	
	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Marketing_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
}

	echo ('	<h2 align=center>Marketing Tool: Customer Count Lookup</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>Enter Gross Sales Minimum<br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></form></table>');

	
	echo ('<table align="center" class="sortable" width=100><tr>');
	format_tbl_header("Mail", 100, center);
	format_tbl_header("eMail", 100, center);
	echo ('</tr>');
	echo ('<tr>');
	echo ('</tr>');
	echo ('</table>');

} // end if ($_POST["in_LB_Search"]=='')

else {
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Marketing'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Marketing Tool: Customer Count Lookup</h2>');

	echo (' <table align="center"><tr><td align="center" valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<label>Enter Gross Sales Minimum<br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center" value="'.$_POST["in_LB_Search"].'"><br/>
		<input type="submit" name="Search" value="Search" /></td>');
	echo ('	</tr></form></table>');


	echo ('<table align="center" class="sortable" width=100><tr>');
//	format_tbl_header("Index", 50, center);
	format_tbl_header("Mail", 100, center);
	format_tbl_header("eMail", 100, center);
//	format_tbl_header("Notes", 450, center);

	echo ('</tr>');

	$list1=get_Mail_Count($DB3_Conn, $_POST["in_LB_Search"], $debug);
	$list2=get_eMail_Count($DB3_Conn, $_POST["in_LB_Search"], $debug);

	echo ('<tr>');
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index
	format_tbl_content(number_format($list1[0][0]), 100, center, $row_bgcolor);	//Cust_ID
	format_tbl_content(number_format($list2[0][0]), 100, center, $row_bgcolor);	//Cust_ID
//	format_tbl_content($list[1][$i], 450, left, $row_bgcolor);	//Cust_ID

	echo ('</tr>');
	

	echo ('	</table>');



} //end else: if ($_POST["in_LB_Search"]=='')

	If ($debug==1) {
		IF (! $DB3_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB3_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB3_UserName.'</b><br>');
			echo ('Database: <b>'.$DB3_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>



