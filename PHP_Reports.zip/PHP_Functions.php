<?php

function isDate($in_Date) {
	$bln_Valid = TRUE;
	// check format mm/dd/yyyy
/*
	switch ($in_Date){
		case (!ereg ("^[0-9]{2}/[0-9]{2}/[0-9]{4}$", $in_Date)):
			$bln_Valid = FALSE;
			echo ('<br>Invalid Date');
			break;
		case (!ereg ("^[0-9]{2}/[0-9]{1}/[0-9]{4}$", $in_Date)):
			$bln_Valid = FALSE;
			echo ('<br>Invalid Date');
			break;
		case (!ereg ("^[0-9]{1}/[0-9]{1}/[0-9]{4}$", $in_Date)):
			$bln_Valid = FALSE;
			echo ('<br>Invalid Date');
			break;
		default:
			$arr_Date = explode("/", $in_Date); // break up date by slash
			$int_Day = $arr_Date[0];
			$int_Month = $arr_Date[1];
			$int_Year = $arr_Date[2];
			$int_IsDate = checkdate($int_Month, $int_Day, $int_Year);
			if(!$int_IsDate){
		        	$bln_Valid = FALSE;
			} // end if(!$int_IsDate)

	} //end switch
 */

	if(!ereg ("^[0-1][0-9]/[0-3][0-9]/[0-9]{4}$", $in_Date)) 
	{
		$bln_Valid = FALSE;
	}
	else 
	{
		$arr_Date = explode("/", $in_Date); // break up date by slash

		$int_Month = $arr_Date[0];
		$int_Day = $arr_Date[1];
		$int_Year = $arr_Date[2];

		$int_IsDate = checkdate($int_Month, $int_Day, $int_Year);
		if(! $int_IsDate)
		{
		        $bln_Valid = FALSE;
		} // end if(!$int_IsDate)
	} //end else 
	return ($bln_Valid);



} // end function isDate()


?>
