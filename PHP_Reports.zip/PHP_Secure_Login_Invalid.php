<?php
session_start();
$_SESSION['User_ID']='';
$_SESSION['Security_Level']='';
$_SESSION['Security_Group']='';

?>
<html>

<head>

</head>

<title>USMR Invalid Access</title>

<?php

?>

<h1><center>United States Money Reserve</center></h1><br/>
<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>

<center>Insufficient permissions. Please contact IT Department.</center>
<center><a href="./PHP_Secure_Login.php">Retry Login</center>


</html>
