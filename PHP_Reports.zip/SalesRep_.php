<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


$sales_manager	=$_SESSION['Sales_Manager'];
$sales_team	=$_SESSION['Sales_Team'];
$sales_rep_name	=$_SESSION['Sales_Rep_Name'];
$isManager	=$_SESSION['isManager'];
$myTeam		=$_SESSION['myTeam'];



//IF ($securitygroup=='Developer')
IF ($securitylevel == 'Executive' || $securitygroup=='Sales' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administrator')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Sales Management Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');

	if($securitygroup=='Developer')
	{
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<center>WELCOME to the Sales Rep Toolsite. The currently available options are: </center><br/>');
	echo ('<table align="center">');
	echo ('<tr><td></td><td><a href="./SalesRep_Gold_Report_Tracking.php">Gold Report Follow-Up</td></tr>');
	echo ('<tr><td></td><td><a href="./SalesRep_UPS_Tracking_Summary.php">UPS Order Tracking</td></tr>');
	//echo ('<tr><td>2.</td><td>UPS Order Tracking <i>(Temporarily Unavailable)</i></td></tr>');

	IF(($login=='SSM' || $login=='TQN')  )
	{
		echo ('<tr><td></td><td><a href="./BSS_Call_History_ContactNumber.php">Contact History: Contact Number</td></tr>');
		echo ('<tr><td></td><td><a href="./BSS_Call_History_DNIS.php">Contact History: 800 Number</td></tr>');
		echo ('<tr><td></td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales Rep ID</td></tr>');
		//echo ('<tr><td>6.</td><td><a href="./SalesRep_Media_Report_Team_Roster.php">Media Report: IB Team Reviews</td></tr>');
		//echo ('<tr><td>7.</td><td><a href="./SalesRep_Media_Report_Team_Roster_OB.php">Media Report: OB Team Reviews</td></tr>');
	}
	ELSE 
	{
		IF($isManager == 'Yes' )
		{
			echo ('<tr><td></td><td><a href="./BSS_Call_History_ContactNumber.php">Contact History: Contact Number</td></tr>');
			echo ('<tr><td></td><td><a href="./BSS_Call_History_DNIS.php">Contact History: 800 Number</td></tr>');
			echo ('<tr><td></td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales Rep ID</td></tr>');

			IF (($login == 'KO'))
			{
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team.php?Sales_Team=Team%20Ozen&Sales_Manager=Kenan%20Ozen">Media Report: IB Team Reviews (Ozen)</td></tr>');
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_CVR.php?Sales_Team=Team%20Ozen&Sales_Manager=Kenan%20Ozen">Media Report: OB Team Reviews(Ozen)</td></tr>');
			}
			ELSE
			{
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team.php?Sales_Team='.$myTeam.'&Sales_Manager='.$sales_rep_name.'">Media Report: IB Team Reviews</td></tr>');
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_CVR.php?Sales_Team='.$myTeam.'&Sales_Manager='.$sales_rep_name.'">Media Report: OB Team Reviews</td></tr>');
			}

			IF (($login == 'JF' || $login == 'TQN'))
			{
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team.php?Sales_Team=Team%20Granger&Sales_Manager=Lee%20Granger">Media Report: IB Team Reviews (Granger)</td></tr>');
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_CVR.php?Sales_Team=Team%20Granger&Sales_Manager=Lee%20Granger">Media Report: OB Team Reviews(Granger)</td></tr>');
			}

			IF (($login == 'BN' || $login == 'TQN'))
			{
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team.php?Sales_Team=Team%20Ozen&Sales_Manager=Kenan%20Ozen">Media Report: IB Team Reviews (Ozen)</td></tr>');
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_CVR.php?Sales_Team=Team%20Ozen&Sales_Manager=Kenan%20Ozen">Media Report: OB Team Reviews(Ozen)</td></tr>');
			}

			IF (($login == 'SRD' || $login == 'TQN'))
			{
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team.php?Sales_Team=Team%20Montoya&Sales_Manager=Marcus%20Montoya">Media Report: IB Team Reviews (Montoya)</td></tr>');
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_CVR.php?Sales_Team=Team%20Montoya&Sales_Manager=Marcus%20Montoya">Media Report: OB Team Reviews(Montoya)</td></tr>');
			}

			IF (($login == 'PEK' || $login == 'TQN'))
			{
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team.php?Sales_Team=Team%20Shakespeare&Sales_Manager=Steven%20Shakespeare">Media Report: IB Team Reviews (Shakespeare)</td></tr>');
				echo ('<tr><td></td><td><a href="./SalesRep_Media_Report_Team_CVR.php?Sales_Team=Team%20Shakespeare&Sales_Manager=Steven%20Shakespeare">Media Report: OB Team Reviews(Shakespeare)</td></tr>');
			}


		}
	}


	


	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
