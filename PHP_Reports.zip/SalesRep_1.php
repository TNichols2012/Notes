<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


$sales_manager	=$_SESSION['Sales_Manager'];
$sales_team	=$_SESSION['Sales_Team'];
$sales_rep_name	=$_SESSION['Sales_Rep_Name'];
$isManager	=$_SESSION['isManager'];
$myTeam		=$_SESSION['myTeam'];



//IF ($securitygroup=='Developer')
IF ($securitylevel == 'Executive' || $securitygroup=='Sales' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administrator')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Sales Management Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');

	if($securitygroup=='Developer')
	{
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<center>WELCOME to the Sales Rep Toolsite. The currently options available are: </center><br/>');
	echo ('<table align="center">');
	echo ('<tr><td>1.</td><td><a href="./SalesRep_Gold_Report_Tracking.php">Gold Report Follow-Up</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./SalesRep_UPS_Tracking_Summary.php">UPS Order Tracking</td></tr>');
	//echo ('<tr><td>2.</td><td>UPS Order Tracking <i>(Temporarily Unavailable)</i></td></tr>');


	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
