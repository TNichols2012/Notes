<?php

$debug=0;

$firstname=$_GET['FirstName'];
$grosssales=$_GET['GrossSales'];
$custnum=$_GET['CustomerNumber'];
$phonenumber=$_GET['PhoneNumber'];
$lastname=$_GET['LastName'];
$agentname=$_GET['AgentName'];
$callstart=$_GET['CallStart'];
$callend=$_GET['CallEnd'];
$city=$_GET['City'];
$state=$_GET['State'];
$zip=$_GET['Zip'];
$fullname = $firstname.' ';
$fullname .= $lastname.' ';

if ($debug==1)
{
	echo "Debugging On...<br><br>";
	echo "Customer Name: ".$fullname."<br>";
	echo "Gross Sales: ".$grosssales."<br>";
	echo "Cust #: ".$custnum."<br>";
	echo "Phone #: ".$phonenumber."<br>";
	echo "First Name: ".$firstname."<br>";
	echo "Last Name: ".$lastname."<br>";
	echo "City: ".$city."<br>";
	echo "State: ".$state."<br>";
	echo "Zip: ".$zip."<br>";
	echo "Agent: ".$agentname."<br>";
	echo "Call Start: ".$callstart."<br>";
	echo "Call End: ".$callend."<br>";
}
?>

<HTML>
<HEAD>
<script language=VBScript src="../ScriptSource.htm"></script>
<script language=VBScript src="../CheckChange.vbs"></script>
<META NAME="GENERATOR" Content="Microsoft DHTML Editing Control">
<TITLE></TITLE>
</HEAD>

<!--
<BODY style="filter:progid:DXImageTransform.Microsoft.Gradient(endColorstr='#C0CFE2', startColorstr='#FFFFFF', gradientType='0');"> 
-->

<BODY style="filter:progid:DXImageTransform.Microsoft.Gradient(endColorstr='#C0CFE2', startColorstr='#000000', gradientType='1');"> 

<P align=center><FONT face=Tahoma color=#0000ff size=7><STRONG><U>CUSTOMER CONTACT (MANUAL DIAL)</U></STRONG></FONT>
<BR>
</P>

<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face=Arial size=5><STRONG><FONT color=#008000>Customer Name:</FONT> 
</STRONG></FONT><INPUT
<?php
echo "value=".$firstname.'_'.$lastname;
?> 
style="WIDTH: 284px; HEIGHT: 22px" readOnly size=48 
ExtAttrs='<Validations><PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" /></Validations>'>
</P>

<P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<FONT face=Verdana size=2><STRONG><U><FONT color=#804ffff size=4>CUSTOMER INFO</FONT></U></STRONG></FONT>
</P>

<P><FONT face=Arial size=4 color=#ffffff>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gross Sales $&nbsp;<INPUT
<?php
echo "value=".$grosssales;
?> 
style="WIDTH: 354px; HEIGHT: 22px" readonly size=43
ExtAttrs='<Validations><PhysicalValidation ReadOnly="True" Strong="True" Type="Float" NullAllowed="True" MaxLength="0" Mask="" KeepMaskMarkers="False" /></Validations>'><BR>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;M.O.M. 
Customer #&nbsp;<INPUT
<?php
echo "value=".$custnum;
?> 
style="WIDTH: 311px; HEIGHT: 22px" readonly size=38
ExtAttrs='<Validations><PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="12" Mask="" KeepMaskMarkers="False" /></Validations>'></STRONG></STRONG><BR><FONT 
face=Arial size=4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Phone&nbsp;#&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<INPUT
<?php
echo "value=".$phonenumber;
?> 
style="WIDTH: 375px; HEIGHT: 22px" readOnly size=48 
ExtAttrs='<Validations><PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="50" Mask="" KeepMaskMarkers="False" /></Validations>'></FONT><STRONG></STRONG><BR><FONT 
face=Arial size=4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;First Name&nbsp; </FONT><INPUT
<?php
echo "value=".$firstname;
?> 
style="WIDTH: 375px; HEIGHT: 22px" readOnly size=47 
ExtAttrs='<Validations><PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="50" Mask="" KeepMaskMarkers="False" /></Validations>'><BR><FONT 
face=Arial size=4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Last Name&nbsp;&nbsp;</FONT><INPUT
<?php
echo "value=".$lastname;
?> 
style="WIDTH: 376px; HEIGHT: 22px" readOnly size=48 
ExtAttrs='<Validations><PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="50" Mask="" KeepMaskMarkers="False" /></Validations>'>

<FONT 
face=Arial size=4>&nbsp;&nbsp;&nbsp;<BR>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<INPUT
<?php
echo "value=".$city;
?> 
style="WIDTH: 376px; HEIGHT: 22px" readOnly size=47 
ExtAttrs='<Validations><PhysicalValidation ReadOnly="False" Strong="True" Type="String" NullAllowed="True" MaxLength="30" Mask="" KeepMaskMarkers="False" /></Validations>'></FONT><FONT 
face=Arial size=4>&nbsp;<BR>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;State&nbsp;&nbsp;&nbsp;&nbsp; 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT><INPUT
<?php
echo "value=".$state;
?>  
style="WIDTH: 52px; HEIGHT: 22px" readOnly size=6 
ExtAttrs='<Validations><PhysicalValidation ReadOnly="False" Strong="True" Type="String" NullAllowed="True" MaxLength="2" Mask="" KeepMaskMarkers="False" /></Validations>'><FONT 
face=Arial size=4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
Zip&nbsp;&nbsp; &nbsp;</FONT><INPUT 
<?php
echo "value=".$zip;
?> 
style="WIDTH: 93px; HEIGHT: 22px" readOnly size=12 
ExtAttrs='<Validations><PhysicalValidation ReadOnly="False" Strong="True" Type="String" NullAllowed="True" MaxLength="10" Mask="" KeepMaskMarkers="False" /></Validations>'><FONT 
face=Arial size=4>&nbsp;&nbsp;&nbsp;
</FONT>
<BR>
<BR>
<BR>
<BR>
</P>


<P>
&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<FONT face=Verdana size=2><STRONG><U><FONT color=#804ffff size=4>FINISH CALL OPTIONS</FONT></U></STRONG></FONT>
</P>


<!--
EXAMPLE:

<P><FONT face=Verdana size=2><STRONG><FONT color=#0000ff size=4>SALES<BR>

<BUTTON id=ClickID style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="UpdateDB(1)">
<FONT color=#0000ff><FONT size=+0>Click Here!</FONT></FONT>
</BUTTON>

</P>

END EXAMPLE!
-->

<P><FONT face=Verdana size=2><STRONG><FONT color=#0000ff size=4>SALES<BR>

<BUTTON id=QuickDispo1 title=C style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(1)}">
<FONT color=#0000ff><FONT size=+0><U>C</U>ertified</FONT></FONT>
</BUTTON>
&nbsp; 
&nbsp;
<BUTTON id=QuickDispo1 title=B style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(2)}">
<FONT color=#0000ff><FONT size=+0><U>B</U>ullion</FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=M style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(3)}">
<FONT color=#0000ff><FONT size=+0><U>M</U>ixed</FONT></FONT>
</BUTTON>
<BR>
<BR>
<BUTTON id=QuickDispo1 title=I style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(4)}">
<FONT color=#0000ff><FONT size=+0><U>I</U>nfo Sent</FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=N style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(5)}">
<FONT color=#0000ff><FONT size=+0><U>N</U>o Deal</FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=G style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(6)}">
<FONT color=#0000ff><FONT size=+0>Left Messa<U>g</U>e</FONT></FONT>
</BUTTON>
<BR>
<BR>
<BUTTON id=QuickDispo1 title=O style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(7)}">
<FONT color=#0000ff><FONT size=+0>N<U>o</U> Answer</FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=J style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(8)}">
<FONT color=#0000ff><FONT size=+0><U>J</U>unk Call</FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=W style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(9)}">
<FONT color=#0000ff><FONT size=+0><U>W</U>ill Call Back</FONT></FONT>
</BUTTON>
<BR>
<BR>
<BR>
</P>



<P><FONT face=Verdana size=2><STRONG><FONT color=#804000 size=4>SUPPORT<BR>

<BUTTON id=QuickDispo1 title=S style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(10)}">
<FONT color=#804000><FONT size=+0>Business <U>S</U>upport</FONT></FONT>
</BUTTON>
&nbsp; 
&nbsp;
<BUTTON id=QuickDispo1 title=R style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(11)}">
<FONT color=#804000><FONT size=+0>Customer <U>R</U>elations<FONT face=Verdana>*</FONT></FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=E style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(12)}">
<FONT color=#804000><FONT size=+0>CCM R<U>e</U>moval<FONT face=Verdana>*</FONT></FONT></FONT>
</BUTTON>
<BR>
<FONT color=#804000><FONT size=3><FONT size=2>&nbsp;</FONT>*</FONT>Requires a SIMS submission</FONT></FONT></STRONG><STRONG><FONT face=Verdana size=2><FONT color=#ff8000 size=4>
<BR>
<BR>
<BR>
</P>

<P><FONT face=Verdana size=2><STRONG><FONT color=#800040 size=4>SALES MANAGER ONLY<BR>

<BUTTON id=QuickDispo1 title=V style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(13)}">
<FONT color=#800040><FONT size=+0><U>V</U>erification</FONT></FONT>
</BUTTON>
&nbsp; 
&nbsp;
<BUTTON id=QuickDispo1 title=A style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(14)}">
<FONT color=#800040><FONT size=+0>Rel<U>a</U>tionship Building</FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=T style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(15)}">
<FONT color=#800040><FONT size=+0>O<U>t</U>her</FONT></FONT>
</BUTTON>
<BR>
<BR>
<BR>
</P>

<P><FONT face=Verdana size=2><STRONG><FONT color=#008000 size=4>BUCKET REMOVAL<BR>

<BUTTON id=QuickDispo1 title=D style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(16)}">
<FONT color=#008000><FONT size=+0><U>D</U>eceased</FONT></FONT>
</BUTTON>
&nbsp; 
&nbsp;
<BUTTON id=QuickDispo1 title=L style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(17)}">
<FONT color=#008000><FONT size=+0>Do Not Ca<U>l</U>l</FONT></FONT>
</BUTTON>
&nbsp;
&nbsp;
<BUTTON id=QuickDispo1 title=I style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(18)}">
<FONT color=#008000><FONT size=+0>Do Not <U>M</U>ail</FONT></FONT>
</BUTTON>
<BR>
<BR>
<BUTTON id=QuickDispo1 title=T style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(19)}">
<FONT color=#008000><FONT size=+0>Do No<U>t</U> Call or Mail</FONT></FONT>
</BUTTON>
&nbsp; 
&nbsp;
<BUTTON id=QuickDispo1 title=B style="FONT-WEIGHT: bold; WIDTH: 200px; COLOR: red; HEIGHT: 24px" onclick="javascript: if(AgentDisp.CheckFields(parent.document)){DispositionCall(20)}">
<FONT color=#008000><FONT size=+0><U>B</U>ad Phone Number</FONT></FONT>
</BUTTON>
</P>
</BODY>
</HTML>
