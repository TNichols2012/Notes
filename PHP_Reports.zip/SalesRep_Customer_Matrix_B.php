<?php

require ('DB_Login.php');

$debug=2;

$db_con = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); 
mssql_select_db ( $DB2_Database, $db_con );

If ($debug==1) 
{	
	IF (! $db_con) 
	{
		DIE ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE 
	{
		echo "Debug Mode: ON <br> Successfully connected to database. <br />";
	}
};

	$custnum = $_GET['Custnum']; //get custnum from url eg http://blob.com/file.php?custnum=403030

	//echo $custnum;


function get_Cust_Info($custnum, $debug){

	$DB2_Host="USRCREP02";
	$DB2_Database="DATA_WAREHOUSE";
	$DB2_UserName="SQL_Admin";
	$DB2_Password="AustinDat@";

	$DB_Conn = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); // Data_Warehouse
	mssql_select_db ( $DB2_Database, $DB_Conn );

	If ($debug==1) {	
		if (! $DB_Conn) {
			die ("Debug Mode: ON <br>
				Could not connect to Database ".$DB2_Host." <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		else {echo "Debug Mode: ON <br> Successfully connected to database ".$DB2_Host.". <br />";}
		echo ('<br>**************************************************************************************<br>');

	};

	$query1="
		SELECT TOP 1
		Cust_ID,
		First_Name + ' ' + Last_Name AS Full_Name,
		First_Name,
		Last_Name,
		City,
		[State],
		Zip_Code,
		Gross
		FROM tbl_MOM_Cust tMC
		WHERE tMC.Cust_ID = ".$custnum."
		";		

		$result1=mssql_query($query1, $DB_Conn);

		$answer[0][0]=mssql_result($result1, 0, 0);// Cust_ID
		$answer[1][0]=mssql_result($result1, 0, 1);// Full_Name
		$answer[2][0]=mssql_result($result1, 0, 2);// First_Name
		$answer[3][0]=mssql_result($result1, 0, 3);// Last_Name
		$answer[4][0]=mssql_result($result1, 0, 4);// City
		$answer[5][0]=mssql_result($result1, 0, 5);// State
		$answer[6][0]=mssql_result($result1, 0, 6);// Zip Code
		$answer[7][0]=mssql_result($result1, 0, 7);// Gross

	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode within Get_List function: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine while inside Get Cust Info Function. <br />";}

		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";

		echo "DB Conn: '<b>".$DB_Conn."</b>'<br>";

		echo "numrows1: '<b>".$numrows1."</b>'<br>";
		echo "answer1: '<b>".$answer1."</b>'<br>";
		echo "query1: '<b>".$query1."</b>'<br>";

		echo "Cust ID: '<b>".$Cust_ID."</b>'<br>";
		echo "debug: '<b>".$debug."</b>'<br>";


		echo "<br>answer 0, 0 Cust_ID: ".$answer[0][0];// Cust_ID
		echo "<br>answer 1, 0 Full_Name: ".$answer[1][0];// Full_Name
		echo "<br>answer 2, 0 First_Name: ".$answer[2][0];// First_Name
		echo "<br>answer 3, 0 Last_Name: ".$answer[3][0];// Last_Name
		echo "<br>answer 4, 0 City: ".$answer[4][0];// City
		echo "<br>answer 5, 0 State: ".$answer[5][0];// State
		echo "<br>answer 6, 0 Zip Code: ".$answer[6][0];// Zip Code
		echo "<br>answer 7, 0 Gross: ".$answer[7][0];// Gross

		echo "<br>query2: '<b>".$query2."</b>'<br>";


	}
	Return $answer;
}


function get_Header ($db_con, $header){

	//echo $db_con;
	//echo $header;
	//echo "In Header...";

        $sp = mssql_init ( 'usp_IM_GetHeader', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@Header_ID', $header, SQLINT1, false, false, 10); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$textout =  mssql_result ( $result, 0, 'Text' ); //process the results (row 0)  

	//echo $sp."<br>";
	//echo $result."<br>";
	//echo $textout."<br>";	

	return $textout; 
} 

function get_Section ($db_con, $section){

	//echo "In Section...";

	$sp = mssql_init ( 'usp_IM_Get_Section', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@Section_ID', $section,SQLINT1, false,false,200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$textout =  mssql_result ( $result, 0, 'Text' ); //process the results (row 0)  
	return $textout; } 
	
function get_Layout ($db_con, $header, $section){  
	$sp = mssql_init ( 'usp_IM_Get_Layout', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@Header_ID', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@Section_ID', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$textout =  mssql_result ( $result, 0, 'Description' ); //process the results (row 0)  
	
	//echo $result."<br>";
	//echo $textout."<br>";	

	return $textout; 
} 

function get_Rows ($db_con, $header, $section){  
	$sp = mssql_init ( 'usp_IM_Get_Rows', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@Header_ID', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@Section_ID', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$numrows= mssql_num_rows ($result);  
	
	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i] =  mssql_result ( $result, $i, 'Text' ); //process the results (row 0)  
	}  
		return $textout; 
}
	
function get_Columns ($db_con, $header, $section){  
	$sp = mssql_init ( 'usp_IM_Get_Columns', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@Header_ID', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@Section_ID', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$numrows= mssql_num_rows ($result);  
	
	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i] =  mssql_result ( $result, $i, 'Text' ); //process the results (row 0)  
	}  
		return $textout; 
}

function is_Vault_Pick ($db_con, $assoc){  
	$sp = mssql_init ( 'usp_isVaultPick', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@in_Product_Code', $assoc, SQLVARCHAR, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  

	return $result; 
}

function Pink_if_Yellow ($in_results){
		if ($in_results == 'Yes') {
			echo "<td align=center bgcolor=#F52887><FONT color='#ffffff'><b>";
		}
		else {
			echo "<td align=center bgcolor=Yellow><b>";
		}
}

function Pink_if_White ($in_results){
		if ($in_results == 'Yes') {
			echo "<td align=center bgcolor=Pink>";
		}
		else {
			echo "<td align=center><FONT color='#ffffff'>";
		}
}

function White_First ($in_results)
{
	echo "<td align=center><font color=White>";
}

function get_Matrix ($db_con, $custnum, $header, $section)
{  
	//echo "In get_Matrix";

	$sp = mssql_init ( 'usp_IM_Load_Matrix', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@Cust_ID', $custnum, SQLVARCHAR, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@Header_ID', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@Section_ID', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$numrows= mssql_num_rows ($result);  

	for ($i=0; $i<$numrows; $i+=1)
	{
		$textout[$i][0] =  mssql_result ( $result, $i, 'Row_Position' );
		$textout[$i][1] =  mssql_result ( $result, $i, 'Column_Position' );
		$textout[$i][2] =  mssql_result ( $result, $i, 'Quantity' );
		$textout[$i][3] =  mssql_result ( $result, $i, 'Product_Classification_Code' );

		//echo $textout[$i][0];
		/*echo $textout[$i][0];
		echo $textout[$i][0];
		echo $textout[$i][0];
		 */
	}

	//echo "In get_Matrix, after loop";

	/*
	 
	for ($i=0; $i<$numrows; $i+=1){
		$columnout[$i] =  mssql_result ( $result, $i, 'ColumnPosition' ); //process the results (row 0)  
	} 
	$columns=max ($columnout);  

	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i / $columns][$i % $columns] =  mssql_result ( $result, $i, 'Quantity' );
		$textout[$i / $columns][$columns+1] =  mssql_result ( $result, $i, 'ProductClassificationCode' );
		//process the results (row 0)
	}
	 */

	return $textout;
}

function get_Pre33 ($db_con, $custnum, $debug){
	$sp = mssql_init ('usp_IM_Load_Pre33', $db_con); //init stored procedure  
	mssql_bind ($sp, '@Cust_ID', $custnum, SQLVARCHAR, false, false, 15); //provide stored procedure arguments  
	$result = mssql_execute ($sp); //execute the stored procedure  
	$numrows= mssql_num_rows ($result); 
	$_SESSION['Pre33_Count']=$numrows;

	If ($debug==2) {	
			echo "Pre33 numrows: ".$numrows;
			echo "Pre33 custnum: ".$custnum;
//			echo "Pre33 numrows: ".$;
	}

	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i][0] =  mssql_result ( $result, $i, 'Stock_Desc1' );
		$textout[$i][1] =  mssql_result ( $result, $i, 'Quantity' );
	}
	return $textout;




}

function create_Matrix ($db_con, $custnum, $header, $section){  
	echo "<table border=1 cellspacing=1><FONT color='#ffffff'><tr><td></td>";
	$array1 = get_Columns ($db_con, $header, $section);  
	
	foreach ($array1 as $column){
		echo "<td align=center><b><FONT color='#ffffff'>";
		echo $column."</b></td>";
  	}
	$array2 = get_Rows ($db_con, $header, $section);
	$array3 = get_Matrix ($db_con, $custnum, $header, $section);  
	$counter=0;  

	foreach ($array2 as $rowdata){
		echo "<tr><td><b><FONT color='#ffffff'>";
		echo $rowdata."</b></td><FONT color='#ffffff'>";

		if ($array3[$counter][2] > 0){

			$answer = is_Vault_Pick ( $db_con, $array3[$counter][3]);
			$result=mssql_fetch_row($answer);

			echo "<FONT color='#ffffff'>";
			Pink_if_Yellow ($result[0]);
			/*
			if ($result[0] == 'Yes') {
				echo "<td align=center bgcolor=Pink><b>";
			}
			else {
				echo "<td align=center bgcolor=Yellow><b>";
			}
			 */
		 	echo $array3[$counter][2];
			echo "</b></td>";
			 
		}
		elseif ($array3[$counter][3]=='N/A'){
			echo "<td align=center bgcolor=black><FONT color=#ffffff>";
			echo $array3[$counter][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter][3]);
			$result=mssql_fetch_row($answer);
			
			//White_First ($result[0]);
			Pink_if_White($result[0]);
			echo $array3[$counter][2];
			echo "</td>";
		}

  		
		//echo "<td><b>";
		//echo $array3[$counter+1][2];		
		//echo "</b></td>";

		if ($array3[$counter+1][2] > 0){
			//echo "<td align=center bgcolor=Yellow><b>";
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+1][3]);
			$result=mssql_fetch_row($answer);

			//White_First ($result[0]);
			Pink_if_Yellow ($result[0]);
			echo $array3[$counter+1][2];
			echo "<b></td>";
		}
		elseif ($array3[$counter+1][3]=='N/A'){
			echo "<td align=center bgcolor=black><FONT color=#ffffff>";
			echo $array3[$counter+1][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+1][3]);
			$result=mssql_fetch_row($answer);

			//White_First ($result[0]);
			Pink_if_White($result[0]);
			echo $array3[$counter+1][2];
			echo "</td>";
		}


		//echo "<td><b>";
		//echo $array3[$counter+2][2];		
		//echo "</b></td>";

		if ($array3[$counter+2][2] > 0){
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+2][3]);
			$result=mssql_fetch_row($answer);

			//White_First ($result[0]);
			Pink_if_Yellow ($result[0]);
			echo $array3[$counter+2][2];
			echo "<b></td>";
		}
		elseif ($array3[$counter+2][3]=='N/A'){
			echo "<td align=center bgcolor=black><FONT color=#ffffff>";
			echo $array3[$counter+2][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+2][3]);
			$result=mssql_fetch_row($answer);

			//White_First ($result[0]);
			Pink_if_White($result[0]);
			echo $array3[$counter+2][2];
			echo "</td>";
		}

		//echo "<td><b>";
		//echo $array3[$counter+3][2];		
		//echo "</b></td>";
		
		if ($array3[$counter+3][2] > 0){
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+3][3]);
			$result=mssql_fetch_row($answer);

			//White_First ($result[0]);
			Pink_if_Yellow ($result[0]);
			echo $array3[$counter+3][2];
			echo "<b></td>";
		}
		elseif ($array3[$counter+3][3]=='N/A'){
			echo "<td align=center bgcolor=black><FONT color=#ffffff>";
			echo $array3[$counter+3][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+3][3]);
			$result=mssql_fetch_row($answer);

			//White_First ($result[0]);
			Pink_if_White($result[0]);
			echo $array3[$counter+3][2];
			echo "</td>";
		}

//		echo "<td></td><td></td>";
  		echo "</tr>";
		$counter=$counter+4;
	}
	echo "</FONT></tr></table>";
}


?>


<html>
<head>
<title>Customer Purchase History</title>  
</head>  
<BODY style="filter:progid:DXImageTransform.Microsoft.Gradient(endColorstr='#000fff', startColorstr='#000000', gradientType='1');">

<?php
	$answer=get_Cust_Info($custnum, $debug);
	echo ('<center><bold><font size="16"><font color=White>'.$answer[1][0].' </bold></center></f>');
	echo ('<h1 align=center><button align=center onclick="window.close()">Close</button></h1>');
?>

<TABLE id="Table1" cellSpacing="1" cellPadding="1" width="100%" border="1" style="FONT-WEIGHT: bold">
<TR> 
<TD align="center" colspan="2"> <FONT color="#ffffff">INVENTORY MATRIX for Cust # 
<?php
	echo $custnum;
?>
</FONT>
</TD>
</TR>

<TR>
<TD align="center" colspan="2">
    <a href="#goldMS"><FONT color="#F52887">MS GOLD</a> 
    <a href="#goldPF"><FONT color="#F52887">PR GOLD</a> 
    <a href="#commems"><FONT color="#F52887">CMMs and BUFF</a> 
    <a href="#platinumMS"><FONT color="#F52887">MS PLAT</a> 
    <a href="#platinumPF"><FONT color="#F52887">PR PLAT</a> 
    <a href="#pre33"><FONT color="#F52887">Pre-1933</a> 
</TD>
</TR>
<!--   
	<TR>
   <TD align="center" colspan="2">LOADBOOK NOTES <i> (if any, otherwise blank) </i></TD>

		//echo 'successfully connected to db ';
		$sp = mssql_init ( 'usp_Loadbook_Request_Notes', $db_con ); //init stored procedure
		mssql_bind ( $sp, '@Cust_ID', $custnum, SQLVARCHAR, false,false,6); //provide stored procedure arguments
		$result = mssql_execute ( $sp ); //execute the stored procedure
		$textout =  mssql_result ( $result, 0, 'Notes1' ); //process the results (row 0)
		$textout = str_replace ( "\n", '<br/>',$textout);
		echo $textout."<br>";

   </TR>
-->
 <TR><TD align ="left" colspan="2">

 </TD>
 </TR>
 <TR>
  <TD align="center" width="50%"><a name="goldMS"> <FONT color="#ffffff">MINT STATE GOLD</a></TD>
  <TD align="center"><a name="goldPF"> <FONT color="#ffffff">PROOF GOLD</a></TD>  </TR>  </TABLE>  
<TABLE id="Table2" cellSpacing="1" cellPadding="1" width="100%" border="1">  <TR>  

<td align=center><b><FONT color="#ffffff">
<?php 
	echo get_Header ($db_con, 1);
	echo " - ";
	echo get_Section ($db_con, 1);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 1, 1);
  ?>
 </td></FONT></b>

 <td align=center><b><FONT color="#ffffff">
  <?php 
	echo get_Header ($db_con, 1);
	echo " - ";
	echo get_Section ($db_con, 5);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 1, 5);
  ?>
 </td></b>

 <td align=center><b><FONT color="#ffffff">
  <?php 
   echo get_Header ($db_con, 1);
   echo " - ";
   echo get_Section ($db_con, 2);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 1, 2);
  ?>
 </td></b>

 <td align=center><b><FONT color="#ffffff">
  <?php 
   echo get_Header ($db_con, 1);
   echo " - ";
   echo get_Section ($db_con, 6);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 1, 6);
  ?>
 </td></b>
 </TR>

  </TABLE>

  <TABLE id="Table5" cellSpacing="1" cellPadding="1" width="100%" border="1" style="FONT-WEIGHT: bold">
   <TR>
    <TD align="center"><a name="commems"> <FONT color="#ffffff">COMMEMORATIVES AND BUFFALOES</a></TD>
   </TR>
  </TABLE>

  <TABLE id="Table6" cellSpacing="1" cellPadding="1" width="100%" border="1" height=650>
   <TR> 

<td align=center valign=top><b><FONT color="#ffffff">
  <?php 
	echo get_Section ($db_con, 3);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 3, 3);
  ?>
 </td></b>

 <td align=center valign=top><b><FONT color="#ffffff">
  <?php 
	echo get_Section ($db_con, 4);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 3, 4);
  ?>
 </td></b>

 <td align=center valign=top><b><FONT color="#ffffff">
  <?php 
   echo get_Section ($db_con, 8);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 3, 8);
  ?>
 </td></b>

   </TR>
  </TABLE>

  <TABLE id="Table8" cellSpacing="1" cellPadding="1" width="100%" border="1" style="FONT-WEIGHT: bold">
   <TR>
    <TD align="center" width="50%"><a name="platinumMS"> <FONT color="#ffffff">MINT STATE PLATINUM</a></TD>
    <TD align="center"><a name="platinumPF"> <FONT color="#ffffff">PROOF PLATINUM</a></TD>
   </TR>
  </TABLE>

  <TABLE id="Table9" cellSpacing="1" cellPadding="1" width="100%" border="1">
   <TR>


<td align=center valign=top><b><FONT color="#ffffff">
  <?php 
	echo get_Header ($db_con, 2);
	echo " - ";
	echo get_Section ($db_con, 1);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 2, 1);
  ?>
 </td></b>

 <td align=center valign=top><b><FONT color="#ffffff">
  <?php 
	echo get_Header ($db_con, 2);
	echo " - ";
	echo get_Section ($db_con, 5);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 2, 5);
  ?>
 </td></b>

 <td align=center valign=top><b><FONT color="#ffffff">
  <?php 
   echo get_Header ($db_con, 2);
   echo " - ";
   echo get_Section ($db_con, 2);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 2, 2);
  ?>
 </td></b>

 <td align=center valign=top><b><FONT color="#ffffff">
  <?php 
   echo get_Header ($db_con, 2);
   echo " - ";
   echo get_Section ($db_con, 6);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 2, 6);
  ?>
 </td></b>
 </TR>
   
   </TR>
  </TABLE>


  <TABLE align=center id="Table12" cellSpacing="1" cellPadding="1" width="36%" border="1" style="FONT-WEIGHT: bold">
   <TR><td align=center colspan=2><b><a name="pre33"> <FONT color="#ffffff">PRE - 1933</b></a></td>
   </TR>
   <TR>
<?php
   $counter2=0;
echo "<td align=center width=/'90%/'><FONT color='#ffffff'><b>"."DATE / DENOM / DESC / CONDITION / GRADE"."</td></b><td width=/'10%/'><b><FONT color='#ffffff'>QUANTITY</td></b>";

If ($debug==1) 
{	
	IF (! $db_con) 
	{
		DIE ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE 
	{
		echo "Debug Mode: ON <br> Successfully connected to database. <br />";
		echo "Custnum is".$custnum;
	}
};

$custnum = $_GET['Custnum'];
$answer5=get_Pre33($db_con, $custnum, $debug);


for ($i=0; $i<$_SESSION['Pre33_Count']; $i+=1){
	
	echo '<tr><td><FONT color="#ffffff"><b>';
	echo $answer5[$i][0].'</td><td align="center"><FONT color="#ffffff"><b>';
	echo $answer5[$i][1]."</td></b></tr>";
}

/*
$array4 = get_Pre33 ($db_con, $custnum);
	foreach ($array4 as $element){
		echo "<tr><td><b>";
		  echo $array4[$counter2][0]."</b></td><b><td align=center>";
		   echo $array4[$counter2][1]."</td></b></tr>";
		   $counter2++;
   }
    echo "<br>";
 */



?>
  </TABLE>
 </body>
</html>
