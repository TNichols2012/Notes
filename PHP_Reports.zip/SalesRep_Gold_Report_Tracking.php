<?php
session_start();
$debug=0;


/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];
$securitysite=$_SESSION['Security_Site'];

IF ($securitygroup=='Sales' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Executive')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB_Conn = mssql_connect($DB20_Host, $DB20_UserName, $DB20_Password); 
mssql_select_db ( $DB20_Database, $DB_Conn );

If ($debug==1) {	
	IF (! $DB_Conn) {
		DIE ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Debug Mode: ON <br> Successfully connected to database. <br />";}
};

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$tbl_bgcolor="Yellow";

//Get report data here
//
function get_list ($DB_Conn, $in_Sales_ID, $in_Room){

	if ($in_Sales_ID=='' || $in_Sales_ID =='All Sales Reps'){
		$SQL_Login=" 1=1 ";
	}
	else {
		$SQL_Login=" dbo.tbl_Sales_Teams.[Login] ='".$in_Sales_ID."'";
	}

	if ($in_Room=='' || $in_Room =='All Rooms'){
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" dbo.tbl_Sales_Teams.Site ='".$in_Room."'";
		$SQL_Login=" 1=1 ";
	}

//		AND tbl_Sales_Teams.[Login]=".$in_Sales_ID."'

	$query="
		SELECT     
		tbl_Sales_Teams.Site, 
		tbl_Sales_Teams.Name, 
		tbl_Sales_Teams.[Login], 
		LEFT(tbl_Sales_Orders.Order_Date, 12) AS Order_Date,
		CASE WHEN tbl_Sales_Orders.Item_State = 'PS' THEN 'Pending'
		WHEN tbl_Sales_Orders.Item_State = 'SH' THEN 'Shipped'
		ELSE 'Unknown' END AS Item_State,	
		tbl_Sales_Orders.Campaign, 
		tbl_Sales_Orders.Ad_Code, 
		tbl_MOM_Cust.Cust_ID, 
		tbl_MOM_Cust.First_Name + ' ' + tbl_MOM_Cust.Last_Name AS Cust_Name, 
		ISNULL(CONVERT(varchar(25), tACI1.Last_OB_Contact_Date), 'Not_Contacted') AS Last_Contact_Date,
		(CASE 
		WHEN tACI1.Last_OB_Contact_Date > tbl_Sales_Orders.Order_Date THEN 'Yes' 
		WHEN tACI2.Last_OB_Contact_Date > tbl_Sales_Orders.Order_Date THEN 'Yes' 
		ELSE 'No' END) AS [Status],
		CASE WHEN Ship_List IN ('USP', 'USF') THEN 'Standard'
		WHEN Ship_List IN ('UPL', 'UPE') THEN 'Overnight' 
		ELSE 'Unknown' END AS Priority		
		FROM         tbl_Sales_Orders 
		INNER JOIN tbl_MOM_Cust 
		ON tbl_Sales_Orders.Cust_ID = tbl_MOM_Cust.Cust_ID 
		INNER JOIN tbl_Sales_Teams 
		ON tbl_Sales_Orders.Sales_ID = tbl_Sales_Teams.Login
		LEFT OUTER JOIN dbo.tbl_Amcat_Contact_Info tACI1
		ON dbo.tbl_MOM_Cust.Contact_Number1 = tACI1.ContactNumber
		LEFT OUTER JOIN dbo.tbl_Amcat_Contact_Info tACI2
		ON dbo.tbl_MOM_Cust.Contact_Number1 = tACI2.ContactNumber
		WHERE     (tbl_Sales_Orders.Order_Date >= dbo.Get_TheMonth_Previous_01(GetDate()) )
		AND (tbl_Sales_Orders.Order_Date < dbo.Get_TheDate(GetDate()) )
		AND (tbl_Sales_Orders.Stock_Type = 'Gold_Report') 
		AND (tbl_Sales_Orders.Ship_List IN ('USF', 'UPL', 'USP', 'UPE'))
		AND (tbl_Sales_Orders.Sales_ID = tbl_MOM_Cust.Sales_ID)
		AND ((CASE WHEN tACI1.Last_OB_Contact_Date >= tbl_Sales_Orders.Order_Date THEN 'Yes' ELSE 'No' END) = 'No'  
		    OR (CASE WHEN tACI2.Last_OB_Contact_Date >= tbl_Sales_Orders.Order_Date THEN 'Yes' ELSE 'No' END) = 'No' ) 
		AND ".$SQL_Login."
		AND ".$SQL_Room."
		ORDER BY 
		tbl_Sales_Orders.Order_Date desc
		";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Asset_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$textout[0][$i]=mssql_result($result, $i, 0);//Site
		$textout[1][$i]=mssql_result($result, $i, 1);//Name
		$textout[2][$i]=mssql_result($result, $i, 2);//Login
		$textout[3][$i]=mssql_result($result, $i, 3);//Order_Date
		$textout[4][$i]=mssql_result($result, $i, 4);//Item_State
		$textout[5][$i]=mssql_result($result, $i, 5);//Campaign
		$textout[6][$i]=mssql_result($result, $i, 6);//Ad_Code
		$textout[7][$i]=mssql_result($result, $i, 7);//Cust_ID
		$textout[8][$i]=mssql_result($result, $i, 8);//Full_Name
		$textout[9][$i]=mssql_result($result, $i, 9);//Last_Contact_Date
		$textout[10][$i]=mssql_result($result, $i, 10);//Status	
		$textout[11][$i]=mssql_result($result, $i, 11);//Priority
	}


	If ($debug==1) {
		echo "In the function call.";	
		echo "SQL_Login looks like: '<b>".$SQL_Login."</b>'<br>";
		echo "SQL_Room looks like: '<b>".$SQL_Room."</b>'<br>";
		echo "query looks like: '<b>".$query."</b>'<br>";

	}


	Return $textout;
}

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" bgcolor="');
	global $tbl_bgcolor;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}


?>

<html>
<title>USRCBR Sales Review: Gold Report Callback Listing</title>
<head>

<script type="text/javascript">
	function show_asset(Index_ID){
	<!--
	str_redirect1='./Survey_Add.php?$orig_index='+Index_ID
	window.open (str_redirect1, 'Asset_Window_'+Index_ID, config='height=800, width=800, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}

	function show_new_survey(){
	<!--
	str_redirect2='./Survey_Add_New.php'
	window.open (str_redirect2, 'Asset_Window_', config='height=800, width=800, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}



</script>

<script src="JS_Sort_Table.js"></script>

<style type="text/css" media="print">
BODY {display:none;visibility:hidden;}
</style>


</head>
	
<body>
<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_SESSION['$in_category']='';
	$_SESSION['$in_room']='';
	$_POST["in_Category"]='';
	$_POST["in_Room"]='';
	$_POST["in_Surveyor"]='';
}


If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}

		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";
	};

if ($_SESSION['User_ID']<>''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Sales'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="SalesRep_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}



	echo ('	<h2 align=center>Sales Agent Report: Gold Report Callback List</h2>
		<h4 align=center>*Last contact is based on OUTBOUND calls to a customer\'s Primary Contact Number.</h4>
		<h3 align=center><button align=center onclick="window.close()">Close</button></h3>
		<p></p>

		<table align="center" class="sortable">
		<tr>');
	format_tbl_header("Status", 100, center);
	format_tbl_header("Priority", 100, center);
	format_tbl_header("Sales Rep", 200, center);
	format_tbl_header("Order Date", 125, center);
	format_tbl_header("Campaign", 75, center);
	format_tbl_header("Ad Code", 150, center);
	format_tbl_header("Customer", 150, center);
	format_tbl_header("Last OB Contact", 150, center);
	format_tbl_header("Called?", 50, center);
	echo ('</tr>');

	$_SESSION['$in_category']=$_POST["in_Category"];
	$_SESSION['$in_room']=$_POST["in_Room"];
	$_SESSION['$in_surveyor']=$_POST["in_Surveyor"];


	if($securitygroup=='Sales' AND $securitysite <>''){
		$asset_list=get_list($DB_Conn, 'All Sales Reps', $securitysite);
	}
	if($securitygroup=='Sales' AND $securitysite ==''){
		$asset_list=get_list($DB_Conn, $_SESSION['User_ID'], $_POST["in_Room"]);
	}
	if($securitygroup=='Administrator' || $securitygroup=='Developer' || $securitygroup=='Executive'){
		$asset_list=get_list($DB_Conn, 'All Sales Reps', 'All Rooms');
	}
	

 


	//$asset_list=get_list($DB_Conn, $_SESSION['User_ID'], $_POST["in_Room"]);

	//$_SESSION['Asset_List']=$asset_list;

	for ($i=0; $i<$_SESSION['Asset_Count']; $i+=1){

		//if ($i%2){
		//	$row_bgcolor=LightGreen;
		//}
		//else {
		//	$row_bgcolor=LightGrey;
		//}
	
		IF ($asset_list[4][$i]=='Pending'){
			$row_bgcolor=LightGrey;
		}

		IF ($asset_list[4][$i]=='Shipped'){
			$row_bgcolor=LightGreen;
		}

		IF ($asset_list[4][$i]=='Unknown'){
			$row_bgcolor=Yellow;
		}

//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			
	
	echo ('<tr>');

	format_tbl_content($asset_list[4][$i], 100, center, $row_bgcolor);	//Site
	
	format_tbl_content($asset_list[11][$i], 100, center, $row_bgcolor);	//Priority
	
	format_tbl_content($asset_list[1][$i], 200, center, $row_bgcolor);	//Login

	echo ('<td align="center" bgcolor="'.$row_bgcolor.'" width="125">'.$asset_list[3][$i].'</td>');

//	format_tbl_content($asset_list[3][$i], 150, left, $row_bgcolor);	//Order_Date
	format_tbl_content($asset_list[5][$i], 75, center, $row_bgcolor);	//Campaign
	format_tbl_content($asset_list[6][$i], 150, center, $row_bgcolor);	//Ad_Code
	format_tbl_content($asset_list[8][$i], 150, center, $row_bgcolor);	//Cust_Name
	format_tbl_content($asset_list[9][$i], 150, center, $row_bgcolor);	//Last_Contact_Date
	format_tbl_content($asset_list[10][$i], 50, center, $row_bgcolor);	//Contact Status
	echo ('</tr>');
	}

	echo ('	</table>');

//	echo ('</br></br><A HREF="http://usrcrep01/php_reports/GR_List_2.php">1) 2008 Holiday Silver Gift Call List</A>');
//	echo ('</br></br><A HREF="http://usrcrep01/php_reports/GR_List_3.php">2) 2007 First Spouse Buyer List</A>');


	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}


		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";
	};
	
}

	 

?>
</body>
</html>

