<?php
session_start();
$debug=0;

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB2_Database, $DB_Conn );



define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
define("Red", "FF3300");
define("Green", "00CC33");
$hdr_bgcolor=Yellow;

if ($debug==1){
	if (! $DB_Conn) {
		DIE ("DEBUG MODE ON. <br /> Could not connect to USRCREP02 Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "DEBUG MODE ON. <br />";
		echo "Connected Fine to USRCREP02 Database. <br />";
		echo "Customer ID =".$_GET['Custnum']."<br>";
		echo "DNIS =".$_GET['DNIS']."<br>";
		echo "Contact Number =".$_GET['Number']."<br>";

	}
}

function get_Info ($DB_Conn, $First_Name, $Last_Name, $City, $State, $Zip_Code, $Contact_Phone, $debug) {

	if ($First_Name=='') {
		$First_Name="%";
	}
	else {
		$First_Name = "%".$First_Name."%";
	}

	if ($Last_Name=='') {
		$Last_Name="%";
	}
	else {
		$Last_Name = "%".$Last_Name."%";
	}

	if ($City=='') {
		$City="%";
	}
	else {
		$City = "%".$City."%";
	}

	if ($State=='') {
		$State="%";
	}
	else {
		$State = "%".$State."%";
	}

	if ($Zip_Code=='') {
		$Zip_Code="%";
	}
	else {
		$Zip_Code = "%".$Zip_Code."%";
	}
	
	if ($Contact_Phone=='') {
		$Contact_Phone="%";
	}
	else {
		$Contact_Phone = "%".$Contact_Phone."%";
	}


	$query="
		SELECT TOP 25
		tMC.Cust_ID,
		tMC.First_Name + ' ' + tMC.Last_Name AS [Name],
		tMC.City,
		tMC.[State],
		tMC.Zip_Code,
		tST.[Name],
		tMC.Sales_ID
		FROM tbl_MOM_Cust tMC
		LEFT OUTER JOIN tbl_Sales_Teams tST
		ON tMC.Sales_ID=tST.[Login]
		WHERE tMC.First_Name LIKE '".$First_Name."'
		AND tMC.Last_Name LIKE '".$Last_Name."'
		AND tMC.City LIKE '".$City."'
		AND tMC.[State] LIKE '".$State."'
		AND tMC.Zip_Code LIKE '".$Zip_Code."'
		AND (tMC.Contact_Number1 LIKE '".$Contact_Phone."' OR tMC.Contact_Number2 LIKE '".$Contact_Phone."' OR tMC.Contact_Number3 LIKE '".$Contact_Phone."' OR tMC.Contact_Number4 LIKE '".$Contact_Phone."')";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['List_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result, $i, 0);// Cust_ID
		$answer[1][$i]=mssql_result($result, $i, 1);// Full Name
		$answer[2][$i]=mssql_result($result, $i, 2);// City
		$answer[3][$i]=mssql_result($result, $i, 3);// State
		$answer[4][$i]=mssql_result($result, $i, 4);// Zip Code
		$answer[5][$i]=mssql_result($result, $i, 5);// Sales Rep Name
		$answer[6][$i]=mssql_result($result, $i, 6);// Sales ID

	}

	if ($numrows == 0) {
		$answer[0][$i]='0';
		$answer[1][$i]='No Loadbook Notes Found.';
		$answer[2][$i]='No Customer Record Found.';
		$answer[3][$i]='';
		$answer[4][$i]='';
		$answer[5][$i]='';
		$answer[6][$i]='';
	}
  
	if ($debug==1){
		if (! $DB_Conn) {
			DIE ("Could not connect to USRCREP02 USRC_Main Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to USRCREP02 USRC_Main Database. <br />";
		}
		
		echo ('<br>Loadbook Search Query Looks Like:<br> '.$query);
		echo ('<br><br>numrow count?:<br> '.$numrows);
	}
	Return $answer;
};

function get_Shortel_Campaign ($Campaign_ID, $debug){
	
	Switch($Campaign_ID) {
		case 400;
		$answer='Verification';
		break;
		case 401;
		$answer='Magazine';
		break;
		case 402;
		$answer='Newspaper';
		break;
		case 403;
		$answer='TV';
		break;		
		case 404;
		$answer='International';
		break;
		case 405;
		$answer='Spot TV';
		break;
		case 406;
		$answer='DMT';
		break;
		case 407;
		$answer='Web';
		break;
		case 408;
		$answer='Customer Callback';
		break;
		default:
		$answer='Unknown Campaign';
		break;
	}
	Return $answer;
}



function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<th align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></th>');
	}
	else {
		echo ('><b>'.$label.'</b></th>');
	}
}; //end function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor)

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}; //end function format_tbl_content($content, $width, $alignment="left", $row_bgcolor)


?>

<html>
<head>

</head>

<body>
<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if ($_GET['DNIS'] =='') {
	$_SESSION['S_Campaign_Name'] = $_SESSION['S_Campaign_Name'];
}
else {
	$_SESSION['S_Campaign_Name'] = get_Shortel_Campaign ($_GET['DNIS'], $debug);
}

if ($_GET['Number']=='') {
	$_SESSION['S_Contact_Number'] = $_SESSION['S_Contact_Number'];
}
else {
	$_SESSION['S_Contact_Number'] = $_GET['Number']; 
}

if ($_POST['Search']){

	$get_search=get_Info ($DB_Conn, $_POST["in_First_Name"], $_POST["in_Last_Name"], $_POST["in_City"], $_POST["in_State"], $Zip_Code, $_POST["in_Contact_Number"], $debug);

	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
		<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>
		<h2 align=center>Inbound Customer Information Summary</h2>');

	echo ('<table align=center><tr>');
	
	echo "<tr><td>Phone:</td><td>".$_SESSION['S_Contact_Number']."</td></tr>";
	echo "<tr><td>Campaign:</td><td>".$_SESSION['S_Campaign_Name']."</td></tr>";

	echo ('</table><br>');

	echo (' <table align="center">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<tr><td align="center" valign="top">
		First Name
		</td>
		<td align="center" valign="top">
		Last Name
		</td>
		<td align="center" valign="top">
		City
		</td>
		<td align="center" valign="top">
		State
		</td>
		<td align="center" valign="top">
		Zip Code
		</td>
		<td align="center" valign="top">
		Contact Number
		</td>
		</tr>
		<tr>
		
		<td><input type="text" style="text-align:center" name="in_First_Name" align="center" value="'.$_POST["in_First_Name"].'"></td>
		<td><input type="text" style="text-align:center" name="in_Last_Name" align="center" value="'.$_POST["in_Last_Name"].'"></td>
		<td><input type="text" style="text-align:center" name="in_City" align="center" value="'.$_POST["in_City"].'"></td>
		<td><input type="text" style="text-align:center" name="in_State" align="center" value="'.$_POST["in_State"].'"></td>
		<td><input type="text" style="text-align:center" name="in_Zip_Code" align="center" value="'.$_POST["in_Zip_Code"].'"></td>
		<td><input type="text" style="text-align:center" name="in_Contact_Number" align="center" value="'.$_POST["in_Contact_Number"].'"></td>
		</tr>
		<tr><td colspan=6 align="center"><input type="submit" name="Search" value="Search" /></tr>
		<tr><td colspan=6 align="center">'.$_SESSION['List_Count'].' Matches');
	echo ('	</td></tr></form></table><br>');



echo ('	<div id="header">
	<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Customer Name", 200, center, $hdr_bgcolor);
	format_tbl_header("City", 200, center, $hdr_bgcolor);
	format_tbl_header("State", 75, center, $hdr_bgcolor);
	format_tbl_header("Zip Code", 75, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep ", 200, center, $hdr_bgcolor);
	format_tbl_header("Sales ID", 75, center, $hdr_bgcolor);
	echo ('</tr></div>');


	for ($i=0; $i<$_SESSION['List_Count']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	format_tbl_content($i+1, 50, center, $row_bgcolor);			// Index	
	format_tbl_content($get_search[1][$i], 200, center, $row_bgcolor);	// Customer Name
	format_tbl_content($get_search[2][$i], 200, center, $row_bgcolor);	// City
	format_tbl_content($get_search[3][$i], 75, center, $row_bgcolor);	// State
	format_tbl_content($get_search[4][$i], 75, center, $row_bgcolor);	// Zip Code
	format_tbl_content($get_search[5][$i], 200, center, $row_bgcolor);	// Sales Rep
	format_tbl_content($get_search[6][$i], 75, center, $row_bgcolor);	// Sales ID	
	echo ('</tr>');
	}



	echo ('</table>');
}
else // if ($_POST['Search'])
{
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
		<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>
		<h2 align=center>Inbound Customer Information Summary</h2>');

	echo ('<table align=center><tr>');
	
	echo "<tr><td>Phone:</td><td>".$_SESSION['S_Contact_Number']."</td></tr>";
	echo "<tr><td>Campaign:</td><td>".$_SESSION['S_Campaign_Name']."</td></tr>";

	echo ('</table><br>');

	echo (' <table align="center">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<tr><td align="center" valign="top">
		First Name
		</td>
		<td align="center" valign="top">
		Last Name 		
		</td>
		<td align="center" valign="top">
		City
		</td>
		<td align="center" valign="top">
		State
		</td>
		<td align="center" valign="top">
		Zip Code
		</td>
		<td align="center" valign="top">
		Contact Number
		</td>
		</tr>
		<tr>
		
		<td><input type="text" style="text-align:center" name="in_First_Name" align="center"></td>
		<td><input type="text" style="text-align:center" name="in_Last_Name" align="center"></td>
		<td><input type="text" style="text-align:center" name="in_City" align="center"></td>
		<td><input type="text" style="text-align:center" name="in_State" align="center"></td>
		<td><input type="text" style="text-align:center" name="in_Zip_Code" align="center"></td>
		<td><input type="text" style="text-align:center" name="in_Contact_Number" align="center"></td>
		</tr>
		<tr><td colspan=6 align="center"><input type="submit" name="Search" value="Search" /></tr>
		<tr><td colspan=6 align="center">Show Top 25 Matches');
	echo ('	</td></tr></form></table><br><br>');

echo ('	<div id="header">
	<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Customer Name", 200, center, $hdr_bgcolor);
	format_tbl_header("City", 200, center, $hdr_bgcolor);
	format_tbl_header("State", 75, center, $hdr_bgcolor);
	format_tbl_header("Zip Code", 75, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep ", 200, center, $hdr_bgcolor);
	format_tbl_header("Sales ID", 75, center, $hdr_bgcolor);
	echo ('</tr></table></div>');

}
i

?>
</body>










</html>

