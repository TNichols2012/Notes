<?php
session_start();
$debug=0;

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB2_Database, $DB_Conn );

$Cust_ID = $_GET['Custnum']; //get custnum from url eg http://blob.com/file.php?custnum=403030
$DNIS = $_GET['DNIS']; //get custnum from url eg http://blob.com/file.php?custnum=403030
$Contact_Number = $_GET['Number']; //get custnum from url eg http://blob.com/file.php?custnum=403030

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
define("Red", "FF3300");
define("Green", "00CC33");
$hdr_bgcolor=Green;

if ($debug==1){
	if (! $DB_Conn) {
		DIE ("DEBUG MODE ON. <br /> Could not connect to USRCREP02 Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "DEBUG MODE ON. <br />";
		echo "Connected Fine to USRCREP02 Database. <br />";
		echo "Customer ID =".$Cust_ID."<br>";
		echo "DNIS =".$DNIS."<br>";
		echo "Contact Number =".$Contact_Number."<br>";

	}
}


function get_Shortel_Lookup($DB_Conn, $Cust_ID, $debug){
/*
	$sp1 = mssql_init ( '[Data_Warehouse].dbo.usp_Shortel_Lookup', $DB_Conn ); 
	mssql_bind ($sp1, '@in_Cust_ID', $Cust_ID, SQLVARCHAR, false, false, 10);
	$result1 = mssql_execute ( $sp1 );
	$numrows=mssql_num_rows($result1);
	$_SESSION['List_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result1, $i, 0);// Cust_ID
		$answer[1][$i]=mssql_result($result1, $i, 1);// Name
		$answer[2][$i]=mssql_result($result1, $i, 2);// City
		$answer[3][$i]=mssql_result($result1, $i, 3);//	State
		$answer[4][$i]=mssql_result($result1, $i, 4);// Gross

	}
*/

	
	$query="
		SELECT TOP 1
		tMC.Cust_ID,
		tMC.First_Name + ' ' + tMC.Last_Name AS [Name],
		tMC.City,
		tMC.[State],
		tMC.Gross
		FROM tbl_MOM_Cust tMC
		WHERE tMC.Cust_ID ='".$Cust_ID."'";

	$result1=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result1);

	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result1, $i, 0);// Cust_ID
		$answer[1][$i]=mssql_result($result1, $i, 1);// Name
		$answer[2][$i]=mssql_result($result1, $i, 2);// City
		$answer[3][$i]=mssql_result($result1, $i, 3);//	State
		$answer[4][$i]=mssql_result($result1, $i, 4);// Gross
	}


	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode within Get_List function: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine while inside Get List Function. <br />";}

		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";

		echo "Query1 numrows: '<b>".$numrows."</b>'<br>";
		echo "Query2 answer: '<b>".$answer."</b>'<br>";
		echo "Query3 sp1: '<b>".$sp1."</b>'<br>";
		echo "Query4 Cust ID: '<b>".$Cust_ID."</b>'<br>";
		echo "Query5 debug: '<b>".$debug."</b>'<br>";
		echo "Query6 DB Conn: '<b>".$DB_Conn."</b>'<br>";
		echo "Query7 result: '<b>".$result1."</b>'<br>";
		echo "Query8 query: '<b>".$query."</b>'<br>";


	}
	Return $answer;
}

function get_Shortel_Campaign ($Campaign_ID, $debug){
	
	Switch($Campaign_ID) {
		case 400;
		$answer='Verification';
		break;
		case 401;
		$answer='Magazine';
		break;
		case 402;
		$answer='Newspaper';
		break;
		case 403;
		$answer='TV';
		break;		
		case 404;
		$answer='International';
		break;
		case 405;
		$answer='Spot TV';
		break;
		case 406;
		$answer='DMT';
		break;
		case 407;
		$answer='Web';
		break;
		case 408;
		$answer='Customer Callback';
		break;
		default:
		$answer='My Customer Inbound';
		break;
	}



	Return $answer;
}


?>

<html>
<head>

</head>

<body>
<?php

$answer = get_Shortel_Lookup ($DB_Conn, $Cust_ID, $debug);
$campaign = get_Shortel_Campaign ($DNIS, $debug);

echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>
	<h2 align=center>Inbound Customer Information Summary</h2>');

echo ('<table align=center><tr>');

echo "<tr><td>Name:</td><td>".$answer[1][0]."</td></tr>";
echo "<tr><td>Phone:</td><td>".$Contact_Number."</td></tr>";
echo "<tr><td>City:</td><td>".$answer[2][0]."</td></tr>";
echo "<tr><td>State:</td><td>".$answer[3][0]."</td></tr>";
echo "<tr><td>Gross:</td><td>$ ".number_format($answer[4][0], 2)."</td></tr>";
echo "<tr><td>Campaign:</td><td>".$campaign."</td></tr>";
echo ('<tr><td align=center colspan=2><a href="http://matrix/php_reports/SalesRep_Inventory_Matrix.php?Custnum='.$Cust_ID.'">Show Me Their Inventory Matrix</a></td></tr>');

echo ('</table>');


?>
</body>










</html>

