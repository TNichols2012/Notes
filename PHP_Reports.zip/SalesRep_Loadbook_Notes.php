<?php
function get_Header ($db_con, $header){
        $sp = mssql_init ( 'usp_InventoryMatrix_GetHeader', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@HeaderId', $header,SQLINT1, false,false,200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$textout =  mssql_result ( $result, 0, 'Text' ); //process the results (row 0)  
	return $textout; 
} 

function get_Section ($db_con, $section){
        $sp = mssql_init ( 'usp_InventoryMatrix_GetSection', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@SectionId', $section,SQLINT1, false,false,200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$textout =  mssql_result ( $result, 0, 'Text' ); //process the results (row 0)  
	return $textout; } function get_Layout ($db_con, $header, $section){  
	$sp = mssql_init ( 'usp_InventoryMatrix_GetLayout', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@HeaderId', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@SectionId', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$textout =  mssql_result ( $result, 0, 'Description' ); //process the results (row 0)  
	return $textout; 
} 

function get_Rows ($db_con, $header, $section){  
	$sp = mssql_init ( 'usp_InventoryMatrix_GetRows', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@HeaderId', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@SectionId', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$numrows= mssql_num_rows ($result);  
	
	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i] =  mssql_result ( $result, $i, 'Text' ); //process the results (row 0)  
	}  
		return $textout; 
}
	
function get_Columns ($db_con, $header, $section){  
	$sp = mssql_init ( 'usp_InventoryMatrix_GetColumns', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@HeaderId', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@SectionId', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$numrows= mssql_num_rows ($result);  
	
	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i] =  mssql_result ( $result, $i, 'Text' ); //process the results (row 0)  
	}  
		return $textout; 
}

function is_Vault_Pick ($db_con, $assoc){  
	$sp = mssql_init ( 'usp_isVaultPick', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@in_Product_Code', $assoc, SQLVARCHAR, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  

	return $result; 
}

function Pink_if_Yellow ($in_results){
		if ($in_results == 'Yes') {
			echo "<td align=center bgcolor=#F52887><b>";
		}
		else {
			echo "<td align=center bgcolor=Yellow><b>";
		}
}

function Pink_if_White ($in_results){
		if ($in_results == 'Yes') {
			echo "<td align=center bgcolor=Pink>";
		}
		else {
			echo "<td align=center>";
		}
}

function get_Matrix ($db_con, $custnum, $header, $section){  
	$sp = mssql_init ( 'usp_InventoryMatrix_GetMatrix', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@custnum', $custnum, SQLVARCHAR, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@HeaderId', $header, SQLINT1, false, false, 200); //provide stored procedure arguments  
	mssql_bind ( $sp, '@SectionId', $section, SQLINT1, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$numrows= mssql_num_rows ($result);  

	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i][0] =  mssql_result ( $result, $i, 'RowPosition' );
		$textout[$i][1] =  mssql_result ( $result, $i, 'ColumnPosition' );
		$textout[$i][2] =  mssql_result ( $result, $i, 'Quantity' );
		$textout[$i][3] =  mssql_result ( $result, $i, 'ProductClassificationCode' );
	}
	/*
	 
	for ($i=0; $i<$numrows; $i+=1){
		$columnout[$i] =  mssql_result ( $result, $i, 'ColumnPosition' ); //process the results (row 0)  
	} 
	$columns=max ($columnout);  

	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i / $columns][$i % $columns] =  mssql_result ( $result, $i, 'Quantity' );
		$textout[$i / $columns][$columns+1] =  mssql_result ( $result, $i, 'ProductClassificationCode' );
		//process the results (row 0)
	}
	 */
		return $textout;
}

function get_Pre33 ($db_con, $custnum){
	$sp = mssql_init ( 'usp_InventoryMatrix_GetPre33Rows', $db_con ); //init stored procedure  
	mssql_bind ( $sp, '@custnum', $custnum, SQLVARCHAR, false, false, 200); //provide stored procedure arguments  
	$result = mssql_execute ( $sp ); //execute the stored procedure  
	$numrows= mssql_num_rows ($result); 
       
	for ($i=0; $i<$numrows; $i+=1){
		$textout[$i][0] =  mssql_result ( $result, $i, 'desc' );
		$textout[$i][1] =  mssql_result ( $result, $i, 'Quantity' );
	}
 	return $textout;
}

function create_Matrix ($db_con, $custnum, $header, $section){  
	echo "<table border=1 cellspacing=1><tr><td></td>";
	$array1 = get_Columns ($db_con, $header, $section);  
	
	foreach ($array1 as $column){
		echo "<td align=center><b>";
		echo $column."</b></td>";
  	}
	$array2 = get_Rows ($db_con, $header, $section);
	$array3 = get_Matrix ($db_con, $custnum, $header, $section);  
	$counter=0;  

	foreach ($array2 as $rowdata){
		echo "<tr><td><b>";
		echo $rowdata."</b></td>";

		if ($array3[$counter][2] > 0){

			$answer = is_Vault_Pick ( $db_con, $array3[$counter][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_Yellow ($result[0]);
			/*
			if ($result[0] == 'Yes') {
				echo "<td align=center bgcolor=Pink><b>";
			}
			else {
				echo "<td align=center bgcolor=Yellow><b>";
			}
			 */
		 	echo $array3[$counter][2];
			echo "</b></td>";
			 
		}
		elseif ($array3[$counter][3]=='N/A'){
			echo "<td align=center bgcolor=black>";
			echo $array3[$counter][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_White($result[0]);
			echo $array3[$counter][2];
			echo "</td>";
		}

  		
		//echo "<td><b>";
		//echo $array3[$counter+1][2];		
		//echo "</b></td>";

		if ($array3[$counter+1][2] > 0){
			//echo "<td align=center bgcolor=Yellow><b>";
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+1][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_Yellow ($result[0]);
			echo $array3[$counter+1][2];
			echo "<b></td>";
		}
		elseif ($array3[$counter+1][3]=='N/A'){
			echo "<td align=center bgcolor=black>";
			echo $array3[$counter+1][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+1][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_White($result[0]);
			echo $array3[$counter+1][2];
			echo "</td>";
		}


		//echo "<td><b>";
		//echo $array3[$counter+2][2];		
		//echo "</b></td>";

		if ($array3[$counter+2][2] > 0){
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+2][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_Yellow ($result[0]);
			echo $array3[$counter+2][2];
			echo "<b></td>";
		}
		elseif ($array3[$counter+2][3]=='N/A'){
			echo "<td align=center bgcolor=black>";
			echo $array3[$counter+2][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+2][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_White($result[0]);
			echo $array3[$counter+2][2];
			echo "</td>";
		}

		//echo "<td><b>";
		//echo $array3[$counter+3][2];		
		//echo "</b></td>";
		
		if ($array3[$counter+3][2] > 0){
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+3][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_Yellow ($result[0]);
			echo $array3[$counter+3][2];
			echo "<b></td>";
		}
		elseif ($array3[$counter+3][3]=='N/A'){
			echo "<td align=center bgcolor=black>";
			echo $array3[$counter+3][2];
			echo "</td>";
  		}
		else {
			$answer = is_Vault_Pick ( $db_con, $array3[$counter+3][3]);
			$result=mssql_fetch_row($answer);

			Pink_if_White($result[0]);
			echo $array3[$counter+3][2];
			echo "</td>";
		}

//		echo "<td></td><td></td>";
  		echo "</tr>";
		$counter=$counter+4;
	}
	echo "</tr></table>";
}

/*
function get_Loadbook_Notes ($custID) {
		$sp = mssql_init ( 'usp_GetLoadBookNotes', $db_con ); //init stored procedure
		mssql_bind ( $sp, '@custnum', $custID, SQLVARCHAR, false,false,200); //provide stored procedure arguments
		$result = mssql_execute ( $sp ); //execute the stored procedure
		
		if (mssql_num_rows($result)>0{
			$textout =  mssql_result ( $result, 0, 'Notes' ); //process the results (row 0)
			$textout = str_replace ( "\n", '<br/>',$textout);
			echo $textout."<br>";
		}
		else {
			echo "No Loadbook Notes Found.";
		}

		return;
}
 */

?>
<html>
 <head>
  <title>Customer Purchase History</title>  </head>  <body>
  <TABLE id="Table1" cellSpacing="1" cellPadding="1" width="100%" border="1" style="FONT-WEIGHT: bold">
   <TR>
   <TD align="center" colspan="2">INVENTORY MATRIX</TD>
   </TR>
   <TR>
   <TD align="center" colspan="2">
    <a href="#goldMS">MS GOLD</a> 
    <a href="#goldPF">PR GOLD</a> 
    <a href="#commems">CMMs and BUFF</a> 
    <a href="#platinumMS">MS PLAT</a> 
    <a href="#platinumPF">PR PLAT</a> 
    <a href="#pre33">Pre-1933</a> </TD>
   </TR>
   <TR>
   <TD align="center" colspan="2">LOADBOOK NOTES <i> (if any, otherwise blank) </i></TD>
   </TR>
 <TR><TD align ="left" colspan="2">
 <?php
	$db_con = mssql_connect ( 'USRC_AMCATSQL', 'sql_admin', 'AustinDat@',TRUE ); //connect to database  
	//$db_con = mssql_connect ( 'USRCDEV01', 'sqladmin', 'AustinDat@',TRUE ); //connect to database  
	$custnum = $_GET['custnum']; //get custnum from url eg http://blob.com/file.php?custnum=403030
	if (mssql_select_db ( 'usrc_main', $db_con )){ //select the database in the server
		//echo 'successfully connected to db ';
		$sp = mssql_init ( 'usp_GetLoadBookNotes', $db_con ); //init stored procedure
		mssql_bind ( $sp, '@custnum', $custnum, SQLVARCHAR, false,false,200); //provide stored procedure arguments
		$result = mssql_execute ( $sp ); //execute the stored procedure
		$textout =  mssql_result ( $result, 0, 'Notes' ); //process the results (row 0)
		$textout = str_replace ( "\n", '<br/>',$textout);
		echo $textout."<br>";
 	}
	else {
		echo 'Database Connection Error. Unable to access data.';
	}
?>
 </TD>
 </TR>
 <TR>
  <TD align="center" width="50%"><a name="goldMS">MINT STATE GOLD</a></TD>
  <TD align="center"><a name="goldPF">PROOF GOLD</a></TD>  </TR>  </TABLE>  
<TABLE id="Table2" cellSpacing="1" cellPadding="1" width="100%" border="1">  <TR>  

<td align=center><b>
  <?php 
	echo get_Header ($db_con, 1);
	echo " - ";
	echo get_Section ($db_con, 1);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 1, 1);
  ?>
 </td></b>

 <td align=center><b>
  <?php 
	echo get_Header ($db_con, 1);
	echo " - ";
	echo get_Section ($db_con, 5);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 1, 5);
  ?>
 </td></b>

 <td align=center><b>
  <?php 
   echo get_Header ($db_con, 1);
   echo " - ";
   echo get_Section ($db_con, 2);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 1, 2);
  ?>
 </td></b>

 <td align=center><b>
  <?php 
   echo get_Header ($db_con, 1);
   echo " - ";
   echo get_Section ($db_con, 6);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 1, 6);
  ?>
 </td></b>
 </TR>

  </TABLE>

  <TABLE id="Table5" cellSpacing="1" cellPadding="1" width="100%" border="1" style="FONT-WEIGHT: bold">
   <TR>
    <TD align="center"><a name="commems">COMMEMORATIVES AND BUFFALOES</a></TD>
   </TR>
  </TABLE>

  <TABLE id="Table6" cellSpacing="1" cellPadding="1" width="100%" border="1" height=650>
   <TR> 

<td align=center valign=top><b>
  <?php 
	echo get_Section ($db_con, 3);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 3, 3);
  ?>
 </td></b>

 <td align=center valign=top><b>
  <?php 
	echo get_Section ($db_con, 4);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 3, 4);
  ?>
 </td></b>

 <td align=center valign=top><b>
  <?php 
   echo get_Section ($db_con, 8);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 3, 8);
  ?>
 </td></b>

   </TR>
  </TABLE>

  <TABLE id="Table8" cellSpacing="1" cellPadding="1" width="100%" border="1" style="FONT-WEIGHT: bold">
   <TR>
    <TD align="center" width="50%"><a name="platinumMS">MINT STATE PLATINUM</a></TD>
    <TD align="center"><a name="platinumPF">PROOF PLATINUM</a></TD>
   </TR>
  </TABLE>

  <TABLE id="Table9" cellSpacing="1" cellPadding="1" width="100%" border="1">
   <TR>


<td align=center valign=top><b>
  <?php 
	echo get_Header ($db_con, 2);
	echo " - ";
	echo get_Section ($db_con, 1);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 2, 1);
  ?>
 </td></b>

 <td align=center valign=top><b>
  <?php 
	echo get_Header ($db_con, 2);
	echo " - ";
	echo get_Section ($db_con, 5);
	echo "<br>";
	echo create_Matrix ($db_con, $custnum, 2, 5);
  ?>
 </td></b>

 <td align=center valign=top><b>
  <?php 
   echo get_Header ($db_con, 2);
   echo " - ";
   echo get_Section ($db_con, 2);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 2, 2);
  ?>
 </td></b>

 <td align=center valign=top><b>
  <?php 
   echo get_Header ($db_con, 2);
   echo " - ";
   echo get_Section ($db_con, 6);
   echo "<br>";
   echo create_Matrix ($db_con, $custnum, 2, 6);
  ?>
 </td></b>
 </TR>
   
   </TR>
  </TABLE>


  <TABLE align=center id="Table12" cellSpacing="1" cellPadding="1" width="36%" border="1" style="FONT-WEIGHT: bold">
   <TR><td align=center colspan=2><b><a name="pre33">PRE - 1933</b></a></td>
   </TR>
   <TR>
<?php
   $counter2=0;
echo "<td align=center width=/'90%/'><b>"."DATE / DENOM / DESC / CONDITION / GRADE"."</td></b><td width=/'10%/'><b>QUANTITY</td></b>";
$array4 = get_Pre33 ($db_con, $custnum);
	foreach ($array4 as $element){
		echo "<tr><td><b>";
		  echo $array4[$counter2][0]."</b></td><b><td align=center>";
		   echo $array4[$counter2][1]."</td></b></tr>";
		   $counter2++;
   }
    echo "<br>";
   

?>
   </TR>
  </TABLE>
 </body>
</html>
