<?php
session_start();
require ('DB_Login.php');

$debug=0;

/////////////////////////////////////////////////////////////////////
// START Test for Permissions
/////////////////////////////////////////////////////////////////////

$login		=$_SESSION['User_ID'];
$securitylevel	=$_SESSION['Security_Level'];
$securitygroup	=$_SESSION['Security_Group'];
$sales_manager	=$_SESSION['Sales_Manager'];
$sales_team	=$_SESSION['Sales_Team'];
$sales_rep_name	=$_SESSION['Sales_Rep_Name'];
$isManager	=$_SESSION['isManager'];
$myTeam		=$_SESSION['isTeam'];
$today		=GetDate();

/*
IF ($login=='AG' || $login='SSM' || $isManager=='Yes' || $securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator') //OR IF ($securitygroup=='Developer') 
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}
 */

/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////



//$DB_Conn1 = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); //USRCREP02
//mssql_select_db ( $DB2_Database, $DB_Conn1 );

$DB_Conn1 = mssql_connect($DB20_Host, $DB20_UserName, $DB20_Password); //USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB_Conn1 );

If ($debug==1) {	
	IF (! $DB_Conn1) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB2_Host." Server, ".$DB2_Database." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo "Debug Mode: ON <br> Successfully connected to ".$DB2_Host." Server, ".$DB2_Database." Database. <br />";
		echo "File Name: Sales_Media_Report_Team_OB.php<br>";
	}
};

$DB_Conn2 = mssql_connect($DB0_Host, $DB0_UserName, $DB0_Password); //USRCAPPSRVR01
mssql_select_db ( $DB0_Database, $DB_Conn2 );

If ($debug==1) {	
	IF (! $DB_Conn2) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB0_Host." Server, ".$DB0_Database." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo "Debug Mode: ON <br> Successfully connected to ".$DB0_Host." Server, ".$DB0_Database." Database. <br />";
		echo "File Name: Sales_Media_Report_Team_OB.php<br>";
	}
};


IF ($_GET['Sales_Team']!='' ) {
$sales_team	=$_GET['Sales_Team'];
$sales_manager	=$_GET['Sales_Manager'];
$sales_id	='ALL';
}
else {
$Index_ID	=$_GET['$Index_ID'];
$team		=$_SESSION['Team_Media_CVR'];
$sales_team	=$team[$Index_ID][0];
$sales_manager	=$team[$Index_ID][1];
$sales_id	='ALL';
}

$today = getdate();

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("LightYellow", "FFFF99");
define("White", "FFFFFF");
$tbl_bgcolor="Yellow";

function get_Team_Members($DB_Conn1, $sales_manager, $debug) {

	if ($sales_manager=='All') {
		$SQL_Sales_Manager=" 1=1 ";
	}
	else {
		$SQL_Sales_Manager=" (tST.Sales_Manager='".$sales_manager."' OR tST.Sales_Manager LIKE '".substr($sales_manager, 0, 10)."%')";
	};
	 
	$query1="SELECT 
		tST.[PKUsers], 
		tST.[Name], 
		tST.[Login], 
		'Team' + SUBSTRING(tST.Sales_Manager, PATINDEX('% %', tST.Sales_Manager), LEN(tST.Sales_Manager)) AS Team,
		tST.[Sales_Manager], 
		tST.[Site], 
		ISNULL(SUM(tMS.Bump_Value), 0) AS IB_Bump_Sales 
		FROM [Data_Warehouse].[dbo].[tbl_Sales_Teams] tST
		LEFT JOIN [Data_Warehouse].[dbo].[tbl_Media_Sales_MTD_OB] tMS
		ON tST.[Name]=tMS.[Name]
		WHERE tST.[Name] NOT LIKE 'Z%' 
		AND tST.PKUsers NOT LIKE '999%' 
		AND tST.[Site] <> 'Company'
		AND ".$SQL_Sales_Manager."
		AND tST.[Active] = 1 
		GROUP BY 
		tST.[PKUsers], 
		tST.[Name], 
		tST.[Login], 
		tMS.[Team],
		tST.[Sales_Manager],
		tST.[Site]
		ORDER BY 
		SUM(tMS.Bump_Value) DESC";

	$result1=mssql_query($query1, $DB_Conn1);
	$numrows1=mssql_num_rows($result1);
	$_SESSION['Team_Count1']=$numrows1;

	for($i=0;$i<$numrows1;$i+=1){
		$answer[$i][0]=mssql_result($result1, $i, 0);// PKUser
		$answer[$i][1]=mssql_result($result1, $i, 1);// Name
		$answer[$i][2]=mssql_result($result1, $i, 2);// Login
		$answer[$i][3]=mssql_result($result1, $i, 3);// Team
		$answer[$i][4]=mssql_result($result1, $i, 4);// Sales Manager
		$answer[$i][5]=mssql_result($result1, $i, 5);// Site
		$answer[$i][6]=mssql_result($result1, $i, 6);// MTD Sales
	}

	if ($debug==2){
		if (! $DB_Conn1) {
			DIE ("Could not connect to Database within Team Member Query. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Database within Team Member Query. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Team Query Looks Like:<br> '.$query1);
		echo ('<br>Manager Team Count is: '.$numrows1);
		echo ('<br>Session Team Count is: '.$_SESSION['Team_Count1']);
		echo ('<br>Session Team Answer is: '.$answer[0][0]);
		echo ('<br>Session Team Answer is: '.$answer[0][1]);
		echo ('<br>');
	}
	Return $answer;

}; //end function get_Team_Rosters($DB_Conn, $room, $debug) 

function Get_Daily_Data_Today ($DB_Conn2, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp0 = mssql_init ( "dbo.usp_Media_Report_Summary_Daily_CVR", $DB_Conn2 ); //init stored procedure  
	mssql_bind ( $sp0, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp0, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result0);
	$result0 = mssql_execute($sp0);

	$numrows0 = mssql_num_rows($result0);
	$_SESSION['List_Count1_CVR'] = $numrows0;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result0)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);
		    
		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][14]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result0));

	if ($debug==1){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp0);
		echo ('<br>results: '.$result0);
		echo ('<br>numrows: '.$numrows0);
		echo ('<br>Searching for rep: '.$in_Sales_Rep_Name);
		echo ('<br>Searching for team: '.$in_Sales_Team);
		echo ('<br>database connection: '.$DB_Conn2);

		if (! $DB_Conn2) {
			DIE ("<br>Could not connect to ".$DB0_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB0_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Daily_Data_Today ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Daily_Data_Today_OB ($DB_Conn2, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp0 = mssql_init ( "dbo.usp_Media_Report_Summary_Daily_OB", $DB_Conn2 ); //init stored procedure  
	mssql_bind ( $sp0, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp0, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result0);
	$result0 = mssql_execute($sp0);

	$numrows0 = mssql_num_rows($result0);
	$_SESSION['List_Count1_OB'] = $numrows0;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result0)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);
		    
		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][14]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result0));

	if ($debug==1){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp0);
		echo ('<br>results: '.$result0);
		echo ('<br>numrows: '.$numrows0);
		echo ('<br>Searching for rep: '.$in_Sales_Rep_Name);
		echo ('<br>Searching for team: '.$in_Sales_Team);
		echo ('<br>database connection: '.$DB_Conn2);

		if (! $DB_Conn2) {
			DIE ("<br>Could not connect to ".$DB0_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB0_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Daily_Data_Today_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)


function Get_Month_to_Date_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp2 = mssql_init ( "dbo.usp_Media_Report_Summary_MTD_CVR", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp2, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp2, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result2);
	$result2 = mssql_execute($sp2);

	$numrows2 = mssql_num_rows($result2);
	$_SESSION['List_Count2_CVR'] = $numrows2;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result2)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);

		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][14]);

		    $i=$i+1;
	    }
	} while (mssql_next_result($result2));

	if ($debug==1){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp2);
		echo ('<br>results: '.$result2);
		echo ('<br>numrows: '.$numrows2);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Previous_Month_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Month_to_Date_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp2 = mssql_init ( "dbo.usp_Media_Report_Summary_MTD_OB", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp2, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp2, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result2);
	$result2 = mssql_execute($sp2);

	$numrows2 = mssql_num_rows($result2);
	$_SESSION['List_Count2_OB'] = $numrows2;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result2)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);

		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][14]);

		    $i=$i+1;
	    }
	} while (mssql_next_result($result2));

	if ($debug==1){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp2);
		echo ('<br>results: '.$result2);
		echo ('<br>numrows: '.$numrows2);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Previous_Month_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)


function Get_Previous_Month_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{

	$sp30 = mssql_init ( "dbo.usp_Media_Report_Summary_PM01_CVR", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp30, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp30, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

//result3 = mssql_execute ( $sp3 ); //execute the stored procedure  
//	$numrows= mssql_num_rows ($result3); 
//	$textout =  mssql_result ( $result3, 0, 'Text' ); //process the results (row 0) 

	mssql_free_result($result30);
	$result30 = mssql_execute($sp30);

	$numrows30 = mssql_num_rows($result30);
	$_SESSION['List_Count3_CVR'] = $numrows30;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result30)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);
		    
		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][14]);

		    $i=$i+1;
	    }
	} while (mssql_next_result($result30));

	if ($debug==1){
		echo ('<br>In PM01 CVR Data<br>'); 
		echo ('<br>stored procedure: '.$sp30);
		echo ('<br>$in_Sales_Rep_Name: '.$in_Sales_Rep_Name);
		echo ('<br>$in_Sales_Team: '.$in_Sales_Team);

		echo ('<br>results: '.$result30);
		echo ('<br>numrows: '.$numrows30);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);
		echo ('<br>database name: '.$DB2_Database);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Previous_Month_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Previous_Month_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{

	$sp3 = mssql_init ( "dbo.usp_Media_Report_Summary_PM01_OB", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp3, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp3, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

//result3 = mssql_execute ( $sp3 ); //execute the stored procedure  
//	$numrows= mssql_num_rows ($result3); 
//	$textout =  mssql_result ( $result3, 0, 'Text' ); //process the results (row 0) 

	mssql_free_result($result3);
	$result3 = mssql_execute($sp3);

	$numrows3 = mssql_num_rows($result3);
	$_SESSION['List_Count3_OB'] = $numrows3;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result3)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);

		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][14]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result3));

	if ($debug==1){
		echo ('<br>In PM01 OB Data<br>'); 
		echo ('<br>stored procedure: '.$sp3);
		echo ('<br>$in_Sales_Rep_Name: '.$in_Sales_Rep_Name);
		echo ('<br>$in_Sales_Team: '.$in_Sales_Team);

		echo ('<br>results: '.$result3);
		echo ('<br>numrows: '.$numrows3);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);
		echo ('<br>database name: '.$DB2_Database);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Previous_Month_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)



function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	global $tbl_bgcolor;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}


?>

<html>
<title>USMR Media Sales Analysis</title>
<head>

<script type="text/javascript">
function show_sales_rep(Index_ID2){
	<!--
	str_redirect2='./SalesRep_Media_Report_Team_Member_CVR.php?$Index_ID='+Index_ID2
	window.open (str_redirect2, 'Asset_Window_'+Index_ID2, config='height=825, width=1150, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
}
</script>

</head>
	
<body>
<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);


// HEADER
echo ('	<table align=center width=800>
	<tr style="font-size:24pt;">
	<td align=center><b>Outbound Summary: Team Statistics</b>
	</td>
	</tr>

	<tr style="font-size:20pt;">
	<td align=center><b>Outbound Sales</b>
	</td>
	</tr>

	<tr style="font-size:18pt;">
	<td align=center><b>'.$sales_team.': '.$sales_manager.'</b>
	</td>
	</tr>');

/*
echo ('	<tr>
	<td align=center>
	<button align=center onclick="window.close()">Close</button>
	</td>
	</tr>');
 */

echo ('	<tr style="font-size:12pt;">
	<td align=center><i>For the Period Ending</i>
	</td>
	</tr>

	<tr style="font-size:12pt;">
	<td align=center>'.$today[weekday].', '.$today[month].' '.$today[mday].', '.$today[year].'
	</td>
	</tr>

	</table>');


//echo ('	</table>');

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Sales'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="SalesRep_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Sales_Managers'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_SalesManagers_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Sales_Operations'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_SalesOperations_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}





	// BODY

echo ('<br><center style="font-size:16pt;"><b>Sales Agents</>');

$team_member=get_Team_Members($DB_Conn1, $sales_manager, $debug);
$_SESSION['Sales_Rep_Media_CVR']=$team_member;

echo ('	<table align="center" class="sortable" title="Click row header to sort team summary."><tr>');
	format_tbl_header("Rank", 50, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep", 200, center, $hdr_bgcolor);
	format_tbl_header("Login", 50, center, $hdr_bgcolor);
	format_tbl_header("Team", 125, center, $hdr_bgcolor);
	format_tbl_header("Manager", 125, center, $hdr_bgcolor);
	format_tbl_header("Room", 125, center, $hdr_bgcolor);
	format_tbl_header("MTD OB Sales", 125, center, $hdr_bgcolor);
	echo ('</tr>');

	for ($i=0; $i<$_SESSION['Team_Count1']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}

	echo ('<tr onClick="show_sales_rep('.($i).')" title="Click row to show sales rep detail.">');		
//	echo ('<tr>');
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
//	format_tbl_content($team_member[$i][1], 200, center, $row_bgcolor);	//Sales Rep

	echo ('<td align=center valign=bottom bgcolor='.$row_bgcolor.' >
		<font color="#0000FF">
		<u>'.$team_member[$i][1].'</u></font>');

	format_tbl_content($team_member[$i][2], 50, center, $row_bgcolor);	//Login
	format_tbl_content($team_member[$i][3], 125, center, $row_bgcolor);	//Team
	format_tbl_content($team_member[$i][4], 125, center, $row_bgcolor);	//Manager
	format_tbl_content($team_member[$i][5], 125, center, $row_bgcolor);	//Room
	format_tbl_content(('$'.number_format($team_member[$i][6], 2)), 125, center, $row_bgcolor);	//MTD IB Sales
	echo ('</tr>');
	}	
	echo ('</table>');	
	
	
	
echo ('<br><center style="font-size:16pt;"><b>Team Summary</>');

echo ('	<table align="center" width=1350>
	<tr>');

echo ('<tr>	<td colspan=16 align=center bgcolor="LightGrey"><b>DAILY</b></td>
	</tr>');

	format_tbl_header("Original Media Type<br>and<br>Loadbook Value Range", 400, center);
	format_tbl_header("Leads", 125, center);
	format_tbl_header("%<br>of<br>Book", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Dials", 50, center);
	format_tbl_header("Leads<br>Dialed", 50, center);
	format_tbl_header("Leads<br>Presented", 75, center);
	format_tbl_header("% of Dialed<br>Presented", 125, center);
	format_tbl_header("Leads<br>Not<br>Called", 75, center);
	format_tbl_header("%<br>Not<br>Called", 75, center);
	format_tbl_header("Certified<br>Orders", 125, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing Ratio", 75, center);
//	format_tbl_header("Certified<br>Pending", 50, center);
	format_tbl_header("Certified<br>Average<br>Ticket", 125, center);
	format_tbl_header("Loadbook<br>Value", 125, center);
	
	echo ('</tr>');


//	Outbound

	$Answers10 = Get_Daily_Data_Today_OB ($DB_Conn2, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count1_OB']; $i+=1){

	if($Answers10[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers10[$i][0], 450, left, $row_bgcolor);					// Media
	format_tbl_content(number_format($Answers10[$i][1], 0), 125, right, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers10[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers10[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers10[$i][4], 0), 50, right, $row_bgcolor);		// Dialed	
	format_tbl_content(number_format($Answers10[$i][5], 0), 50, right, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers10[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers10[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers10[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers10[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers10[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers10[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers10[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers10[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers10[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers10[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value	

	echo ('</tr>');
	}

//	Customer Value Range	
	$Answers1 = Get_Daily_Data_Today ($DB_Conn2, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count1_CVR']; $i+=1){

	if($Answers1[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers1[$i][0], 450, left, $row_bgcolor);					// Media
	format_tbl_content(number_format($Answers1[$i][1], 0), 125, right, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers1[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers1[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers1[$i][4], 0), 50, right, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers1[$i][5], 0), 50, right, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers1[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers1[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers1[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers1[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers1[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers1[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers1[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers1[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers1[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers1[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value
	echo ('</tr>');
	}


echo ('	</table><table align="center" width=1350>');


echo 	('<tr>
	<td colspan=16 align=center bgcolor="LightGrey"><b>MONTH TO DATE</b></td>
	</tr>
	<tr>');

	echo ('</tr>');

echo	('<tr>');

	format_tbl_header("Original Media Type<br>and<br>Loadbook Value Range", 400, center);
	format_tbl_header("Leads", 125, center);
	format_tbl_header("%<br>of<br>Book", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Dials", 50, center);
	format_tbl_header("Leads<br>Dialed", 50, center);
	format_tbl_header("Leads<br>Presented", 75, center);
	format_tbl_header("% of Dialed<br>Presented", 125, center);
	format_tbl_header("Leads<br>Not<br>Called", 75, center);
	format_tbl_header("%<br>Not<br>Called", 75, center);
	format_tbl_header("Certified<br>Orders", 125, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing Ratio", 75, center);
//	format_tbl_header("Certified<br>Pending", 50, center);
	format_tbl_header("Certified<br>Average<br>Ticket", 125, center);
	format_tbl_header("Loadbook Value", 125, center);
	
	echo ('</tr>');



//	Outbound
	$Answers20 = Get_Month_to_Date_Data_OB ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count2_OB']; $i+=1){

	if($Answers20[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers20[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content(number_format($Answers20[$i][1], 0), 125, right, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers20[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers20[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers20[$i][4], 0), 50, right, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers20[$i][5], 0), 50, right, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers20[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers20[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers20[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers20[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers20[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers20[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers20[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers2[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers20[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers20[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value

	echo ('</tr>');
	}
	

//	Customer Value Range
	$Answers2 = Get_Month_to_Date_Data ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count2_CVR']; $i+=1){

	if($Answers2[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers2[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content(number_format($Answers2[$i][1], 0), 125, right, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers2[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers2[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers2[$i][4], 0), 50, right, $row_bgcolor);		// Dialed	
	format_tbl_content(number_format($Answers2[$i][5], 0), 50, right, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers2[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers2[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers2[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers2[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers2[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers2[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers2[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers2[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers2[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers2[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value

	echo ('</tr>');
	}

	echo ('	</table>');
/*
	echo ('	<table align="center" width=1350>');
	echo ('	<tr>
	<td colspan=16 align=center bgcolor="LightGrey"><b>PREVIOUS MONTH</b></td>
	</tr>
	<tr>');

	echo ('</tr>');

	echo	('<tr>');

	format_tbl_header("Original Media Type<br>and<br>Loadbook Value Range", 400, center);
	format_tbl_header("Leads", 125, center);
	format_tbl_header("%<br>of<br>Book", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Dials", 50, center);
	format_tbl_header("Leads<br>Dialed", 50, center);
	format_tbl_header("Leads<br>Presented", 75, center);
	format_tbl_header("% of Dialed<br>Presented", 125, center);
	format_tbl_header("Leads<br>Not<br>Called", 75, center);
	format_tbl_header("%<br>Not<br>Called", 75, center);
	format_tbl_header("Certified<br>Orders", 125, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing Ratio", 75, center);
//	format_tbl_header("Certified<br>Pending", 50, center);
	format_tbl_header("Certified<br>Average<br>Ticket", 125, center);
	format_tbl_header("Loadbook Value", 125, center);	
	
	echo ('</tr>');

	
//	Outbound
	$Answers30 = Get_Previous_Month_Data_OB ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count3_OB']; $i+=1){

	if($Answers30[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers30[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content(number_format($Answers30[$i][1], 0), 125, right, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers30[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers30[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers30[$i][4], 0), 50, right, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers30[$i][5], 0), 50, right, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers30[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers30[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers30[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers30[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers30[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers30[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers30[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers2[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers30[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers30[$i][14], 2)), 125, right, $row_bgcolor);		// Average Ticket	

	echo ('</tr>');
	}



//	Customer Value Range	
	$Answers3 = Get_Previous_Month_Data ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count3_CVR']; $i+=1){

	if($Answers3[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers3[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content(number_format($Answers3[$i][1], 0), 125, right, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers3[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers3[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers3[$i][4], 0), 50, right, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers3[$i][5], 0), 50, right, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers3[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers3[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers3[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers3[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers3[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers3[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers3[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers3[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers3[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers3[$i][14], 2)), 125, right, $row_bgcolor);		// Average Ticket

	echo ('</tr>');
	}

	echo ('</table><br>');

*/


?>
</body>
</html>
