<?php
session_start();

$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login		=$_SESSION['User_ID'];
$securitylevel	=$_SESSION['Security_Level'];
$securitygroup	=$_SESSION['Security_Group'];
$sales_manager	=$_SESSION['Sales_Manager'];
$sales_team	=$_SESSION['Sales_Team'];
$sales_rep_name	=$_SESSION['Sales_Rep_Name'];
$isManager	=$_SESSION['isManager'];
$today		=GetDate();

IF ($login=='AG' || $login='SSM' || $isManager=='Yes' || $securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator') //OR IF ($securitygroup=='Developer') 
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}

/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require_once ('DB_Login.php');


$DB_Conn1 = mssql_connect($DB20_Host, $DB20_UserName, $DB20_Password); //USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB_Conn1 );


//$DB_Conn1 = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); //USRCREP02
//mssql_select_db ( $DB2_Database, $DB_Conn1 );

If ($debug==1) {	
	IF (! $DB_Conn1) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB2_Host." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Debug Mode: ON <br> Successfully connected to ".$DB2_Host." database. <br />";}
};


$DB_Conn2 = mssql_connect($DB0_Host, $DB0_UserName, $DB0_Password); //USRCAPPSRVR01
mssql_select_db ( $DB0_Database, $DB_Conn2 );

If ($debug==1) {	
	IF (! $DB_Conn2) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB0_Host." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo "Debug Mode: ON <br> Successfully connected to ".$DB0_Host." database. <br />";
		echo "File Name: Sales_Media_Report_Team.php<br>";
	}
};


$Index_ID	=$_GET['$Index_ID'];
$team_roster	=$_SESSION['Sales_Rep_Media'];
$sales_rep_name	=$team_roster[$Index_ID][1];
$sales_id	=$team_roster[$Index_ID][2];
$sales_team	=$team_roster[$Index_ID][3];


$today = getdate();

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("LightYellow", "FFFF99");
define("White", "FFFFFF");
$tbl_bgcolor="Yellow";

function Get_Daily_Data_Today ($DB_Conn2, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp0 = mssql_init ( "dbo.usp_Media_Report_Summary_Daily", $DB_Conn2 ); //init stored procedure  
	mssql_bind ( $sp0, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp0, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result0);
	$result0 = mssql_execute($sp0);

	$numrows0 = mssql_num_rows($result0);
	$_SESSION['List_Count1'] = $numrows0;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result0)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result0));

	if ($debug==1){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp0);
		echo ('<br>results: '.$result0);
		echo ('<br>numrows: '.$numrows0);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn2);

		if (! $DB_Conn2) {
			DIE ("<br>Could not connect to ".$DB0_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB0_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Daily_Data_Today ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)


function Get_Daily_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp1 = mssql_init ( "dbo.usp_Media_Report_Summary_Daily", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp1, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp1, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result1);
	$result1 = mssql_execute($sp1);

	$numrows1 = mssql_num_rows($result1);
	$_SESSION['List_Count1'] = $numrows1;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result1)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result1));

	if ($debug==2){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp1);
		echo ('<br>results: '.$result1);
		echo ('<br>numrows: '.$numrows1);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Daily_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Month_to_Date_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp2 = mssql_init ( "dbo.usp_Media_Report_Summary_MTD", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp2, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp2, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result2);
	$result2 = mssql_execute($sp2);

	$numrows2 = mssql_num_rows($result2);
	$_SESSION['List_Count2'] = $numrows2;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result2)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result2));

	if ($debug==2){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp2);
		echo ('<br>results: '.$result2);
		echo ('<br>numrows: '.$numrows2);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Previous_Month_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Previous_Month_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp3 = mssql_init ( "dbo.usp_Media_Report_Summary_PM01", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp3, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp3, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result3);
	$result3 = mssql_execute($sp3);

	$numrows3 = mssql_num_rows($result3);
	$_SESSION['List_Count3'] = $numrows3;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result3)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result3));

	if ($debug==2){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp3);
		echo ('<br>results: '.$result3);
		echo ('<br>numrows: '.$numrows3);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}
	}
	Return $answer; 

} // function Get_Previous_Month_Data ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	global $tbl_bgcolor;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}

?>

<html>
<title>USRCBR Media Sales Analysis</title>
<head>

</head>
	
<body>
<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);


// HEADER
echo ('	<table align=center width=800>
	<tr style="font-size:24pt;">
	<td align=center><b>Media Summary: Sales Rep Statistics</b>
	</td>
	</tr>

	<tr style="font-size:20pt;">
	<td align=center><b>Inbound Sales</b>
	</td>
	</tr>

	<tr style="font-size:18pt;">
	<td align=center><b>'.$sales_team.': '.$sales_rep_name.'</b>
	</td>
	</tr>

	<tr>
	<td align=center>
	<button align=center onclick="window.close()">Close</button>
	</td>
	</tr>

	<tr style="font-size:12pt;">
	<td align=center><i>For the Period Ending</i>
	</td>
	</tr>

	<tr style="font-size:12pt;">
	<td align=center>'.$today[weekday].', '.$today[month].' '.$today[mday].', '.$today[year].'
	</td>
	</tr>

	</table>');


echo ('	</table>');


// BODY
echo ('	<table align="center" width=800>

	<tr>');

	format_tbl_header("Media", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Unique<br>Calls", 50, center);
	format_tbl_header("Certified<br>Orders", 75, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing<br>Ratio", 75, center);
	format_tbl_header("Bullion<br>Orders", 75, center);
	format_tbl_header("Bullion<br>Sales", 125, center);
	format_tbl_header("GR<br>Sent", 50, center);
	format_tbl_header("Certified<br>Average<br>Ticket", 125, center);
	
	echo ('</tr>');

	echo ('<tr>
	<td colspan=10 align=center bgcolor="LightGrey"><b>DAILY</b></td>
	</tr>');

	//$Answers = Get_Daily_Data ($DB_Conn1, $sales_id, $sales_team, $debug);
	$Answers = Get_Daily_Data_Today ($DB_Conn2, $sales_id, $sales_team, $debug);

	for ($i=0; $i<$_SESSION['List_Count1']; $i+=1){
	
	if($Answers[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers[$i][0], 125, left, $row_bgcolor);					// Media
	format_tbl_content($Answers[$i][1], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers[$i][2], 0), 50, center, $row_bgcolor);		// Calls
	format_tbl_content(number_format($Answers[$i][3], 0), 75, center, $row_bgcolor);		// Certified Orders
//	format_tbl_content(number_format($Answers[$i][4], 2), 125, right, $row_bgcolor);		// Certified Sales
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][4], 2).'</td>');
//	format_tbl_content($Answers[$i][5], 75, center, $row_bgcolor);					// Certified Closing Ratio
	echo ('<td width=125 align=center bgcolor='.$row_bgcolor.'>'.number_format($Answers[$i][5]*100, 1).'%</td>');
	format_tbl_content($Answers[$i][6], 75, center, $row_bgcolor);					// Bullion Orders
//	format_tbl_content($Answers[$i][7], 125, center, $row_bgcolor);					// Bullion Sales
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][7], 2).'</td>');
	format_tbl_content($Answers[$i][8], 50, center, $row_bgcolor);					// GR Sent
//	format_tbl_content($Answers[$i][9], 125, center, $row_bgcolor);					// Average Ticket
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][9], 2).'</td>');
	echo ('</tr>');
	}


echo 	('<tr>
	<td colspan=10 align=center bgcolor="LightGrey"><b>MONTH TO DATE</b></td>
	</tr>
	<tr>');

/*
	format_tbl_header("Media", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Calls", 50, center);
	format_tbl_header("Certified<br>Orders", 75, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing<br>Ratio", 75, center);
	format_tbl_header("Bullion<br>Orders", 75, center);
	format_tbl_header("Bullion<br>Sales", 125, center);
	format_tbl_header("GR<br>Sent", 50, center);
	format_tbl_header("Average<br>Ticket", 125, center);
*/

	echo ('</tr>');

	$Answers = Get_Month_to_Date_Data ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count2']; $i+=1){

	if($Answers[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers[$i][0], 125, left, $row_bgcolor);					// Media
	format_tbl_content($Answers[$i][1], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers[$i][2], 0), 50, center, $row_bgcolor);		// Calls
	format_tbl_content(number_format($Answers[$i][3], 0), 75, center, $row_bgcolor);		// Certified Orders
//	format_tbl_content(number_format($Answers[$i][4], 2), 125, right, $row_bgcolor);		// Certified Sales
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][4], 2).'</td>');
//	format_tbl_content($Answers[$i][5], 75, center, $row_bgcolor);					// Certified Closing Ratio
	echo ('<td width=125 align=center bgcolor='.$row_bgcolor.'>'.number_format($Answers[$i][5]*100, 1).'%</td>');
	format_tbl_content($Answers[$i][6], 75, center, $row_bgcolor);					// Bullion Orders
//	format_tbl_content($Answers[$i][7], 125, center, $row_bgcolor);					// Bullion Sales
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][7], 2).'</td>');
	format_tbl_content($Answers[$i][8], 50, center, $row_bgcolor);					// GR Sent
//	format_tbl_content($Answers[$i][9], 125, center, $row_bgcolor);					// Average Ticket
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][9], 2).'</td>');
	echo ('</tr>');
	}

/*
echo ('	<tr>
	<td colspan=10 align=center bgcolor="LightGrey"><b>PREVIOUS MONTH</b></td>
	</tr>

	<tr>');


	format_tbl_header("Media", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Calls", 50, center);
	format_tbl_header("Certified<br>Orders", 75, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing<br>Ratio", 125, center);
	format_tbl_header("Bullion<br>Orders", 75, center);
	format_tbl_header("Bullion<br>Sales", 125, center);
	format_tbl_header("GR<br>Sent", 50, center);
	format_tbl_header("Average<br>Ticket", 125, center);
*/

	echo ('</tr>');
/*
	$Answers = Get_Previous_Month_Data ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count3']; $i+=1){

	if($Answers[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers[$i][0], 125, left, $row_bgcolor);					// Media
	format_tbl_content($Answers[$i][1], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers[$i][2], 0), 50, center, $row_bgcolor);		// Calls
	format_tbl_content(number_format($Answers[$i][3], 0), 75, center, $row_bgcolor);		// Certified Orders
//	format_tbl_content(number_format($Answers[$i][4], 2), 125, right, $row_bgcolor);		// Certified Sales
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][4], 2).'</td>');
//	format_tbl_content($Answers[$i][5], 75, center, $row_bgcolor);					// Certified Closing Ratio
	echo ('<td width=125 align=center bgcolor='.$row_bgcolor.'>'.number_format($Answers[$i][5]*100, 1).'%</td>');
	format_tbl_content($Answers[$i][6], 75, center, $row_bgcolor);					// Bullion Orders
//	format_tbl_content($Answers[$i][7], 125, center, $row_bgcolor);					// Bullion Sales
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][7], 2).'</td>');
	format_tbl_content($Answers[$i][8], 50, center, $row_bgcolor);					// GR Sent
//	format_tbl_content($Answers[$i][9], 125, center, $row_bgcolor);					// Average Ticket
	echo ('<td width=125 align=right bgcolor='.$row_bgcolor.'>$'.number_format($Answers[$i][9], 2).'</td>');
	echo ('</tr>');
	}

*/	
	echo ('</table><br><br>');


?>
</body>
</html>
