<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login		=$_SESSION['User_ID'];
$securitylevel	=$_SESSION['Security_Level'];
$securitygroup	=$_SESSION['Security_Group'];
$sales_manager	=$_SESSION['Sales_Manager'];
$sales_team	=$_SESSION['Sales_Team'];
$sales_rep_name	=$_SESSION['Sales_Rep_Name'];
$isManager	=$_SESSION['isManager'];
$today		=GetDate();

IF ($securitygroup=='BSS' || $login=='AG' || $login=='SSM' || $isManager=='Yes' || $securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator') //OR IF ($securitygroup=='Developer') 
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}

/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////
require ('DB_Login.php');
require ('PHP_Functions.php');



$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRCAPPSRVR01
mssql_select_db ($DB0_Database, $DB1_Conn);

If ($debug==1) {	
	IF (! $DB1_Conn) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB0_Host." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo "Debug Mode: ON <br> Successfully connected to ".$DB0_Host." database. <br />";
		echo "File Name: Sales_Media_Report_Team_Roster.php";
	}
};

$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB2_Database, $DB2_Conn);

If ($debug==1) {	
	IF (! $DB2_Conn) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB2_Host." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Debug Mode: ON <br> Successfully connected to ".$DB2_Host." database. <br />";}
};

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("LightYellow", "FFFF99");
define("White", "FFFFFF");
define("Green", "00CC33");
$hdr_bgcolor="Yellow";

function get_Team ($DB_Conn, $debug) {
 
	$query1="SELECT
		Team,
		Sales_Manager,
		[Site],
		SUM(IB_Bump_Sales) AS IB_Bump_Sales
		FROM (	SELECT 
			'Team' + SUBSTRING(tST.Sales_Manager, PATINDEX('% %', tST.Sales_Manager), LEN(tST.Sales_Manager)) AS Team,
			tST.[Sales_Manager], 
			tST.[Site], 
			ISNULL(SUM(tMS.Bump_Value), 0) AS IB_Bump_Sales 
			FROM [Data_Warehouse].[dbo].[tbl_Media_Sales_MTD] tMS
			RIGHT JOIN [Data_Warehouse].[dbo].[tbl_Sales_Teams] tST
			ON tST.[Name]=tMS.[Name]
			WHERE tST.[Name] NOT LIKE 'Z%' 
			AND tST.PKUsers NOT LIKE '999%' 
			AND tST.Sales_Manager IS NOT NULL 
			AND tST.[Site] <> 'Company'
			AND tST.[Active] = 1 
			GROUP BY 
			tMS.[Team],
			tST.[Sales_Manager],
			tST.[Site]
			HAVING SUM(tMS.Bump_Value) > 0
			) AS vw1
		GROUP BY
		Team,
		Sales_Manager,
		[Site]		
		ORDER BY
		SUM(IB_Bump_Sales) DESC";

	$result1=mssql_query($query1, $DB_Conn);
	$numrows1=mssql_num_rows($result1);
	$_SESSION['Roster_Count1']=$numrows1;

	for($i=0;$i<$numrows1;$i+=1){
		$answer[$i][0]=mssql_result($result1, $i, 0);// Team
		$answer[$i][1]=mssql_result($result1, $i, 1);// Sales Manager
		$answer[$i][2]=mssql_result($result1, $i, 2);// Site
		$answer[$i][3]=mssql_result($result1, $i, 3);// MTD Sales
	}

	if ($debug==1){
		if (! $DB_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Query Looks Like:<br> '.$query1);
		echo ('<br>Manager count is: '.$numrows1);

		echo ('<br>');
	}
	Return $answer;
}; //end function get_Team_Rosters($DB_Conn, $room, $debug) 


function get_Team_Rosters($DB_Conn, $room, $debug) {

	if ($room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" Site='".$room."'";
	};
	 
	$query="SELECT 
		tST.[PKUsers], 
		tST.[Name], 
		tST.[Login], 
		'Team' + SUBSTRING(tST.Sales_Manager, PATINDEX('% %', tST.Sales_Manager), LEN(tST.Sales_Manager)) AS Team,
		tST.[Sales_Manager], 
		tST.[Site], 
		ISNULL(SUM(tMS.Bump_Value), 0) AS IB_Bump_Sales 
		FROM [Data_Warehouse].[dbo].[tbl_Sales_Teams] tST
		LEFT JOIN [Data_Warehouse].[dbo].[tbl_Media_Sales_MTD] tMS
		ON tST.[Name]=tMS.[Name]
		WHERE tST.[Name] NOT LIKE 'Z%' 
		AND tST.PKUsers NOT LIKE '999%' 
		AND tST.Sales_Manager IS NOT NULL 
		AND tST.[Site] <> 'Company'
		AND ".$SQL_Room."
		AND tST.[Active] = 1 
		GROUP BY 
		tST.[PKUsers], 
		tST.[Name], 
		tST.[Login], 
		tMS.[Team],
		tST.[Sales_Manager],
		tST.[Site]
		ORDER BY 
		SUM(tMS.Bump_Value) DESC";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Roster_Count2']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);// PKUser
		$answer[$i][1]=mssql_result($result, $i, 1);// Name
		$answer[$i][2]=mssql_result($result, $i, 2);// Login
		$answer[$i][3]=mssql_result($result, $i, 3);// Team
		$answer[$i][4]=mssql_result($result, $i, 4);// Sales Manager
		$answer[$i][5]=mssql_result($result, $i, 5);// Site
		$answer[$i][6]=mssql_result($result, $i, 6);// MTD Sales
	}

	if ($debug==2){
		if (! $DB_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Query Looks Like:<br> '.$query);
		echo ('<br>Manager count is: '.$numrows);
		echo ('<br>Session Count is: '.$_SESSION['Roster_Count_'.$room]);

		echo ('<br>');
	}
	Return $answer;
}; //end function get_Team_Rosters($DB_Conn, $room, $debug) 

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	global $hdr_bgcolor;
	echo $hdr_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
} // function format_tbl_header($label, $width, $alignment="center")

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
} // function format_tbl_content($content, $width, $alignment="left", $row_bgcolor)

?>
<html>

<head>

<script type="text/javascript">

function show_team(Index_ID1){
	<!--
	str_redirect1='./SalesRep_Media_Report_Team.php?$Index_ID='+Index_ID1
	window.open (str_redirect1, 'Asset_Window_'+Index_ID1, config='height=825, width=850, toolbar=no, menubar=yes, scrollbars=yes, resizable=yes, location=no, directories=no, status=yes')
	-->


	}


function show_sales_rep(Index_ID2){
	<!--
	str_redirect2='./SalesRep_Media_Report_Team_Member.php?$Index_ID='+Index_ID2
	window.open (str_redirect2, 'Asset_Window_'+Index_ID2, config='height=825, width=850, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->


	}

</script>

<script src="JS_Sort_Table.js"></script>

</head>

<title>USRCBR Media Report: Team Rosters</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);


if ($debug==2){
	echo ('<br>Posted Sales Room : '.$_POST["in_Room"]);
	echo ('<br>Posted Sales Manager : '.$_POST["in_Manager"]);
	echo ('<br>Posted Sales Rep : '.$_POST["in_SalesRep"]);
	echo ('<br>Posted enter date : '.$_POST["in_Enter_Date"]);
}

/***************MAIN CODE STARTS HERE ********************/

echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Sales'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="SalesRep_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}


echo ('<h2 align=center>Inbound Media Sales Analysis</h2>');

echo ('<center style="font-size:16pt;"><b>Teams</>');

$team_list=get_Team($DB2_Conn, $debug);
$_SESSION['Team_Media']=$team_list;
$MTD_IB_Sales_Total=0;

echo ('	<div id="header">
	<table align="center" class="sortable" title="Click row header to sort team summary."><tr>');
	format_tbl_header("Rank", 50, center, $hdr_bgcolor);
	format_tbl_header("Team", 150, center, $hdr_bgcolor);
	format_tbl_header("Manager", 150, center, $hdr_bgcolor);
	format_tbl_header("Room", 75, center, $hdr_bgcolor);
	format_tbl_header("MTD IB Sales", 125, center, $hdr_bgcolor);
	
echo ('</tr></div><div ID="body1">');

	for ($i=0; $i<$_SESSION['Roster_Count1']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}

//	echo ('<tr onClick="show_team('.($i).')" title="Click row to show team detail.">');		
	echo ('<tr>');
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
//	format_tbl_content($team_list[$i][0], 150, center, $row_bgcolor);	//Team
	echo ('<td align=center width=150 valign=bottom bgcolor='.$row_bgcolor.'>
		<a href="http://usrcrep01/php_reports/SalesRep_Media_Report_Team.php?
		Sales_Team='.$team_list[$i][0].'
		&Sales_Manager='.$team_list[$i][1].'">'.$team_list[$i][0].'</a></td>
		');

	format_tbl_content($team_list[$i][1], 150, center, $row_bgcolor);	//Manager
	format_tbl_content($team_list[$i][2], 75, center, $row_bgcolor);	//Room
	format_tbl_content(('$'.number_format($team_list[$i][3], 2)), 125, center, $row_bgcolor);	//MTD IB Sales
	echo ('</tr>');

	$MTD_IB_Sales_Total=$MTD_IB_Sales_Total+$team_list[$i][3];
	}	

	echo ('	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td align=right>Total</td>
		<td bgcolor="Yellow"><b><center>'.'$'.number_format($MTD_IB_Sales_Total, 2).'</b></td>');

	$_SESSION['$MTD_IB_Sales_Total']=$MTD_IB_Sales_Total;

	echo ('</table></div>');	


echo ('	<center style="font-size:16pt;"><b>Sales Agents</>');

$team_roster=get_Team_Rosters($DB2_Conn, 'All Sales Rooms', $debug);
$_SESSION['Sales_Rep_Media']=$team_roster;

echo ('	<div id="header">
	<table align="center" class="sortable" title="Click row header to sort team summary."><tr>');
	format_tbl_header("Rank", 50, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep", 200, center, $hdr_bgcolor);
	format_tbl_header("Login", 50, center, $hdr_bgcolor);
	format_tbl_header("Team", 125, center, $hdr_bgcolor);
	format_tbl_header("Manager", 125, center, $hdr_bgcolor);
	format_tbl_header("Room", 125, center, $hdr_bgcolor);
	format_tbl_header("MTD IB Sales", 125, center, $hdr_bgcolor);
	echo ('</tr></div><div ID="body1">');

	for ($i=0; $i<$_SESSION['Roster_Count2']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}

	echo ('<tr onClick="show_sales_rep('.($i).')" title="Click row to show sales rep detail.">');		
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
//	format_tbl_content($team_roster[$i][1], 200, center, $row_bgcolor);	//Sales Rep

	echo ('	<td align=center valign=bottom bgcolor='.$row_bgcolor.' >
		<font color="#0000FF"><u>'.$team_roster[$i][1].'</u></font>');


	echo ('</td>');

	format_tbl_content($team_roster[$i][2], 50, center, $row_bgcolor);	//Login
	format_tbl_content($team_roster[$i][3], 125, center, $row_bgcolor);	//Team
	format_tbl_content($team_roster[$i][4], 125, center, $row_bgcolor);	//Manager
	format_tbl_content($team_roster[$i][5], 125, center, $row_bgcolor);	//Room
	format_tbl_content(('$'.number_format($team_roster[$i][6], 2)), 125, center, $row_bgcolor);	//MTD IB Sales
	echo ('</tr>');
	}	
	echo ('</table></div>');	

?>

</html>
