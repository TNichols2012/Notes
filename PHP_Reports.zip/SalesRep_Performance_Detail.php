<?php
session_start();
require ('DB_Login.php');
$debug=1;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login		=$_SESSION['User_ID'];
$securitylevel	=$_SESSION['Security_Level'];
$securitygroup	=$_SESSION['Security_Group'];
$sales_manager	=$_SESSION['Sales_Manager'];
$sales_team	=$_SESSION['Sales_Team'];
$sales_rep_name	=$_SESSION['Sales_Rep_Name'];
$isManager	=$_SESSION['isManager'];
$today		=GetDate();

/*
IF ($login=='AG' || $login='SSM' || $isManager=='Yes' || $securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator') //OR IF ($securitygroup=='Developer') 
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}
*/
/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////





//$DB_Conn1 = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); //USRCREP02
//mssql_select_db ( $DB2_Database, $DB_Conn1 );
$DB_Conn1 = mssql_connect($DB20_Host, $DB20_UserName, $DB20_Password); //USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB_Conn1 );


If ($debug==1) {	
	IF (! $DB_Conn1) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB20_Host." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Debug Mode: ON <br> Successfully connected to ".$DB20_Host." database. <br />";}
};


$DB_Conn2 = mssql_connect($DB0_Host, $DB0_UserName, $DB0_Password); //USRCAPPSRVR01
mssql_select_db ( $DB0_Database, $DB_Conn2 );

If ($debug==1) {	
	IF (! $DB_Conn2) {
		DIE ("Debug Mode: ON <br>
			Could not connect to ".$DB0_Host." Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo "Debug Mode: ON <br> Successfully connected to ".$DB0_Host." database. <br />";
		echo "File Name: Sales_Media_Report_Team.php<br>";
	}
};


$Index_ID	=$_GET['$Index_ID'];
$team_roster	=$_SESSION['Sales_Rep_Media_CVR'];
$sales_rep_name	=$team_roster[$Index_ID][1];
$sales_id	=$team_roster[$Index_ID][2];
$sales_team	=$team_roster[$Index_ID][3];


$today = getdate();

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("LightYellow", "FFFF99");
define("White", "FFFFFF");
$tbl_bgcolor="Yellow";

function Get_Daily_Data_Today_OB ($DB_Conn2, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp0 = mssql_init ( "dbo.usp_Media_Report_Summary_Daily_OB", $DB_Conn2 ); //init stored procedure  
	mssql_bind ( $sp0, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp0, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result0);
	$result0 = mssql_execute($sp0);

	$numrows0 = mssql_num_rows($result0);
	$_SESSION['List_Count1_OB'] = $numrows0;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result0)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);
		    		    
		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][13]);


		    $i=$i+1;
	    }
	} while (mssql_next_result($result0));

	if ($debug==1){
		echo ('<br>In Media Sales Daily<br>'); 
		echo ('<br>stored procedure: '.$sp0);
		echo ('<br>results: '.$result0);
		echo ('<br>numrows: '.$numrows0);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn2);

		if (! $DB_Conn2) {
			DIE ("<br>Could not connect to ".$DB0_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB0_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Daily_Data_Today_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Daily_Data_Today_CVR ($DB_Conn2, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp0 = mssql_init ( "dbo.usp_Media_Report_Summary_Daily_CVR", $DB_Conn2 ); //init stored procedure  
	mssql_bind ( $sp0, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 50);
	mssql_bind ( $sp0, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result0);
	$result0 = mssql_execute($sp0);

	$numrows0 = mssql_num_rows($result0);
	$_SESSION['List_Count1_CVR'] = $numrows0;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result0)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);

		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][13]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result0));

	if ($debug==1){
		echo ('<br>In Media Sales Daily<br>'); 
		echo ('<br>stored procedure: '.$sp0);
		echo ('<br>results: '.$result0);
		echo ('<br>numrows: '.$numrows0);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn2);

		if (! $DB_Conn2) {
			DIE ("<br>Could not connect to ".$DB0_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB0_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Daily_Data_Today_CVR ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)


function Get_Month_to_Date_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp2 = mssql_init ( "dbo.usp_Media_Report_Summary_MTD_OB", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp2, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp2, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result2);
	$result2 = mssql_execute($sp2);

	$numrows2 = mssql_num_rows($result2);
	$_SESSION['List_Count2_OB'] = $numrows2;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result2)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);
		    
		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][13]);

		    $i=$i+1;
	    }
	} while (mssql_next_result($result2));

	if ($debug==2){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp2);
		echo ('<br>results: '.$result2);
		echo ('<br>numrows: '.$numrows2);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Month_to_Date_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Month_to_Date_Data_CVR ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp3 = mssql_init ( "dbo.usp_Media_Report_Summary_MTD_CVR", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp3, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp3, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result2);
	$result2 = mssql_execute($sp3);

	$numrows2 = mssql_num_rows($result2);
	$_SESSION['List_Count2_CVR'] = $numrows2;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result2)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);
		    
		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][13]);

		    $i=$i+1;
	    }
	} while (mssql_next_result($result2));

	if ($debug==2){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp3);
		echo ('<br>results: '.$result2);
		echo ('<br>numrows: '.$numrows2);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}

	}
	Return $answer; 

} // function Get_Month_to_Date_Data_CVR ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)


function Get_Previous_Month_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp3 = mssql_init ( "dbo.usp_Media_Report_Summary_PM01_OB", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp3, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp3, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result3);
	$result3 = mssql_execute($sp3);

	$numrows3 = mssql_num_rows($result3);
	$_SESSION['List_Count3_OB'] = $numrows3;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result3)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);

		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][13]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result3));

	if ($debug==1){
		echo ('<br>In PM01 Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp3);
		echo ('<br>$in_Sales_Rep_Name: '.$in_Sales_Rep_Name);
		echo ('<br>$in_Sales_Team: '.$in_Sales_Team);


		echo ('<br>results: '.$result3);
		echo ('<br>numrows: '.$numrows3);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}
	}
	Return $answer; 

} // function Get_Previous_Month_Data_OB ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)

function Get_Previous_Month_Data_CVR ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)
	{
        $sp3 = mssql_init ( "dbo.usp_Media_Report_Summary_PM01_CVR", $DB_Conn1 ); //init stored procedure  
	mssql_bind ( $sp3, '@in_Sales_ID', $in_Sales_Rep_Name, SQLVARCHAR, false, false, 25);
	mssql_bind ( $sp3, '@in_Sales_Team', $in_Sales_Team, SQLVARCHAR, false, false, 50);

	mssql_free_result($result3);
	$result3 = mssql_execute($sp3);

	$numrows3 = mssql_num_rows($result3);
	$_SESSION['List_Count3_CVR'] = $numrows3;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result3)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);

		    $answer[$i][5] = $row[5];
//		    print_r($answer[$i][5]);
		    
		    $answer[$i][6] = $row[6];
//		    print_r($answer[$i][6]);

		    $answer[$i][7] = $row[7];
//		    print_r($answer[$i][7]);

		    $answer[$i][8] = $row[8];
//		    print_r($answer[$i][8]);

		    $answer[$i][9] = $row[9];
//		    print_r($answer[$i][9]);

		    $answer[$i][10] = $row[10];
//		    print_r($answer[$i][10]);

		    $answer[$i][11] = $row[11];
//		    print_r($answer[$i][11]);

		    $answer[$i][12] = $row[12];
//		    print_r($answer[$i][12]);

		    $answer[$i][13] = $row[13];
//		    print_r($answer[$i][13]);

		    $answer[$i][14] = $row[14];
//		    print_r($answer[$i][13]);
		    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result3));

	if ($debug==1){
		echo ('<br>In PM01 Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp3);
		echo ('<br>$in_Sales_Rep_Name: '.$in_Sales_Rep_Name);
		echo ('<br>$in_Sales_Team: '.$in_Sales_Team);


		echo ('<br>results: '.$result3);
		echo ('<br>numrows: '.$numrows3);
		echo ('<br>Searching for: '.$in_Sales_Rep_Name);
		echo ('<br>database connection: '.$DB_Conn1);

		if (! $DB_Conn1) {
			DIE ("<br>Could not connect to ".$DB2_Host." Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to ".$DB2_Host." Database. <br />";
		}
	}
	Return $answer; 

} // function Get_Previous_Month_Data_CVR ($DB_Conn1, $in_Sales_Rep_Name, $in_Sales_Team, $debug)


function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	global $tbl_bgcolor;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" valign=bottom bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}

?>

<html>
<title>USRCBR Media Sales Analysis</title>
<head>

</head>
	
<body>
<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);


// HEADER
//	<tr style="font-size:20pt;">
//	<td align=center><b>Outbound Sales</b>
//	</td>
//	</tr>

echo ('	<table align=center width=800>
	<tr style="font-size:24pt;">
	<td align=center><b>Media Summary: Sales Rep Statistics</b>
	</td>
	</tr>


	<tr style="font-size:12pt;">
	<td align=center><i>This is a summary for all Leads assigned to</i>
	</td>
	</tr>

	<tr style="font-size:18pt;">
	<td align=center><b>'.$sales_team.': '.$sales_rep_name.'</b>
	</td>
	</tr>

	<tr style="font-size:12pt;">
	<td align=center><i>(Including any reps using these Leads)</i>
	</td>
	</tr>

	<tr>
	<td align=center>
	<button align=center onclick="window.close()">Close</button>
	</td>
	</tr>

	<tr style="font-size:12pt;">
	<td align=center><i>For the Period Ending</i>
	</td>
	</tr>

	<tr style="font-size:12pt;">
	<td align=center>'.$today[weekday].', '.$today[month].' '.$today[mday].', '.$today[year].'
	</td>
	</tr>

	</table>');


echo ('	</table>');


// BODY
echo ('	<table align="center" width=1350>');


echo ('<tr>
	<td colspan=16 align=center bgcolor="LightGrey"><b>DAILY</b></td>
	</tr>');



echo ('	<tr>');


	format_tbl_header("Original Media Type<br>and<br>Loadbook Value Range", 400, center);
	format_tbl_header("Leads", 125, center);
	format_tbl_header("%<br>of<br>Book", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Dials", 50, center);
	format_tbl_header("Leads<br>Dialed", 50, center);
	format_tbl_header("Leads<br>Presented", 75, center);
	format_tbl_header("% of Dialed<br>Presented", 125, center);
	format_tbl_header("Leads<br>Not<br>Called", 75, center);
	format_tbl_header("%<br>Not<br>Called", 75, center);
	format_tbl_header("Certified<br>Orders", 125, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing Ratio", 75, center);
//	format_tbl_header("Certified<br>Pending", 50, center);
	format_tbl_header("Certified<br>Average<br>Ticket", 125, center);
	format_tbl_header("Loadbook Value", 125, center);
	

//	Outbound
	$Answers10 = Get_Daily_Data_Today_OB ($DB_Conn2, $sales_id, $sales_team, $debug);

	for ($i=0; $i<$_SESSION['List_Count1_OB']; $i+=1){

	if($Answers10[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers10[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content($Answers10[$i][1], 125, left, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers10[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers10[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers10[$i][4], 0), 50, center, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers10[$i][5], 0), 50, center, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers10[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers10[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers10[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers10[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers10[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers10[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers10[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers2[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers10[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers10[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value
	}

//	Customer Value Range	
	$Answers1 = Get_Daily_Data_Today_CVR ($DB_Conn2, $sales_id, $sales_team, $debug);

	for ($i=0; $i<$_SESSION['List_Count1_CVR']; $i+=1){

	if($Answers1[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers1[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content($Answers1[$i][1], 125, left, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers1[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers1[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers1[$i][4], 0), 50, center, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers1[$i][5], 0), 50, center, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers1[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers1[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers1[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers1[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers1[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers1[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers1[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers2[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers1[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers1[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value	
	}

echo ('	</table><table align="center" width=1350>');
echo 	('<tr>
	<td colspan=16 align=center bgcolor="LightGrey"><b>MONTH TO DATE</b></td>
	</tr>
	<tr>');

	echo ('</tr>');
	
echo	('<tr>');

	format_tbl_header("Original Media Type<br>and<br>Loadbook Value Range", 400, center);
	format_tbl_header("Leads", 125, center);
	format_tbl_header("%<br>of<br>Book", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Dials", 50, center);
	format_tbl_header("Leads<br>Dialed", 50, center);
	format_tbl_header("Leads<br>Presented", 75, center);
	format_tbl_header("% of Dialed<br>Presented", 125, center);
	format_tbl_header("Leads<br>Not<br>Called", 75, center);
	format_tbl_header("%<br>Not<br>Called", 75, center);
	format_tbl_header("Certified<br>Orders", 125, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing Ratio", 75, center);
//	format_tbl_header("Certified<br>Pending", 50, center);
	format_tbl_header("Certified<br>Average<br>Ticket", 125, center);
	format_tbl_header("Loadbook Value", 125, center);	
	echo ('</tr>');

	
//	Outbound
	$Answers20 = Get_Month_to_Date_Data_OB ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count2_OB']; $i+=1){

	if($Answers20[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers20[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content($Answers20[$i][1], 125, left, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers20[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers20[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers20[$i][4], 0), 50, center, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers20[$i][5], 0), 50, center, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers20[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers20[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers20[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers20[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers20[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers20[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers20[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers2[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers20[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers20[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value

	echo ('</tr>');
	}

//	Customer Value Range
	$Answers2 = Get_Month_to_Date_Data_CVR ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count2_CVR']; $i+=1){

	if($Answers2[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	
	format_tbl_content($Answers2[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content($Answers2[$i][1], 125, left, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers2[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers2[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers2[$i][4], 0), 50, center, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers2[$i][5], 0), 50, center, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers2[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers2[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers2[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers2[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers2[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers2[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers2[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers2[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers2[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers2[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value
	echo ('</tr>');
	}

	echo ('	</table>');

/*
	echo ('<table align="center" width=1350>');
	echo ('	<tr>
		<td colspan=16 align=center bgcolor="LightGrey"><b>PREVIOUS MONTH</b></td>
		</tr><tr>');

	format_tbl_header("Original Media Type<br>and<br>Loadbook Value Range", 400, center);
	format_tbl_header("Leads", 125, center);
	format_tbl_header("%<br>of<br>Book", 125, center);
	format_tbl_header("Total<br>Talk Time", 125, center);
	format_tbl_header("Dials", 50, center);
	format_tbl_header("Leads<br>Dialed", 50, center);
	format_tbl_header("Leads<br>Presented", 75, center);
	format_tbl_header("% of Dialed<br>Presented", 125, center);
	format_tbl_header("Leads<br>Not<br>Called", 75, center);
	format_tbl_header("%<br>Not<br>Called", 75, center);
	format_tbl_header("Certified<br>Orders", 125, center);
	format_tbl_header("Certified<br>Sales", 125, center);
	format_tbl_header("Certified<br>Closing Ratio", 75, center);
//	format_tbl_header("Certified<br>Pending", 50, center);
	format_tbl_header("Certified<br>Average<br>Ticket", 125, center);
	format_tbl_header("Loadbook Value", 125, center);
	
	echo ('</tr>');

//	Outbound	
	$Answers30 = Get_Previous_Month_Data_OB ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count3_OB']; $i+=1){

	if($Answers30[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	

	format_tbl_content($Answers30[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content($Answers30[$i][1], 125, left, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers30[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers30[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers30[$i][4], 0), 50, center, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers30[$i][5], 0), 50, center, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers30[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers30[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers30[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers30[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers30[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers30[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers30[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers3[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers30[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers30[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value
	echo ('</tr>');
	}

//	Customer Value Range
	$Answers3 = Get_Previous_Month_Data_CVR ($DB_Conn1, $sales_id, $sales_team, $debug);
	
	for ($i=0; $i<$_SESSION['List_Count3_CVR']; $i+=1){

	if($Answers3[$i][0]=="Total") {
		$row_bgcolor=LightYellow;
	}
	else {$row_bgcolor=White;
	}

	echo ('<tr>');
//	echo ('<tr onClick="show_detail('.($i).')">');		
//	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	

	format_tbl_content($Answers3[$i][0], 400, left, $row_bgcolor);					// Media
	format_tbl_content($Answers3[$i][1], 125, left, $row_bgcolor);					// Leads
	format_tbl_content((number_format($Answers3[$i][2], 3)*100).'%', 125, right, $row_bgcolor);	// % of Book
	format_tbl_content($Answers3[$i][3], 125, center, $row_bgcolor);					// Talk Time
	format_tbl_content(number_format($Answers3[$i][4], 0), 50, center, $row_bgcolor);		// Dials
	format_tbl_content(number_format($Answers3[$i][5], 0), 50, center, $row_bgcolor);		// Dialed
	format_tbl_content(number_format($Answers3[$i][6], 0), 75, center, $row_bgcolor);		// Presentations
	format_tbl_content((number_format($Answers3[$i][7], 3)*100).'%', 125, right, $row_bgcolor);	// % of Dialed	
	format_tbl_content(number_format($Answers3[$i][8], 0), 75, center, $row_bgcolor);		// Leads Not Called
	format_tbl_content((number_format($Answers3[$i][9], 3)*100).'%', 125, right, $row_bgcolor);	// % Not Called
	format_tbl_content(number_format($Answers3[$i][10], 0), 125, center, $row_bgcolor);		// Certified Orders
	format_tbl_content('$'.(number_format($Answers3[$i][11], 2)), 125, right, $row_bgcolor);		// Certified Sales
	format_tbl_content((number_format($Answers3[$i][12], 3)*100).'%', 125, right, $row_bgcolor);	// Certified Closing Ratio
//	format_tbl_content('$'.(number_format($Answers3[$i][12], 2)), 125, right, $row_bgcolor);		// Certified Pending
	format_tbl_content('$'.(number_format($Answers3[$i][13], 2)), 125, right, $row_bgcolor);		// Average Ticket
	format_tbl_content('$'.(number_format($Answers3[$i][14], 2)), 125, right, $row_bgcolor);		// Loadbook Value

	echo ('</tr>');
	}


	echo ('</table><br><br>');
*/

?>
</body>
</html>
