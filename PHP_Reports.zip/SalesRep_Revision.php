<?php
session_start();

/////////////////////////////////////////////////////////////////////
// START Test for Permissions
/////////////////////////////////////////////////////////////////////

$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];


$sales_manager	=$_SESSION['Sales_Manager'];
$sales_team	=$_SESSION['Sales_Team'];
$sales_rep_name	=$_SESSION['Sales_Rep_Name'];
$isManager	=$_SESSION['isManager'];

IF ($securitygroup=='Sales' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administrator')
	{}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');

$debug=1;

$DB_Conn2 = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to database USRCREP02 
mssql_select_db("Data_Warehouse", $DB_Conn2); 

IF ($debug == 1){
	IF (! $DB_Conn2) {
		DIE ("Could not connect to ".$DB2_Host." Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to ".$DB2_Host." Database. <br />";}

	$DB_Select2 = mssql_select_db('Data_Warehouse', $DB_Conn2);
	IF (!$DB_Select2){
		DIE ("Could not connect to Data_Warehouse on ".$DB2_Host.". <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {
		echo ("Connected to Data_Warehouse on ".$DB2_Host."<br/>");	
	}
}


function Get_MyTeam ($DB_Conn2, $in_Sales_ID, $debug)
	{
        $sp = mssql_init ( "dbo.usp_Media_Report_Request_myTeam", $DB_Conn2 ); //init stored procedure  
	mssql_bind ( $sp, '@in_Sales_ID', $in_Sales_ID, SQLVARCHAR, false, false, 5);

	mssql_free_result($result);
	$result = mssql_execute($sp);

	$numrows = mssql_num_rows($result);
	$_SESSION['List_Count'] = $numrows;

	do {
		$i=0;
	    while ($row = mssql_fetch_row($result)) {
		    
		    $answer[$i][0] = $row[0];
//		    print_r($answer[$i][0]);
		    
		    $answer[$i][1] = $row[1];
//		    print_r($answer[$i][1]);

		    $answer[$i][2] = $row[2];
//		    print_r($answer[$i][2]);

		    $answer[$i][3] = $row[3];
//		    print_r($answer[$i][3]);

		    $answer[$i][4] = $row[4];
//		    print_r($answer[$i][3]);
    
		    $i=$i+1;
	    }
	} while (mssql_next_result($result));


	if ($debug==1){
		echo ('<br>In Get_User_Data<br>'); 
		echo ('<br>stored procedure: '.$sp);
		echo ('<br>results: '.$result);
		echo ('<br>numrows: '.$numrows);
		echo ('<br>Searching for: '.$in_Sales_ID);
		echo ('<br>database connection: '.$DB_Conn2);

		if (! $DB_Conn2) {
			DIE ("<br>Could not connect to USRCREP02 Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "<br>Connected Fine to USRCREP02 Database. <br />";
		}

	}
	Return $answer; 

} // function Get_myTeam ($DB_Conn2, $in_Sales_ID, $debug)



/////////////////////////////////////////////////////////////////////
// START HTML Page
/////////////////////////////////////////////////////////////////////

	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Vault Management Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');

	if($securitygroup=='Developer')
	{
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<center>WELCOME to the Sales Rep Toolsite. The currently options available are: </center><br/>');
	echo ('<table align="center">');
	echo ('<tr><td>1.</td><td><a href="./SalesRep_Gold_Report_Tracking.php">Gold Report Follow-Up</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./SalesRep_UPS_Tracking_Summary.php">UPS Order Tracking</td></tr>');
	//echo ('<tr><td>2.</td><td>UPS Order Tracking <i>(Temporarily Unavailable)</i></td></tr>');

	IF(($login=='SSM' || $login=='TQN') && $isManager = 'Yes' )
	{
		echo ('<tr><td>3.</td><td><a href="./BSS_Call_History_ContactNumber.php">Contact History: Contact Number</td></tr>');
		echo ('<tr><td>4.</td><td><a href="./BSS_Call_History_DNIS.php">Contact History: 800 Number</td></tr>');
		echo ('<tr><td>5.</td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales Rep ID</td></tr>');
		echo ('<tr><td>6.</td><td><a href="./SalesRep_Media_Report_Team_Roster.php">Media Report: Team Reviews</td></tr>');
	}
	ELSE 
	{
		IF($isManager = 'Yes' )
		{
			echo ('<tr><td>3.</td><td><a href="./BSS_Call_History_ContactNumber.php">Contact History: Contact Number</td></tr>');
			echo ('<tr><td>4.</td><td><a href="./BSS_Call_History_DNIS.php">Contact History: 800 Number</td></tr>');
			echo ('<tr><td>5.</td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales Rep ID</td></tr>');
//			echo ('<tr><td>6.</td><td><a href="./SalesRep_Media_Report_Team.php?Sales_Team='.$sales_team.'&Sales_Manager='.$sales_manager.'">Media Report: Team Reviews</td></tr>');
		}
	}

	
	echo ('</table></html>');


?>
