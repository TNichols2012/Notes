<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

////////////////////////////////////////////////////////////////////
// END Test for Permissions
////////////////////////////////////////////////////////////////////

require ('DB_Login.php');

// Connection to USRC_AmcatSQL
$DB3_Conn = mssql_connect($DB3_Host, $DB3_UserName, $DB3_Password); 

//mssql_select_db ( $DB1_Database, $DB1_Conn );

$orig_returns_detail	=$_SESSION['Returns_Detail'];

$orig_returns_index	= $orig_returns_detail[0][$_GET['$Index_ID']]; // Primary Key
$orig_datetime		= $orig_returns_detail[1][$_GET['$Index_ID']]; // DateTime
$orig_user_name		= $orig_returns_detail[2][$_GET['$Index_ID']]; // Username
$orig_customer_name	= $orig_returns_detail[3][$_GET['$Index_ID']]; // Customer Name
$orig_customer_ID	= $orig_returns_detail[4][$_GET['$Index_ID']]; // Customer Number
$_SESSION['Cust_ID']	= $orig_returns_detail[4][$_GET['$Index_ID']]; // Customer Number
$orig_order_ID		= $orig_returns_detail[5][$_GET['$Index_ID']]; // Order Number
$orig_dollar_amount	= $orig_returns_detail[6][$_GET['$Index_ID']]; // Dollar Amount
$orig_issue		= $orig_returns_detail[7][$_GET['$Index_ID']]; // Issue
$orig_issue		= str_replace ( "\n", '<br>',$orig_issue);
$orig_manager_notes	= $orig_returns_detail[8][$_GET['$Index_ID']]; // Manager Notes
$orig_manager_notes	= str_replace ( "\n", '<br>',$orig_manager_notes);
$orig_returns		='';

$_SESSION['Index_ID']=$_GET['$Index_ID'];
$php_status='Original';

// Test Data
//$orig_customer_ID = 1;

$sp1 = mssql_init ( '[USRC_Main].dbo.usp_GetLoadBookNotes', $DB3_Conn ); 
$sp1_custnum=$orig_customer_ID;
$_SESSION['Cust_ID']=$orig_customer_ID;

mssql_bind ($sp1, '@custnum', $sp1_custnum, SQLVARCHAR, false, false, 10);
$result1 = mssql_execute ( $sp1 ); 
$loadbook_notes = mssql_result($result1, 0, 0);

If ($debug==1) {	
	if (! $DB3_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
		}
	else {echo "Debug Mode: ON <br> Successfully connected to USRC_AmcatSQL database. <br />";}

		echo ('<br>Original customer ID is: '.$orig_customer_ID);
		echo ('<br>sp1_custnum is: '.$sp1_custnum);
		echo ('<br>Original Session Index ID is: '.$_GET['$Index_ID']);
		echo ('<br>Original Session cust ID is: '.$_SESSION['Cust_ID']);
		echo ('<br>Original Session User ID is: '.$_SESSION['User_ID']);
		echo ('<br>Original Session Sec Grp is: '.$_SESSION['Security_Group']);
		echo ('<br>Original Session Sec Lvl is: '.$_SESSION['Security_Level']);
		echo ('<br>Original Session Details: '.$_SESSION['Returns_Detail']);
		echo ('<br>php status is: '.$php_status);
		echo ('<br>**************************************************************************************');

	};

if($php_status=='Original'){
echo ('	<html>
	<title>USRCBR IT Inventory Submission</title>
	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Vault Returns Management: Issues Detail</h2>
	<h3 align=center>Original</h3>
	<table align="center">
	<button  onclick="window.close()">Close</button>
	</table>
	<br>Sales Return issue for: <b>'.$orig_user_name.'<br><br>
	<table align=center>
	<form action="VaultMgmt_Returns_Update.php?$Index_ID='.$_SESSION['Index_ID'].'" method="POST">
	<tr>
	<td style="width=150px" align=left>
	<label>Issue Entry Date:<br>
	<b>'.$orig_datetime.'</b></label>
	</td>
	<td style="width=150px" align=left>
	<label>Customer Name:<br>
	<b>'.$orig_customer_name.'</b></label>
	</td>
	<td style="width=150px" align=left>
	<label>MOM Customer ID:<br>
	<b>'.$orig_customer_ID.'</b></label>	
	<td style="width=150px" align=left>
	<label>Return Value:<br>
	<b>'.$orig_dollar_amount.'</b></label>
	</td></tr>
	<tr><td colspan=4>
	<label><br>MOM Order ID(s):<br>
       	<b>'.$orig_order_ID.'</b></label>
	</td></tr>
	
	<tr align="center"><td colspan=4>
	<label><br><u>Sales Rep Comments</u> (<i>if any</i>):</label></td></tr>

	<tr><td colspan=4>
	<label>'.$orig_issue.'</label>
	</td></tr>
	
	<tr align="center"><td colspan=4>
	<label><br><u>Loadbook Notes</u> (<i>if any</i>):</label>
	</td></tr>

	<tr><td colspan=4>
	<textarea name="in_Loadbook_Notes" cols=80 rows=10 align=center>'.$loadbook_notes.'</textarea>
	</td></tr>
	<tr align="center"><td colspan=4>
	<input type="submit" name="Update" value="Update" />
	</td></tr>

	<tr align="center"><td colspan=4>
	<label><br><u>Manager Notes</u> (<i>if any</i>):</label>
	</td></tr>

	<tr><td colspan=4>
       	'.$orig_manager_notes.'</label>
	</td></tr>
	
	</form>
	</table>
	</html>');

$php_page=htmlentities($_SERVER['PHP_SELF']);
$loadbook_notes_update = htmlentities($_POST["in_Loadbook_Notes"]);

if ($orig_inventory=='Confirm'){
	//Test Data	
	//$orig_inventory='Close';
	}

if($orig_inventory == 'Close')
{
	$orig_inventory='';
	$_POST['Update']= False;
?>
<script language=JavaScript>
window.close();
</script>

<?php
}

} // end if($inve_asset_tag==='')

?>



