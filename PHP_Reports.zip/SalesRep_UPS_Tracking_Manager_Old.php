<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////

$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];
$site=$_SESSION['Security_Site'];

IF ($securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB2_Database, $DB_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
define("Red", "FF3300");
define("DarkGreen", "00FF00");
define("Green", "00CC33");
$hdr_bgcolor=Green;

if ($debug==2){
	if (! $DB_Conn) {
		DIE ("Could not connect to USRCREP02 Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to USRCREP02 Database. <br />";
	}
}

function get_SalesReps($DB_Conn, $room, $manager, $debug) {

	if ($room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" 1=1 ";
		//$SQL_Room=" SecurityLevel='".$room."'";
	}

	if ($room=='Austin Sales Manager') {
		$SQL_Room=" Manager IN ('Ben Rollings (BN)', 'Robert Raben (RN)') ";
	}

	if ($room=='Beaumont Sales Manager') {
		$SQL_Room=" Manager IN ('Johnpaul Durham (JP)', 'Larry Kuykendall (LK)') ";
	}

	if ($room=='C3 Sales Manager') {
		$SQL_Room=" Manager IN ('Brad Remington (RBC)', 'Steve Dominguez (SRD)') ";
	}

	if ($manager=='All Sales Managers') {
		$SQL_Sales_Manager=" 1=1 ";
	}
	else {
		$SQL_Sales_Manager=" Manager='".$manager."'";
	}

	$query="SELECT	Name, RTRIM(Login) AS Login
		FROM	tbl_Sales_Teams
		WHERE	(Sales_Manager IS NOT NULL) 
		AND	(Sales_Manager NOT IN ('', 'AU Rollovers', 'BM Rollovers', 'C3 Rollovers', 'Company')) 
		AND	(Active = 1) 
		AND	( ".$SQL_Room." ) 		
		AND	( ".$SQL_Sales_Manager." )
		AND	(Name NOT LIKE 'Z-Deleted%')
		GROUP BY Name, Login";


	//AND ( SecurityLevel LIKE '%Sales%' ) 
	//
	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Sales_Rep_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result, $i, 0);//Sales_Rep
		$answer[1][$i]=mssql_result($result, $i, 1);//Sales_Rep
	}

	if ($debug==2){
		echo ('<br>Sales Rep query Looks Like:<br> '.$query);
		echo ('<br>');
		echo ('<br>Result is : '.$result);
		echo ('<br>Numrows are: '.$numrows);
		echo ('<br>');
	}

	Return $answer;

}; // end function get_SalesRep()

function get_Managers($DB_Conn, $room, $debug) {

	if ($room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" Site='".$room."'";
	};
	 
	$query="SELECT  Sales_Manager
		FROM    tbl_Sales_Teams
		WHERE   (Sales_Manager IS NOT NULL) 
		AND 	(Sales_Manager NOT IN ('', 'AU Rollovers', 'BM Rollovers', 'C3 Rollovers', 'Company')) 
		AND	(Active = 1)
		AND	".$SQL_Room."
		GROUP BY Sales_Manager";

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Manager_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Manager
	}

	if ($debug==2){
		if (! $DB_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Query Looks Like:<br> '.$query);
		echo ('<br>Manager count is:<br> '.$numrows);

		echo ('<br>');
	}
	Return $answer;
};

function get_UPS_Tracking($DB_Conn, $status, $ship_date, $ship_called, $delivered_date, $delivered_called, $last_contact, $sales_rep, $manager, $room, $debug){

//	echo ('In the UPS Tracking function.<br>');
	if ($status=='All Statuses' || $status=='') {
		$SQL_status=" 1=1 ";
	}
	else {
		$SQL_status=" tUT.[Status]='".$status."'";
	};

	if ($ship_date==''){
		$SQL_ship_date=" 1=1 ";
	}
	elseif (isDate($ship_date)){
		$SQL_ship_date=" tUT.Manifest_Date >='".$ship_date."'";
		}
		else { echo "<script>alert(\"Invalid Ship Date. Please re-enter. (format: mm/dd/yyyy)\");</script>";}

	if ($ship_called=='') {
		$SQL_ship_called=" 1=1 ";
	}
	else {
		$SQL_ship_called=" tUT.Called_After_Manifest='".$ship_called."'";
	};

	if ($delivered_date==''){
		$SQL_delivered_date=" 1=1 ";
	}
	elseif (isDate($delivered_date)){
		$SQL_delivered_date=" tUT.Scheduled_Delivery_Date >='".$delivered_date."'";
		}
		else { echo "<script>alert(\"Invalid Delivery Date. Please re-enter. (format: mm/dd/yyyy)\");</script>";}

	if ($delivered_called=='') {
		$SQL_delivered_called=" 1=1 ";
	}
	else {
		$SQL_delivered_called=" tUT.Called_After_Delivery='".$delivered_called."'";
	};

	if ($last_contact==''){
		$SQL_last_contact=" 1=1 ";
	}
	elseif (isDate($last_contact)){
		$SQL_last_contact=" (CASE 
		WHEN tACI1.Last_OB_Contact_Date IS NOT NULL AND tACI1.Last_OB_Contact_Date > ISNULL(tACI2.Last_OB_Contact_Date, '1/1/1900') THEN tACI1.Last_OB_Contact_Date
		WHEN tACI1.Last_OB_Contact_Date IS NOT NULL AND tACI1.Last_OB_Contact_Date < tACI2.Last_OB_Contact_Date THEN tACI2.Last_OB_Contact_Date
		WHEN tACI1.Last_OB_Contact_Date IS NULL AND tACI2.Last_OB_Contact_Date IS NOT NULL THEN tACI2.Last_OB_Contact_Date
		WHEN tACI1.First_IB_Contact_Date IS NOT NULL THEN tACI1.First_IB_Contact_Date
		WHEN tACI2.First_IB_Contact_Date IS NOT NULL THEN tACI2.First_IB_Contact_Date
		ELSE NULL END) >='".$last_contact."'";
		}
		else { echo "<script>alert(\"Invalid Last Contact Date. Please re-enter. (format: mm/dd/yyyy)\");</script>";}

	if ($sales_rep=='All Sales Reps' || $sales_rep=='') {
		$SQL_sales_reps=" 1=1 ";
	}
	else {
		$SQL_sales_reps=" tST.Name='".$sales_rep."'";
	};

	if ($manager=='All Sales Managers' || $manager=='') {
		$SQL_managers=" 1=1 ";
	}
	else {
		$SQL_managers=" tST.Sales_Manager='".$manager."'";
	};

	if ($room=='All Sales Rooms' || $room=='') {
		$SQL_rooms=" 1=1 ";
	}
	else {
		$SQL_rooms=" tST.Site='".$room."'";
	};	

	$query1="SELECT 
		tUT.Tracking_Number, 
		tUT.Order_ID, 
		tUT.[Status], 
		CONVERT(varchar(50), tUT.Manifest_Date, 101) AS Manifest_Date,
		tUT.Called_After_Manifest, 
		tUT.Called_After_Manifest_Time, 
		CONVERT(varchar(50), tUT.Scheduled_Delivery_Date, 101) AS Scheduled_Delivery_Date, 
		tUT.Called_After_Delivery, 
		tUT.Called_After_Delivery_Time, 
		(CASE 
		WHEN tACI1.Last_OB_Contact_Date IS NOT NULL AND tACI1.Last_OB_Contact_Date > ISNULL(tACI2.Last_OB_Contact_Date, '1/1/1900') THEN tACI1.Last_OB_Contact_Date
		WHEN tACI1.Last_OB_Contact_Date IS NOT NULL AND tACI1.Last_OB_Contact_Date < tACI2.Last_OB_Contact_Date THEN tACI2.Last_OB_Contact_Date
		WHEN tACI1.Last_OB_Contact_Date IS NULL AND tACI2.Last_OB_Contact_Date IS NOT NULL THEN tACI2.Last_OB_Contact_Date
		WHEN tACI1.First_IB_Contact_Date IS NOT NULL THEN tACI1.First_IB_Contact_Date
		WHEN tACI2.First_IB_Contact_Date IS NOT NULL THEN tACI2.First_IB_Contact_Date
		ELSE NULL END) AS Last_Contact,
		tUT.Ship_To_Name AS Customer,
		tST.[Login], 
		tST.Name, 
		tST.Sales_Manager, 
		tST.[Site], 
		tMCMS.Ttl_Billed_Merch AS Order_Value
		FROM         dbo.tbl_UPS_Tracking tUT
		INNER JOIN   dbo.tbl_MOM_CMS tMCms
		ON tUT.Order_ID = tMCms.Order_ID 
		INNER JOIN   dbo.tbl_Sales_Teams tST 
		ON tMCms.Sales_ID = tST.[Login] 
		INNER JOIN   dbo.tbl_MOM_Cust tMCust
		ON tMCms.Cust_ID = tMCust.Cust_ID 
		LEFT OUTER JOIN dbo.tbl_Amcat_Contact_Info AS tACI2 
		ON tMCust.Contact_Number2 = tACI2.ContactNumber 
		LEFT OUTER JOIN dbo.tbl_Amcat_Contact_Info AS tACI1 
		ON tMCust.Contact_Number1 = tACI1.ContactNumber
		WHERE Manifest_Date > GETDATE()-90
		AND ".$SQL_status."
		AND ".$SQL_ship_date."
		AND ".$SQL_ship_called."
		AND ".$SQL_delivered_date."
		AND ".$SQL_delivered_called."
		AND ".$SQL_last_contact."
		AND ".$SQL_sales_reps."
		AND ".$SQL_managers."
		AND ".$SQL_rooms."
		ORDER BY Manifest_Date DESC";
		
	$result1=mssql_query($query1, $DB_Conn);
	$numrows=mssql_num_rows($result1);
	$_SESSION['UPS_Count']=$numrows;



	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result1, $i, 0);//Tracking_Number
		$answer[1][$i]=mssql_result($result1, $i, 1);//Order_ID
		$answer[2][$i]=mssql_result($result1, $i, 2);//Status
		$answer[3][$i]=mssql_result($result1, $i, 3);//Manifest Date
		$answer[4][$i]=mssql_result($result1, $i, 4);//Called?
		$answer[5][$i]=mssql_result($result1, $i, 5);//Called? Yes
		$answer[6][$i]=mssql_result($result1, $i, 6);//Scheduled Delivery Date
		$answer[7][$i]=mssql_result($result1, $i, 7);//Called?
		$answer[8][$i]=mssql_result($result1, $i, 8);//Called? Yes
		$answer[9][$i]=mssql_result($result1, $i, 9);//Last Contact
		$answer[10][$i]=mssql_result($result1, $i, 10);//Customer
		$answer[11][$i]=mssql_result($result1, $i, 11);//Login
		$answer[12][$i]=mssql_result($result1, $i, 12);//Sales Rep Name
		$answer[13][$i]=mssql_result($result1, $i, 13);//Sales Manager
		$answer[14][$i]=mssql_result($result1, $i, 14);//Site
		$answer[15][$i]=mssql_result($result1, $i, 15);//Order Value

	}
	
	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode within Get_List function: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine while inside Get List Function. <br />";}

		echo "Query1 Looks Like: '<b>".$query1."</b>'<br>";

	}

	Return $answer;
}

function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');

	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){

	echo ('<td align="'.$alignment.'" bgcolor="');
		
	echo $row_bgcolor.'"';

	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}


?>

<html>

<head>
<script type="text/javascript">
	function show_detail(Index_ID){
	<!--
	str_redirect1='./Survey_Add.php?$orig_index='+Index_ID
	window.open (str_redirect1, 'Asset_Window_'+Index_ID, config='height=800, width=800, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}

</script>

<script src="JS_Sort_Table.js"></script>



</head>
<title>USRCBR Sales Rep UPS Tracking Info</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_Status"]="";
	$_POST["in_Room"]="";
	$_POST["in_Manager"]="";
	$_POST["in_Sales_Rep"]="";
	$_POST["in_Shipped_Date"]="";
	$_POST["in_Shipped_Call"]="";
	$_POST["in_Delivered_Date"]="";	
	$_POST["in_Delivered_Call"]="";	
	$_POST["in_Last_Contact"]="";	
}

$manager_list = get_Managers($DB_Conn, 'All Sales Rooms', $debug);
$sales_rep_list = get_SalesReps($DB_Conn, 'All Sales Rooms', 'All Sales Managers', $debug);

if($_POST['Show']) {
//echo ('Working when picked out.<br>'); 

$UPS_Tracking_List=get_UPS_Tracking($DB_Conn, $_POST["in_Status"], $_POST["in_Shipped_Date"], $_POST["in_Shipped_Call"], $_POST["in_Delivered_Date"], $_POST["in_Delivered_Call"], $_POST["in_Last_Contact"], $_POST["in_Sales_Rep"], $_POST["in_Manager"], $_POST["in_Room"], $debug);


// Header
echo ('	<div id="header">
	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

if($securitygroup=='Sales'){
	echo ('<table align="center"><tr><td align="center" valign="top">
	<form action="SalesRep_.php" method="POST">
	<input type="submit" name="Back" value="Back to Menu" />
	</td></tr></form></table>');
	}
if($securitygroup=='Administrator'){
	echo ('<table align="center"><tr><td align="center" valign="top">
	<form action="Administrator_.php" method="POST">
	<input type="submit" name="Back" value="Back to Menu" />
	</td></tr></form></table>');
	}
if($securitygroup=='Developer'){
	echo ('<table align="center"><tr><td align="center" valign="top">
	<form action="Developer_.php" method="POST">
	<input type="submit" name="Back" value="Back to Menu" />
	</td></tr></form></table>');
	}

echo ('	<h2 align=center>Executive Tools: UPS Tracking Manager</h2>
	</div>');

// Query Input
echo (' <div id="body1">
	<table align="center" width="1024" cellspacing="1">
		<tr>
		<td></td>
		<td align="center" colspan=2 bgcolor="00FFFF"><b>2) Ship Date</b></td>
		<td align="center" colspan=2 bgcolor="00FFFF"><b>3) Delivery Date</b></td>
		</tr>
		
		<tr>
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td valign="bottom" align="center" width="125" bgcolor="00FFFF">
		<label><b>1) Status:</b><br></label>
		<select name="in_Status" >
		<option>'.$_POST["in_Status"].'</option>
		<option value="All Statuses">All Statuses</option>
		<option value="Manifested">Manifested</option>
		<option value="In Transit">In Transit</option>
		<option value="Out for Delivery">Out for Delivery</option>
		<option value="Delivered">Delivered</option>
		<option value="Returning">Returning</option>
		</td>');

	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF" cellspacing="0">
		<label align="center"><b>From</b><br></label>
		<input type="text" style="text-align:center" name="in_Shipped_Date" value="'.$_POST["in_Shipped_Date"].'" align="center" />
		</td>');

	echo ('	<td valign="bottom" align="center" width="50" bgcolor="00FFFF" cellspacing="0">
		<label><b>Called?</b><br></label>
		<select name="in_Shipped_Call" >
		<option>'.$_POST["in_Shipped_Call"].'</option>
		<option value=""></option>		
		<option value="Yes">Yes</option>
		<option value="No">No</option>
		</td>');

	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF">
		<label><b>From</b><br></label>
		<input type="text" style="text-align:center" name="in_Delivered_Date" value="'.$_POST["in_Delivered_Date"].'" align="center" />
		</td>');

	echo ('	<td valign="bottom" align="center" width="50" bgcolor="00FFFF">
		<label><b>Called?</b><br></label>
		<select name="in_Delivered_Call" >
		<option>'.$_POST["in_Delivered_Call"].'</option>
		<option value=""></option>
		<option value="Yes">Yes</option>
		<option value="No">No</option>
		</td>');

	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF">
		<label><b>4) Last Contact?</b><br></label>
		<input type="text" style="text-align:center" name="in_Last_Contact" value="'.$_POST["in_Last_Contact"].'" align="center" />
		</td>');

	echo ('	<td valign="bottom" align="center" width="200" bgcolor="00FFFF">
		<label><b>5) Sales Rep:</b><br>
		<select name="in_Sales_Rep">
		<option>'.$_POST["in_Sales_Rep"].'</option>
		<option value="All Sales Reps">All Sales Reps</option>');	

		for($i=0;$i<$_SESSION['Sales_Rep_Count'];$i+=1){
			echo ('<option value="'.$sales_rep_list[0][$i].'">'.$sales_rep_list[0][$i].'</option>  ');
		}
	echo ('</td>');
		
	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF">
		<label><b>6) Manager:</b><br>
		<select name="in_Manager">
		<option>'.$_POST["in_Manager"].'</option>
		<option value="All Sales Managers">All Sales Managers</option>');	

		for($i=0;$i<$_SESSION['Manager_Count'];$i+=1){
			echo ('<option value="'.$manager_list[$i].'">'.$manager_list[$i].'</option>');
		}
	echo ('	</td>');

	echo ('	<td valign="bottom" align="center" width="125" bgcolor="00FFFF">
		<label><b>7) Room:</b><br></label>
		<select name="in_Room" >
		<option>'.$_POST["in_Room"].'</option>
		<option value="All Sales Rooms">All Sales Rooms</option>
		<option value="Austin">Austin</option>
		<option value="Beaumont">Beaumont</option>
		<option value="C3">C3</option>
		</td>');

	// bottom
	echo ('</tr>
		<tr>
		<td bgcolor="00FFFF"></td>
		<td align="center" bgcolor="00FFFF"><i>(mm/dd/yyyy)</i></td>
		<td bgcolor="00FFFF"></td>
		<td align="center" bgcolor="00FFFF"><i>(mm/dd/yyyy)</i></td>
		<td bgcolor="00FFFF"></td>
		<td align="center" bgcolor="00FFFF"><i>(mm/dd/yyyy)</i></td>
		<td bgcolor="00FFFF"></td>
		<td bgcolor="00FFFF"></td>
		<td bgcolor="00FFFF"></td>');

	// submit
	echo ('	</tr>
		<tr><td colspan=9 valign="top" align="center">
		<input type="submit" name="Show" value="Show Me" />
		<input type="submit" name="Clear" value="Clear All" />
		
		</form></table>
		</div>');
//////////////////////////////////////////////////////////////////////////////////////////	
// END OF QUERY INPUT
//////////////////////////////////////////////////////////////////////////////////////////

	echo ('	<div id="body2">
		<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Order ID", 75, center, $hdr_bgcolor);
	format_tbl_header("Status", 75, center, $hdr_bgcolor);
	format_tbl_header("Ship Date ->", 100, center, $hdr_bgcolor);
	format_tbl_header("Called?", 50, center, $hdr_bgcolor);
	format_tbl_header("Delivery Date ->", 125, center, $hdr_bgcolor);
	format_tbl_header("Called?", 50, center, $hdr_bgcolor);
	format_tbl_header("Last Contact", 175, center, $hdr_bgcolor);
	format_tbl_header("Customer", 150, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep", 150, center, $hdr_bgcolor);
	format_tbl_header("Room", 50, center, $hdr_bgcolor);
	format_tbl_header("Order Value", 150, center, $hdr_bgcolor);
	echo ('</tr><tr>');


	for ($i=0; $i<$_SESSION['UPS_Count']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	format_tbl_content($UPS_Tracking_List[1][$i], 75, center, $row_bgcolor);//Order_ID
	format_tbl_content($UPS_Tracking_List[2][$i], 75, center, $row_bgcolor);//Status
	format_tbl_content($UPS_Tracking_List[3][$i], 100, center, $row_bgcolor);//Manifest Date


	// Called After Manifest options
	if($UPS_Tracking_List[4][$i]=="No"){
		echo ('<td align="center" bgcolor='.Red.'><b>'.$UPS_Tracking_List[4][$i].'</b></td>');//Called
	}
	else 	{
		echo ('<td align="center" bgcolor='.$row_bgcolor.' title="'.$UPS_Tracking_List[5][$i].'">'.$UPS_Tracking_List[4][$i].'</td>');//Called
	}	


	//	format_tbl_content($UPS_Tracking_List[4][$i], 50, center, $row_bgcolor);//Called
	
	format_tbl_content($UPS_Tracking_List[6][$i], 125, center, $row_bgcolor);//Scheduled Delivery

	// Called After Delivery options	
	if($UPS_Tracking_List[7][$i]=="No"){
		echo ('<td align="center" bgcolor='.Red.'><b>'.$UPS_Tracking_List[7][$i].'</b></td>');//Called
	}
	else 	{
		echo ('<td align="center" bgcolor='.$row_bgcolor.' title="'.$UPS_Tracking_List[8][$i].'">'.$UPS_Tracking_List[7][$i].'</td>');//Called
	}	
	//format_tbl_content($UPS_Tracking_List[7][$i], 50, center, $row_bgcolor);//Called


	format_tbl_content($UPS_Tracking_List[9][$i], 175, left, $row_bgcolor);//Last_Contact
	format_tbl_content(ucwords(strtolower($UPS_Tracking_List[10][$i])), 150, left, $row_bgcolor);//Customer
	format_tbl_content($UPS_Tracking_List[12][$i], 150, center, $row_bgcolor);//Sales_Rep
	format_tbl_content($UPS_Tracking_List[14][$i], 75, center, $row_bgcolor);//Room
	echo ('<td align="right" bgcolor='.$row_bgcolor.'>$ '.number_format($UPS_Tracking_List[15][$i], 2).'</td>');//Order_Value

	echo ('</tr>');
	}	
	echo ('</table></div>');	


	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB2_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB2_UserName.'</b><br>');
			echo ('Database: <b>'.$DB2_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}
} //if($_POST['Show Me'])
ELSE { 

//echo ('Working when empty.'); 

// Header
echo ('	<div id="header">
	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

if($securitygroup=='Sales'){
	echo ('<table align="center"><tr><td align="center" valign="top">
	<form action="SalesRep_.php" method="POST">
	<input type="submit" name="Back" value="Back to Menu" />
	</td></tr></form></table>');
	}
if($securitygroup=='Administrator'){
	echo ('<table align="center"><tr><td align="center" valign="top">
	<form action="Administrator_.php" method="POST">
	<input type="submit" name="Back" value="Back to Menu" />
	</td></tr></form></table>');
	}
if($securitygroup=='Developer'){
	echo ('<table align="center"><tr><td align="center" valign="top">
	<form action="Developer_.php" method="POST">
	<input type="submit" name="Back" value="Back to Menu" />
	</td></tr></form></table>');
	}

echo ('	<h2 align=center>Executive Tools: UPS Tracking Manager</h2>
	</div>');

// Query Input
echo (' <div id="body1">
	<table align="center" width="1024" cellspacing="1">
		<tr>
		<td></td>
		<td align="center" colspan=2 bgcolor="00FFFF"><b>2) Ship Date</b></td>
		<td align="center" colspan=2 bgcolor="00FFFF"><b>3) Delivery Date</b></td>
		</tr>
		
		<tr>
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td valign="bottom" align="center" width="125" bgcolor="00FFFF">
		<label><b>1) Status:</b><br></label>
		<select name="in_Status" >
		<option>'.$_POST["in_Status"].'</option>
		<option value="All Statuses">All Statuses</option>
		<option value="Manifested">Manifested</option>
		<option value="In Transit">In Transit</option>
		<option value="Out for Delivery">Out for Delivery</option>
		<option value="Delivered">Delivered</option>
		<option value="Returning">Returning</option>
		</td>');

	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF" cellspacing="0">
		<label align="center"><b>From</b><br></label>
		<input type="text" style="text-align:center" name="in_Shipped_Date" value="'.$_POST["in_Shipped_Date"].'" align="center" />
		</td>');

	echo ('	<td valign="bottom" align="center" width="50" bgcolor="00FFFF" cellspacing="0">
		<label><b>Called?</b><br></label>
		<select name="in_Shipped_Call" >
		<option>'.$_POST["in_Shipped_Call"].'</option>
		<option value="Yes">Yes</option>
		<option value="No">No</option>
		</td>');

	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF">
		<label><b>From</b><br></label>
		<input type="text" style="text-align:center" name="in_Delivered_Date" value="'.$_POST["in_Delivered_Date"].'" align="center" />
		</td>');

	echo ('	<td valign="bottom" align="center" width="50" bgcolor="00FFFF">
		<label><b>Called?</b><br></label>
		<select name="in_Delivered_Call" >
		<option>'.$_POST["in_Delivered_Call"].'</option>
		<option value="Yes">Yes</option>
		<option value="No">No</option>
		</td>');

	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF">
		<label><b>4) Last Contact?</b><br></label>
		<input type="text" style="text-align:center" name="in_Last_Contact" value="'.$_POST["in_Last_Contact"].'" align="center" />
		</td>');

	echo ('	<td valign="bottom" align="center" width="200" bgcolor="00FFFF">
		<label><b>5) Sales Rep:</b><br>
		<select name="in_Sales_Rep">
		<option>'.$_POST["in_Sales_Rep"].'</option>
		<option value="All Sales Reps">All Sales Reps</option>');	

		for($i=0;$i<$_SESSION['Sales_Rep_Count'];$i+=1){
			echo ('<option value="'.$sales_rep_list[0][$i].'">'.$sales_rep_list[0][$i].'</option>  ');
		}
	echo ('</td>');
		
	echo ('	<td valign="bottom" align="center" width="150" bgcolor="00FFFF">
		<label><b>6) Manager:</b><br>
		<select name="in_Manager">
		<option>'.$_POST["in_Manager"].'</option>
		<option value="All Sales Managers">All Sales Managers</option>');	

		for($i=0;$i<$_SESSION['Manager_Count'];$i+=1){
			echo ('<option value="'.$manager_list[$i].'">'.$manager_list[$i].'</option>');
		}
	echo ('	</td>');

	echo ('	<td valign="bottom" align="center" width="125" bgcolor="00FFFF">
		<label><b>7) Room:</b><br></label>
		<select name="in_Room" >
		<option>'.$_POST["in_Room"].'</option>
		<option value="All Sales Rooms">All Sales Rooms</option>
		<option value="Austin">Austin</option>
		<option value="Beaumont">Beaumont</option>
		<option value="C3">C3</option>
		</td>');

	// bottom
	echo ('</tr>
		<tr>
		<td bgcolor="00FFFF"></td>
		<td align="center" bgcolor="00FFFF"><i>(mm/dd/yyyy)</i></td>
		<td bgcolor="00FFFF"></td>
		<td align="center" bgcolor="00FFFF"><i>(mm/dd/yyyy)</i></td>
		<td bgcolor="00FFFF"></td>
		<td align="center" bgcolor="00FFFF"><i>(mm/dd/yyyy)</i></td>
		<td bgcolor="00FFFF"></td>
		<td bgcolor="00FFFF"></td>
		<td bgcolor="00FFFF"></td>');

	// submit
	echo ('	</tr>
		<tr><td colspan=9 valign="top" align="center">
		<input type="submit" name="Show" value="Show Me" />
		<input type="submit" name="Clear" value="Clear All" />
		
		</form></table>
		</div>');
//////////////////////////////////////////////////////////////////////////////////////////	
// END OF QUERY INPUT
//////////////////////////////////////////////////////////////////////////////////////////

	echo ('<div id="body2"><table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center, $hdr_bgcolor);
	format_tbl_header("Order ID", 100, center, $hdr_bgcolor);
	format_tbl_header("Status", 125, center, $hdr_bgcolor);
	format_tbl_header("Ship Date ->", 125, center, $hdr_bgcolor);
	format_tbl_header("Called?", 5, center, $hdr_bgcolor);
	format_tbl_header("Delivery Date ->", 125, center, $hdr_bgcolor);
	format_tbl_header("Called?", 5, center, $hdr_bgcolor);
	format_tbl_header("Last Contact", 125, center, $hdr_bgcolor);
	format_tbl_header("Customer", 150, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep", 150, center, $hdr_bgcolor);
	format_tbl_header("Room", 50, center, $hdr_bgcolor);
	format_tbl_header("Order Value", 150, center, $hdr_bgcolor);
	echo ('</tr></div>');

	If ($debug==2) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB2_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB2_UserName.'</b><br>');
			echo ('Database: <b>'.$DB2_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


















}


?>

</html>



