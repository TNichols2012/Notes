<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];
$site=$_SESSION['Security_Site'];

IF ($securitygroup=='BSS' || $securitygroup=='Sales' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Executive')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
define("Red", "FF3300");
define("Green", "00CC33");
$hdr_bgcolor=Green;

if ($debug==1){
	if (! $DB_Conn) {
		DIE ("Could not connect to USRCREP02 Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to USRCREP02 Database. <br />";
	}
}


function get_UPS_Tracking($DB_Conn, $login, $site, $debug){

	$sp1 = mssql_init ( '[Data_Warehouse].dbo.usp_UPS_Tracking_List', $DB_Conn ); 

	mssql_bind ($sp1, '@in_User_ID', $login, SQLVARCHAR, false, false, 10);
	mssql_bind ($sp1, '@in_Site_ID', $site, SQLVARCHAR, false, false, 10);

	$result1 = mssql_execute ( $sp1 );

	$numrows=mssql_num_rows($result1);
	$_SESSION['List_Count']=$numrows;


	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result1, $i, 0);//Tracking_Number
		$answer[1][$i]=mssql_result($result1, $i, 1);//Order_ID
		$answer[2][$i]=mssql_result($result1, $i, 2);//Status
		$answer[3][$i]=mssql_result($result1, $i, 3);//Exception Description
		$answer[4][$i]=mssql_result($result1, $i, 4);//Manifest Date
		$answer[5][$i]=mssql_result($result1, $i, 5);//Called?
		$answer[6][$i]=mssql_result($result1, $i, 6);//Called Detail
		$answer[7][$i]=mssql_result($result1, $i, 7);//Scheduled Delivery Date
		$answer[8][$i]=mssql_result($result1, $i, 8);//Called?
		$answer[9][$i]=mssql_result($result1, $i, 9);//Called Detail
		$answer[10][$i]=mssql_result($result1, $i, 10);//Last Contact
		$answer[11][$i]=mssql_result($result1, $i, 11);//Customer
		$answer[12][$i]=mssql_result($result1, $i, 12);//Login
		$answer[13][$i]=mssql_result($result1, $i, 13);//Sales Rep Name
		$answer[14][$i]=mssql_result($result1, $i, 14);//Sales Manager
		$answer[15][$i]=mssql_result($result1, $i, 15);//Site
		$answer[16][$i]=mssql_result($result1, $i, 16);//Order Value

	}
	Return $answer;

	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode within Get_List function: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine while inside Get List Function. <br />";}

		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";

		echo "Query1: '<b>".$query_Good_Money."</b>'<br>";
		echo "Query2: '<b>".$query_AMEX."</b>'<br>";
		echo "Query3: '<b>".$query_Pending."</b>'<br>";

	}
}

function format_tbl_header($label, $width, $alignment="center", $hdr_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor.'"');
//	global $tbl_bgcolor;
//	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){

	echo ('<td align="'.$alignment.'" bgcolor="');
		
	echo $row_bgcolor.'"';

	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}


?>

<html>

<head>
<script type="text/javascript">
	function show_detail(Index_ID){
	<!--
	str_redirect1='./Survey_Add.php?$orig_index='+Index_ID
	window.open (str_redirect1, 'Asset_Window_'+Index_ID, config='height=800, width=800, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}





</script>

<script src="JS_Sort_Table.js"></script>



</head>
<title>USRCBR Sales Rep UPS Tracking Info</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);


	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Sales'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="SalesRep_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Sales Rep Tools: UPS Tracking Info</h2>');


	echo ('<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center , $hdr_bgcolor);
	format_tbl_header("Order ID", 100, center, $hdr_bgcolor);
	format_tbl_header("Status", 125, center, $hdr_bgcolor);
	format_tbl_header("Ship Date =>", 125, center, $hdr_bgcolor);
	format_tbl_header("Called?", 5, center, $hdr_bgcolor);
	format_tbl_header("Delivery Date =>", 125, center, $hdr_bgcolor);
	format_tbl_header("Called?", 5, center, $hdr_bgcolor);
	format_tbl_header("Last Contact", 125, center, $hdr_bgcolor);
	format_tbl_header("Customer", 150, center, $hdr_bgcolor);
	format_tbl_header("Sales Rep", 150, center, $hdr_bgcolor);
	format_tbl_header("Room", 50, center, $hdr_bgcolor);
	format_tbl_header("Order Value", 150, center, $hdr_bgcolor);
	echo ('</tr><tr>');

	if ($securitygroup=='Administrator' || $securitygroup=='Developer' || $securitygroup=='Executive'){
		$UPS_Tracking_List= get_UPS_Tracking($DB_Conn, 'ZZZ', $site, $debug);
	}
	else {
		$UPS_Tracking_List= get_UPS_Tracking($DB_Conn, $login, $site, $debug);
	}

	for ($i=0; $i<$_SESSION['List_Count']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	format_tbl_content($UPS_Tracking_List[1][$i], 100, center, $row_bgcolor);//Order_ID
	
	// Status
//	format_tbl_content($UPS_Tracking_List[2][$i], 125, center, $row_bgcolor);//Status
	
	if($UPS_Tracking_List[2][$i]=="Exception"){
		echo ('<td align="center" bgcolor='.$row_bgcolor.' title="'.$UPS_Tracking_List[3][$i].'">'.$UPS_Tracking_List[2][$i].'</td>');//Called

	}
	else 	{
		format_tbl_content($UPS_Tracking_List[2][$i], 125, center, $row_bgcolor);//Status
	}	





	format_tbl_content($UPS_Tracking_List[4][$i], 125, center, $row_bgcolor);//Manifest Date


	// Called After Manifest options
	if($UPS_Tracking_List[5][$i]=="No"){
		echo ('<td align="center" bgcolor='.Red.'><b>'.$UPS_Tracking_List[5][$i].'</b></td>');//Called
	}
	else 	{
		echo ('<td align="center" bgcolor='.$row_bgcolor.' title="'.$UPS_Tracking_List[6][$i].'">'.$UPS_Tracking_List[5][$i].'</td>');//Called
	}	


	//	format_tbl_content($UPS_Tracking_List[4][$i], 50, center, $row_bgcolor);//Called
	
	format_tbl_content($UPS_Tracking_List[7][$i], 150, center, $row_bgcolor);//Scheduled Delivery

	// Called After Delivery options	
	if($UPS_Tracking_List[8][$i]=="No"){
		echo ('<td align="center" bgcolor='.Red.'><b>'.$UPS_Tracking_List[8][$i].'</b></td>');//Called
	}
	else 	{
		echo ('<td align="center" bgcolor='.$row_bgcolor.' title="'.$UPS_Tracking_List[9][$i].'">'.$UPS_Tracking_List[8][$i].'</td>');//Called
	}	
	//format_tbl_content($UPS_Tracking_List[7][$i], 50, center, $row_bgcolor);//Called


	format_tbl_content($UPS_Tracking_List[10][$i], 150, left, $row_bgcolor);//Last_Contact
	format_tbl_content(ucwords(strtolower($UPS_Tracking_List[11][$i])), 150, left, $row_bgcolor);//Customer
	format_tbl_content($UPS_Tracking_List[12][$i], 50, center, $row_bgcolor);//Sales_Rep
	format_tbl_content($UPS_Tracking_List[15][$i], 50, center, $row_bgcolor);//Room
	echo ('<td align="right" bgcolor='.$row_bgcolor.'>$ '.number_format($UPS_Tracking_List[16][$i], 2).'</td>');//Order_Value

	echo ('</tr>');

	}	
	echo ('</table>');	
/*
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_detail('.($asset_list[0][$i]).')">');
echo ('<tr>');
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index

	format_tbl_content($UPS_Tracking_List[2][$i], 125, center, $row_bgcolor);//Status


	echo ('</tr>');
	}
 


 */





	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB2_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB2_UserName.'</b><br>');
			echo ('Database: <b>'.$DB2_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>



