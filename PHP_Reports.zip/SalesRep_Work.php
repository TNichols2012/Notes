<?php

$debug=0;

require_once ('DB_Login.php');

$DB_Conn = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); // Data_Warehouse
mssql_select_db ( $DB2_Database, $DB_Conn );

If ($debug==1) {	
	if (! $DB_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database ".$DB2_Host." <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database ".$DB2_Host.". <br />";}


	echo ('<br>**************************************************************************************<br>');

};


$firstname=$_GET['FirstName'];
$grosssales=$_GET['GrossSales'];
$custnum=$_GET['CustomerNumber'];
$phonenumber=$_GET['PhoneNumber'];
$lastname=$_GET['LastName'];
$agentname=$_GET['AgentName'];
$callstart=$_GET['CallStart'];
$callend=$_GET['CallEnd'];
$city=$_GET['City'];
$state=$_GET['State'];
$zip=$_GET['Zip'];
$pcid=$_GET['Primary_Call_ID'];
$fullname = $firstname.' ';
$fullname .= $lastname.' ';

$pcid=115000;

$url='CallStart='.$_GET['CallStart'].'&CallEnd='.$_GET['CallEnd'].'&GrossSales='.$_GET['GrossSales'].'&CustomerNumber='.$_GET['CustomerNumber'].'&FirstName='.$_GET['FirstName'].'&LastName='.$_GET['LastName'].'&AgentName='.$_GET['AgentName'].'&City='.$_GET['City'].'&State='.$_GET['State'].'&Zip='.$_GET['Zip'].'&Primary_Call_ID='.$_GET['Primary_Call_ID'];


function Confirmation_Screen($in_Disposition, $debug)
{
	echo ('<br>Please confirm your disposition.<br><br>');
	echo ('<br>You have chosen disposition.<br><br>   <b>');

	switch ($in_Disposition) {
		case 116:
			echo "Certified<br>";
			break;
		case 34:
			echo "Bullion<br>";
			break;
		case 117:
			echo "Mixed<br>";
			break;
		case 118:
			echo "Info Sent<br>";
			break;
		case 119:
			echo "No Deal<br>";
			break;
		case 132:
			echo "Left Message<br>";
			break;
		case 131:
			echo "No Answer<br>";
			break;
		case 133:
			echo "Junk Call<br>";
			break;
		case 135:
			echo "Will Call Back<br>";
			break;
		case 120:
			echo "Business Support<br>";
			break;
		case 121:
			echo "Customer Relations<br>";
			break;
		case 122:
			echo "CCM Removal<br>";
			break;
		case 124:
			echo "Verification<br>";
			break;
		case 125:
			echo "Relationship Building<br>";
			break;
		case 126:
			echo "Other<br>";
			break;
		case 123:
			echo "Deceased<br>";
			break;
		case 127:
			echo "Do Not Call<br>";
			break;
		case 128:
			echo "Do Not Mail<br>";
			break;
		case 129:
			echo "Do Not Call or Mail<br>";
			break;
		case 130:
			echo "Bad Phone Number<br>";
			break;

	}
	
	echo ('</b><br>To confirm, choose "YES", to re-select, choose "NO"');
	

}

function Button_Insert ($DB_Conn, $in_Primary_Call_ID, $in_Disposition, $debug)
	{
        $sp = mssql_init ( 'usp_ShoreTel_Edit_Disposition', $DB_Conn ); //init stored procedure  
	mssql_bind ( $sp, '@in_Primary_Call_ID', $in_Primary_Call_ID, SQLINT4, false,false,50);
	mssql_bind ( $sp, '@in_Disposition', $in_Disposition, SQLINT4, false,false,50);

	mssql_execute ( $sp );

	if ($debug==1){
		echo ('<br>Update sent');
		echo ('<br>in Primary Call ID is: '.$in_Primary_Call_ID);
		echo ('<br>in Disposition is: '.$in_Disposition);
	}
	return; 
} 

if ($debug==1)
	{
	echo "Debugging On...<br><br>";
	echo "Customer Name: ".$fullname."<br>";
	echo "Gross Sales: ".$grosssales."<br>";
	echo "Cust #: ".$custnum."<br>";
	echo "Phone #: ".$phonenumber."<br>";
	echo "First Name: ".$firstname."<br>";
	echo "Last Name: ".$lastname."<br>";
	echo "City: ".$city."<br>";
	echo "State: ".$state."<br>";
	echo "Zip: ".$zip."<br>";
	echo "Agent: ".$agentname."<br>";
	echo "Call Start: ".$callstart."<br>";
	echo "Call End: ".$callend."<br>";
	echo "URL: ".$url."<br>";
	}

if ($_POST['Disp116']){
	$exit=True;
	Confirmation_Screen(116, $debug);
	Button_Insert($DB_Conn, $pcid, 116, $debug);
}

if ($_POST['Disp34']){
	$exit=True;
	Confirmation_Screen(34, $debug);
	Button_Insert($DB_Conn, $pcid, 34, $debug);
}

if ($_POST['Disp117']){
	$exit=True;
	Confirmation_Screen(117, $debug);
	Button_Insert($DB_Conn, $pcid, 117, $debug);
}

if ($_POST['Disp118']){
	$exit=True;
	Confirmation_Screen(118, $debug);
	Button_Insert($DB_Conn, $pcid, 118, $debug);
}

if ($_POST['Disp119']){
	$exit=True;
	Confirmation_Screen(119, $debug);
	Button_Insert($DB_Conn, $pcid, 119, $debug);
}

if ($_POST['Disp132']){
	$exit=True;
	Confirmation_Screen(132, $debug);
	Button_Insert($DB_Conn, $pcid, 132, $debug);
}

if ($_POST['Disp131']){
	$exit=True;
	Confirmation_Screen(131, $debug);
	Button_Insert($DB_Conn, $pcid, 131, $debug);
}

if ($_POST['Disp133']){
	$exit=True;
	Confirmation_Screen(133, $debug);
	Button_Insert($DB_Conn, $pcid, 133, $debug);
}

if ($_POST['Disp135']){
	$exit=True;
	Confirmation_Screen(135, $debug);
	Button_Insert($DB_Conn, $pcid, 135, $debug);
}

if ($_POST['Disp120']){
	$exit=True;
	Confirmation_Screen(120, $debug);
	Button_Insert($DB_Conn, $pcid, 120, $debug);
}

if ($_POST['Disp121']){
	$exit=True;
	Confirmation_Screen(121, $debug);
	Button_Insert($DB_Conn, $pcid, 121, $debug);
}

if ($_POST['Disp122']){
	$exit=True;
	Confirmation_Screen(122, $debug);
	Button_Insert($DB_Conn, $pcid, 122, $debug);
}

if ($_POST['Disp124']){
	$exit=True;
	Confirmation_Screen(124, $debug);
	Button_Insert($DB_Conn, $pcid, 124, $debug);
}

if ($_POST['Disp125']){
	$exit=True;
	Confirmation_Screen(125, $debug);
	Button_Insert($DB_Conn, $pcid, 125, $debug);
}

if ($_POST['Disp126']){
	$exit=True;
	Confirmation_Screen(126, $debug);
	Button_Insert($DB_Conn, $pcid, 126, $debug);
}

if ($_POST['Disp123']){
	$exit=True;
	Confirmation_Screen(123, $debug);
	Button_Insert($DB_Conn, $pcid, 123, $debug);
}

if ($_POST['Disp127']){
	$exit=True;
	Confirmation_Screen(127, $debug);
	Button_Insert($DB_Conn, $pcid, 127, $debug);
}

if ($_POST['Disp128']){
	$exit=True;
	Confirmation_Screen(128, $debug);
	Button_Insert($DB_Conn, $pcid, 128, $debug);
}

if ($_POST['Disp129']){
	$exit=True;
	Confirmation_Screen(129, $debug);
	Button_Insert($DB_Conn, $pcid, 129, $debug);
}

if ($_POST['Disp130']){
	$exit=True;
	Confirmation_Screen(130, $debug);
	Button_Insert($DB_Conn, $pcid, 130, $debug);
}

if($exit == True)
{
?>
<script language=JavaScript>
	window.open('','_self');
	window.close();
</script>
<?php
}

//$php_page=htmlentities($_SERVER['PHP_SELF']);


?>


<HTML>
<HEAD>

<script type="text/javascript">
	function Insert_Data(Disposition_ID){

<?php
	

	//Button_Insert($DB_Conn, 110000, Disposition_ID, $debug);

//	echo ('<br>Seems to work okay<br>');

?>

	
</script>

<META NAME="GENERATOR" Content="Microsoft DHTML Editing Control">
<TITLE>Customer Contact Manager - Disposition</TITLE>
</HEAD>

<BODY style="filter:progid:DXImageTransform.Microsoft.Gradient(endColorstr='#000000', startColorstr='#C0CFE2', gradientType='1');"> 

<?php

echo ('<table width=1024 align=center>');
echo ('<tr>');
echo ('<td colspan=2 align=center>');
echo ('<font face=Tahoma color=#0000ff size=7>');
echo ('<strong><U>CUSTOMER CONTACT (MANUAL DIAL)</U></strong>');
echo ('</font>');
echo ('</td>');
echo ('</tr>');

echo ('<tr>');
echo ('<td width=512 align=right>');
echo ('<font face=Arial color=#008000 size=5>');
echo ('<strong>Customer Name:</strong>');
echo ('</font> ');
echo ('</td>');

echo ('<td width=512 align=left>');
echo ('<input value="'.$firstname.' '.$lastname.'" ');
echo ('style="width: 256px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');
echo ('</tr></table>');



echo ('<tr><table align=center>');
echo ('<td colspan=6 align=center><font face=Verdana size=2><strong><U><font color=#804ffff size=4>CUSTOMER INFO</font></U></strong></font>');
echo ('</tr>');

echo ('<tr>');
echo ('<td colspan=2 align=right><font face=Arial size=4 color=#ffffff>Gross Sales</td>');
echo ('<td colspan=3 align=left><input value="'.$grosssales.'" ');
echo (' style="width: 256px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td><td></td>');
echo ('</tr>');


echo ('<tr>');
echo ('<td colspan=2 align=right><font face=Arial size=4 color=#ffffff>M.O.M. Customer #</td>');
echo ('<td colspan=3 align=left><input value="'.$custnum.'" ');
echo (' style="width: 256px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');
echo ('</tr>');


echo ('<tr>');
echo ('<td colspan=2 align=right><font face=Arial size=4 color=#ffffff>Phone #</td>');
echo ('<td colspan=3 align=left><input value="'.$phonenumber.'" ');
echo (' style="width: 256px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');
echo ('</tr>');


echo ('<tr>');
echo ('<td colspan=2 align=right><font face=Arial size=4 color=#ffffff>First Name</td>');
echo ('<td colspan=3 align=left><input value="'.$firstname.'" ');
echo (' style="width: 256px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');
echo ('</tr>');


echo ('<tr>');
echo ('<td colspan=2 align=right><font face=Arial size=4 color=#ffffff>Last Name</td>');
echo ('<td colspan=3 align=left><input value="'.$lastname.'" ');
echo (' style="width: 256px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');
echo ('</tr>');


echo ('<tr>');
echo ('<td colspan=2 align=right><font face=Arial size=4 color=#ffffff>City</td>');
echo ('<td colspan=3 align=left><input value="'.$city.'" ');
echo (' style="width: 256px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');
echo ('</tr>');


echo ('<tr>');
echo ('<td colspan=2 align=right><font face=Arial size=4 color=#ffffff>State</td>');
echo ('<td align=left><input value="'.$state.'" ');
echo (' style="width: 56px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');

echo ('<td align=right><font face=Arial size=4 color=#ffffff>Zip</td>');
echo ('<td align=left><input value="'.$zip.'" ');
echo (' style="width: 56px; height: 22px" readOnly size=48 ExtAttrs=');
echo ('<Validations>');
echo ('<PhysicalValidation ReadOnly="True" Strong="True" Type="String" NullAllowed="True" MaxLength="100" Mask="" KeepMaskMarkers="False" />');
echo ('</Validations>');
echo ('</td>');
echo ('<td></td>');

echo ('</tr><tr></tr>');

echo ('</table>');


//echo ('URL looks like: '.$url.' ...did it work?');

echo ('<form action ="http://usrcrep01/PHP_Reports/SalesRep_Work.php?'.$url.'" method="post"><table align=center>');

//
//echo ('./SalesRep_Work.php?'.$url);
//

?>









<tr>
<td colspan=5 align=center><font face=Verdana size=2><strong><U><font color=#804ffff size=4>FINISHED CALL OPTIONS</font></U></strong></font>
</td></tr>



<tr>
<td colspan=5 align=center>
<font face=Verdana size=2><strong><font color=#0000ff size=4>SALES</font></strong></font><BR>
</td>
</tr>
<tr>
<td>
<input type="submit" name="Disp116" value="Certified" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(116)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp34" value="Bullion" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(34)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp117" value="Mixed" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(117)">
</td>

</tr><tr></tr>

<tr>

<td>
<input type="submit" name="Disp118" value="Info Sent" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(118)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp119" value="No Deal" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(119)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp132" value="Left Message" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(132)">
</td>

</tr><tr></tr>

<tr>

<td>
<input type="submit" name="Disp131" value="No Answer" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(131)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp133" value="Junk Call" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(133)"></td><td width=32px></td>

<td>
<input type="submit" name="Disp135" value="Will Call Back" style="font size=16; font-weight: bold; width: 200px; color: blue; height: 30px"
onclick="javascript:Insert_Data(135)">
</td>

</tr><tr></tr>

<tr>
<td colspan=5 align=center>
<font face=Verdana size=2><strong><font color=#804000 size=4>SUPPORT</font></strong></font><BR>
</td>
</tr>

<tr>

<td>
<input type="submit" name="Disp120" value="Business Support" style="font size=16; font-weight: bold; width: 200px; color: #804000; height: 30px"
onclick="javascript:Insert_Data(120)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp121" value="Customer Relations" style="font size=16; font-weight: bold; width: 200px; color: #804000; height: 30px"
onclick="javascript:Insert_Data(121)">

</td><td width=32px></td>

<td>
<input type="submit" name="Disp122" value="CCM Removal" style="font size=16; font-weight: bold; width: 200px; color: #804000; height: 30px"
onclick="javascript:Insert_Data(122)">
</td>

</tr>

<tr>
<td colspan=5 align=left>
<font face=Verdana size=2><strong><font color=#804000 size=4>* Requires a SIMS submission</font></strong></font><BR>
</td>
</tr>

<tr></tr>

<tr>
<td colspan=5 align=center>
<font face=Verdana size=2><strong><font color=#800040 size=4>SALES MANAGER ONLY</font></strong></font><BR>
</td>
</tr>

<tr>

<td>
<input type="submit" name="Disp124" value="Verification" style="font size=16; font-weight: bold; width: 200px; color: #800040; height: 30px"
onclick="javascript:Insert_Data(124)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp125" value="Relationship Building" style="font size=16; font-weight: bold; width: 200px; color: #800040; height: 30px"
onclick="javascript:Insert_Data(125)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp126" value="Other" style="font size=16; font-weight: bold; width: 200px; color: #800040; height: 30px"
onclick="javascript:Insert_Data(126)">
</td>
</tr>

<tr></tr>


<tr>
<td colspan=5 align=center>
<font face=Verdana size=2><strong><font color=#008000 size=4>BUCKET REMOVAL</font></strong></font><BR>
</td>
</tr>

<tr>

<td>
<input type="submit" name="Disp123" value="Deceased" style="font size=16; font-weight: bold; width: 200px; color: #008000; height: 30px"
onclick="javascript:Insert_Data(123)">
</td><td width=32px></td>
<td>
<input type="submit" name="Disp127" value="Do Not Call" style="font size=16; font-weight: bold; width: 200px; color: #008000; height: 30px"
onclick="javascript:Insert_Data(127)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp128" value="Do Not Mail" style="font size=16; font-weight: bold; width: 200px; color: #008000; height: 30px"
onclick="javascript:Insert_Data(128)">
</td>
</tr>

<tr>
<td>
<input type="submit" name="Disp129" value="Do Not Call or Mail" style="font size=16; font-weight: bold; width: 200px; color: #008000; height: 30px"
onclick="javascript:Insert_Data(129)">
</td><td width=32px></td>

<td>
<input type="submit" name="Disp130" value="Bad Phone Number" style="font size=16; font-weight: bold; width: 200px; color: #008000; height: 30px"
onclick="javascript:Insert_Data(130)">
</td>
</tr>


</form></table>


</BODY>
</HTML>
