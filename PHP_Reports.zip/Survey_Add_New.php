<?php
session_start();

require_once ('DB_Login.php');

$debug=0;

$DB_Conn = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); 
mssql_select_db ( $DB2_Database, $DB_Conn );

$orig_list		= $_SESSION['Asset_List'];
$orig_index		= $_GET['$orig_index'];
$orig_order_date	= $orig_list[0][$_GET['$orig_index']];
$orig_order_id		= $orig_list[1][$_GET['$orig_index']];
$orig_customer_id	= $orig_list[2][$_GET['$orig_index']];
$orig_first_name	= $orig_list[3][$_GET['$orig_index']];
$orig_last_name		= $orig_list[4][$_GET['$orig_index']];
$orig_sales_id		= $orig_list[5][$_GET['$orig_index']];
$orig_room		= $orig_list[6][$_GET['$orig_index']];
$orig_contact_number	= $orig_list[7][$_GET['$orig_index']];
$orig_order_value	= $orig_list[8][$_GET['$orig_index']];
$orig_sales_name	= $orig_list[9][$_GET['$orig_index']];
$orig_alternate_number	= $orig_list[10][$_GET['$orig_index']];

if (rtrim($orig_alternate_number)=='') {
	$orig_alternate_number='None';
}

$orig_inventory='';

If ($debug==1) {	
	if (! $DB_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database. <br />";}

	echo ('<br>GET index: '.$_GET['$orig_index']);	
	echo ('<br>Original Order Date: '.$orig_order_date);	
	echo ('<br>Original Cust ID: '.$orig_customer_id);
	echo ('<br>Original Contact Number: '.$orig_contact_number);
	echo ('<br>DB Host: '.$DB2_Host);	
	echo ('<br>DB Used: '.$DB2_Database);	
	echo ('<br>DB User: '.$DB2_UserName);	
	echo ('<br>Surveyor Session: <b>'.$_SESSION['$in_surveyor'].'</b>');


	echo ('<br>**************************************************************************************');

};


function get_sales_rep ($DB_Conn, $in_Room, $debug){

	if ($in_Room=='' OR $in_Room =='All Rooms'){
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" vSR.Site ='".$in_Room."'";
	}

	
	$query_Sales_Rep= " 
		SELECT
		vSR.[Name],
		vSR.Sales_ID
		FROM dbo.vw_Survey_Review vSR
		WHERE vSR.Sales_ID <>'XXX'
		AND ".$SQL_Room."
		GROUP BY vSR.[Name], vSR.Sales_ID
		ORDER BY vSR.[Name], vSR.Sales_ID
		";

	$result=mssql_query($query_Sales_Rep, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Sales_Rep_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$textout[0][$i]=mssql_result($result, $i, 0);//Name
		$textout[1][$i]=mssql_result($result, $i, 1);//Sales_ID
		
	}
	
	if ($debug==2) {
		if (! $DB_Conn) {
			die ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		else {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}

		echo "fct get sales rep POST in Room : '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "fct get sales rep in Room: '<b>".$in_Room."</b>'<br>";
		echo "fct get sales rep query: '<b>".$query_Sales_Rep."</b>'<br>";
		echo "fct get sales rep num rows: '<b>".$numrows."</b>'<br>";		


	}; // if ($debug==1)

	Return $textout;
}



function Submit_Record_Insert ($DB_Conn, $in_Sales_ID, $in_Order_ID, $in_Email_Requested, $in_Gold_Owner, $in_Collector_Type, $in_Other_Companies, $in_Specialist_Name, $in_Level_One, $in_Level_Two, $in_Level_Three, $in_Survey_Rating, $in_Surveyor, $in_Survey_Minutes, $in_Comments, $debug)
	{
        $sp = mssql_init ( 'usp_Survey_Insert', $DB_Conn ); //init stored procedure  
	mssql_bind ( $sp, '@in_Sales_ID', $in_Sales_ID, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Order_ID', $in_Order_ID, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Email_Request', $in_Email_Requested, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Gold_Owner', $in_Gold_Owner, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Collector_Type', $in_Collector_Type, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Other_Companies', $in_Other_Companies, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Specialist_Name', $in_Specialist_Name, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Level_One', $in_Level_One, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Level_Two', $in_Level_Two, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Level_Three', $in_Level_Three, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Survey_Rating', $in_Survey_Rating, SQLINT1, false,false,50);
	mssql_bind ( $sp, '@in_Surveyor', $in_Surveyor, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Survey_Minutes', $in_Survey_Minutes, SQLINT1, false,false,50);
	mssql_bind ( $sp, '@in_Comments', $in_Comments, SQLTEXT, false,false,5000);

	mssql_execute ( $sp );

	if ($debug==1){
		echo ('<br>Insert sent');
		echo ('<br>Database connection is: '.$DB_Conn);
		echo ('<br>Updated sales ID is: '.$in_Sales_ID);
		echo ('<br>Updated order ID is: '.$in_Order_ID);
		echo ('<br>Updated surveyor is: '.$in_Surveyor);


		echo ('<br>Updated Comment is: '.$in_Comments);
	}
	return; 
} 


?>

<html>
<title>USRCBR Customer Service Quality Assurance</title>
<head>

<script type="text/javascript">
	function show_asset(Phone_ID){
	<!--
	str_redirect='./Survey_Phone.php?$orig_index='+Phone_ID
	window.open (str_redirect, 'Asset_Window_'+Phone_ID, config='height=400, width=1200, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}
</script>

<script src="JS_Sort_Table.js"></script>

</head>

<body>
<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);

$sales_reps=get_sales_rep($DB_Conn, '', 0);

if ($_POST['Add']){
$orig_inventory='Close';
//$orig_inventory='Add';

$in_Email_Requested	=($_POST["in_Email_Requested"]);
$in_Gold_Owner		=($_POST["in_Gold_Owner"]);
$in_Collector_Type	=($_POST["in_Collector_Type"]);
$in_Other_Companies	=($_POST["in_Other_Companies"]);
$in_Specialist_Name	=($_POST["in_Specialist_Name"]);
$in_Level_One		=($_POST["in_Level_One"]);
$in_Level_Two		=($_POST["in_Level_Two"]);
$in_Level_Three		=($_POST["in_Level_Three"]);
$in_Comments		=($_POST["in_Comments"]);
$in_Surveyor		=($_POST['in_Surveyor']);
$in_Survey_Minutes	=($_POST["in_Survey_Minutes"]);

$orig_sales_id		=($_POST["in_Sales_Rep"]);
$orig_order_id		=($_POST["in_Reference_ID"]);
//$_SESSION['$in_surveyor']=$_POST["in_Surveyor"];

$in_Survey_Rating=100;

if($in_Email_Requested=='No'){
	$in_Survey_Rating=$in_Survey_Rating-5;
}

if($in_Gold_Owner=='No'){
	$in_Survey_Rating=$in_Survey_Rating-5;
}

if(rtrim($in_Level_One!='')){
	$in_Survey_Rating=$in_Survey_Rating-20;
}

if(rtrim($in_Level_Two!='')){
	$in_Survey_Rating=$in_Survey_Rating-30;
}

if(rtrim($in_Level_Three!='')){
	$in_Survey_Rating=$in_Survey_Rating-40;
}

Submit_Record_Insert($DB_Conn, $orig_sales_id, $orig_order_id, $in_Email_Requested, $in_Gold_Owner, $in_Collector_Type, $in_Other_Companies, $in_Specialist_Name, $in_Level_One, $in_Level_Two, $in_Level_Three, $in_Survey_Rating, $in_Surveyor, $in_Survey_Minutes, $in_Comments, $debug);

	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine. <br> Second Pass. <br>";}


		echo "Email: '<b>".$_POST["in_Email_Requested"]."</b>'<br>";
		echo "Gold?: '<b>".$_POST["in_Gold_Owner"]."</b>'<br>";
		echo "Collector: '<b>".$_POST["in_Collector_Type"]."</b>'<br>";
		echo "Company: '<b>".$_POST["in_Other_Companies"]."</b>'<br>";
		echo "Name: '<b>".$_POST["in_Specialist_Name"]."</b>'<br>";
		echo "Level 1: '<b>".$_POST["in_Level_One"]."</b>'<br>";
		echo "Level 2: '<b>".$_POST["in_Level_Two"]."</b>'<br>";
		echo "Level 3: '<b>".$_POST["in_Level_Three"]."</b>'<br>";
		echo "Suggestions to Sales Reps: '<b>".$_POST["in_Comments"]."</b>'<br>";
		echo "rating: '<b>".$in_Survey_Rating."</b>'<br>";
		echo "Surveyor (in string): '<b>".$in_Surveyor."</b>'<br>";
		echo "Surveyor (session string): '<b>".$_SESSION['$in_surveyor']."</b>'<br>";
		echo "Sales Rep (orig sales id): '<b>".$orig_sales_id."</b>'<br>";
		echo "Sales Rep: '<b>".$_POST["in_Sales_Rep"]."</b>'<br>";

		echo "Reference ID: '<b>".$orig_order_id."</b>'<br>";
		echo "Reference ID (post): '<b>".$_POST["in_Reference_ID"]."</b>'<br>";
	};

}

if($orig_inventory == 'Close')
{
?>
<script language=JavaScript>
window.close();
</script>
<?php
}

if($orig_inventory==''){
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Customer Service: Survey Selection Confirmation</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>

	<table align=center>
	</table>
	<br>
	<br>

	<form action="./Survey_Add_New.php?$orig_index='.$orig_index.'" method="POST">
	<table align=center>

	<tr>
	<td valign="top" align="left">
	<label>Survey for: <br>
	<select name="in_Sales_Rep" onChange="submit()">
	<option>'.$_POST["in_Sales_Rep"].'</option>
	<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>');
		for($i=0;$i<$_SESSION['Sales_Rep_Count'];$i+=1){
		echo ('<option value="'.$sales_reps[1][$i].'">'.$sales_reps[0][$i].'</option>  ');
		}

	echo ('</td>
		<td valign="top" align="left">
		<label>By: <br>
		<select name="in_Surveyor" onChange="submit()">
		<option value='.$_POST["in_Surveyor"].'>'.$_POST["in_Surveyor"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="CM">CM</option>
		<option value="LB">LB</option>
		<option value="SK">SK</option>
		<option value="TN">TN</option>
		</td>

	<td style="width=150px" align=center valign=top>
	<label>Reference ID<br>
	<input type="text" name="in_Reference_ID" size=20 align=left value="'.$_POST["in_Surveyor"].date(m).date(d).date(y).date(H).date(i).'">
	</label>
	</td>

	</tr>
	<tr> </tr>

	<tr>
	<td style="width=100px" align=left>
	<fieldset>
	<label>Yes<input type="radio" name="in_Email_Requested" value="Yes"/></label>
	<label>No<input type="radio" name="in_Email_Requested" value="No" checked="checked" /></label>
	</fieldset>
	</td>
	<td colspan=4 align=left>
	 (5 Points) Email Requested?
	</td>
	</tr>

	<tr>
	<td style="width=100px" align=left>
	<fieldset>
	<label>Yes<input type="radio" name="in_Gold_Owner" value="Yes"/></label>
	<label>No<input type="radio" name="in_Gold_Owner" value="No" checked="checked" /></label>
	</fieldset>
	</td>
	<td colspan=4>
	(5 Points) Did they ask if the potential customer owned gold? 
	</td>
	</tr>

	<tr>
	<td>
	</td>
	<td colspan=4>
	What type of coins did they collect? <i>(if applicable)</i><br>
	<select name="in_Collector_Type">
	<option value="Not Applicable">Not Applicable</option>
	<option value="None">None</option>
	<option value="Bullion">Bullion</option>
	<option value="Numismatic">Numismatic</option>
	<option value="Combo">Combo</option>
	</td>
	</tr>

	<tr>
	<td valign="bottom">Survey
	</td>
	<td colspan=4>
	<label>What company or companies have they worked with? <br>
	<input type="text" name="in_Other_Companies" size=50 align=left></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td>
	<label>Minutes?<br>
	<input type="text" name="in_Survey_Minutes" size="5" align=center></label>
	</td>
	<td colspan=4>
	<label>Did they know the name of their Gold Specialist? <br>
	<input type="text" name="in_Specialist_Name" size=50 align=left></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(20 Points) Level I Offense <br>
	<input type="text" name="in_Level_One" size=80 align=left></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(30 Points) Level II Offense <br>
	<input type="text" name="in_Level_Two" size=80 align=left></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(40 Points) Level III Offense<br>
	<input type="text" name="in_Level_Three" size=80 align=left></label>	
	</td>
	<td>
	</td>
	</tr>

	<tr><td colspan=5>
	<label>Survey Notes:<br>
       	<textarea name="in_Comments" cols=60 rows=3 align=center></textarea></label>
	</td></tr>

	<tr><td colspan=5 align=center>
	<input type="submit" name="Add" value="Add" />
	</td>

	</table></form>');
	echo "<br>";


} // end if($inve_asset_tag==='')
else {
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Customer Service: Survey Selection Confirmation</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>

	<table align=center>
	</table>
	<br><br>

	<form action="./Survey_Add_New.php?$orig_index='.$orig_index.'" method="POST">
	<table align=center>
	<tr>
	<td valign="top" align="left">
	<label>Survey for: <br>
	<select name="in_Sales_Rep" onChange="submit()">
	<option>'.$_POST["in_Sales_Rep"].'</option>
	<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>');
		for($i=0;$i<$_SESSION['Sales_Rep_Count'];$i+=1){
		echo ('<option value="'.$sales_reps[0][$i].'">'.$sales_reps[0][$i].'</option>  ');
		}

	echo ('</td>
		<td valign="top" align="left">
		<label>By: <br>
		<select name="in_Surveyor" onChange="submit()">
		<option value='.$_POST["in_Surveyor"].'>'.$_POST["in_Surveyor"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="CM">CM</option>
		<option value="LB">LB</option>
		<option value="SK">SK</option>
		<option value="TN">TN</option>
		</td>

	<td style="width=150px" align=center valign=top>
	<label>Reference ID<br>
	<input type="text" name="in_Reference_ID" size=20 align=left value="'.$_POST["in_Surveyor"].'">
	</label>
	</td>

	<td style="width=100px" align=left>
	<fieldset>');

	if ($in_Email_Requested=="Yes"){
	echo ('	<label>Yes<input type="radio" name="in_Email_Requested" value="Yes" checked="checked"></label>
		<label>No<input type="radio" name="in_Email_Requested" value="No"></label>');
	}
	else {
	echo ('	<label>Yes<input type="radio" name="in_Email_Requested" value="Yes"></label>
		<label>No<input type="radio" name="in_Email_Requested" value="No" checked="checked"></label>');
	}
	echo ('
	</fieldset>
	</td>
	<td colspan=4 align=left>
	 (5 Points) Email Requested?
	</td>
	</tr>

	<tr>
	<td style="width=100px" align=left>
	<fieldset>');

	if ($in_Gold_Owner=="Yes"){
	echo ('	<label>Yes<input type="radio" name="in_Gold_Owner" value="Yes" checked="checked"></label>
		<label>No<input type="radio" name="in_Gold_Owner" value="No"></label>');
	}
	else {
	echo ('	<label>Yes<input type="radio" name="in_Gold_Owner" value="Yes"></label>
		<label>No<input type="radio" name="in_Gold_Owner" value="No" checked="checked"></label>');
	}
	echo ('
	</fieldset>
	</td>
	<td colspan=4>
	(5 Points) Did they ask if the potential customer owned gold? 
	</td>
	</tr>

	<tr>
	<td>
	</td>
	<td colspan=4>
	What type of coins did they collect? <i>(if applicable)</i><br>
	<select name="in_Collector_Type">
	<option>'.$in_Collector_Type.'</option>
	<option value="Not Applicable">Not Applicable</option>
	<option value="None">None</option>
	<option value="Bullion">Bullion</option>
	<option value="Numismatic">Numismatic</option>
	<option value="Combo">Combo</option>
	</td>
	</tr>

	<tr>
	<td valign="bottom">Survey
	</td>
	<td colspan=4>
	<label>What company or companies have they worked with? <br>
	<input type="text" name="in_Other_Companies" size=50 align=left value="'.$in_Other_Companies.'"></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td>
	<label>Minutes?<br>
	<input type="text" name="in_Survey_Minutes" size="5" align=center value="'.$in_Survey_Minute.'"></label>
	</td>
	<td colspan=4>
	<label>Did they know the name of their Gold Specialist? <br>
	<input type="text" name="in_Specialist_Name" size=50 align=left value="'.$in_Specialist_Name.'"></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(20 Points) Level I Offense <br>
	<input type="text" name="in_Level_One" size=80 align=left value="'.$in_Level_One.'"></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(30 Points) Level II Offense <br>
	<input type="text" name="in_Level_Two" size=80 align=left value="'.$in_Level_Two.'"></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(40 Points) Level III Offense<br>
	<input type="text" name="in_Level_Three" size=80 align=left value="'.$in_Level_Three.'"></label>	
	</td>
	<td>
	</td>
	</tr>

	<tr><td colspan=5>
	<label>Suggestions to Sales Reps:<br>
       	<textarea name="in_Comments" cols=60 rows=3 align=center>'.$in_Comments.'</textarea></label>
	</td></tr>

	<tr><td colspan=5 align=center>
	<input type="submit" name="Add" value="Add" />
	</td>

	</table></form>');
	echo "<br>";

	


}; //else ($orig_inventory<>'')



	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine. <br> First Pass. <br>";}


		echo "Email: '<b>".$_POST["in_Email_Requested"]."</b>'<br>";
		echo "Gold?: '<b>".$_POST["in_Gold_Owner"]."</b>'<br>";
		echo "Collector: '<b>".$_POST["in_Collector_Type"]."</b>'<br>";
		echo "Company: '<b>".$_POST["in_Other_Companies"]."</b>'<br>";
		echo "Name: '<b>".$_POST["in_Specialist_Name"]."</b>'<br>";
		echo "Level 1: '<b>".$_POST["in_Level_One"]."</b>'<br>";
		echo "Level 2: '<b>".$_POST["in_Level_Two"]."</b>'<br>";
		echo "Level 3: '<b>".$_POST["in_Level_Three"]."</b>'<br>";
		echo "Suggestions to Sales Reps: '<b>".$_POST["in_Comments"]."</b>'<br>";
		echo "rating: '<b>".$in_Survey_Rating."</b>'<br>";

		echo "Surveyor (in string): '<b>".$in_Surveyor."</b>'<br>";
		echo "Surveyor (session string): '<b>".$_SESSION['$in_surveyor']."</b>'<br>";
		echo "Sales Rep (orig sales id): '<b>".$orig_sales_id."</b>'<br>";
		echo "Sales Rep: '<b>".$_POST["in_Sales_Rep"]."</b>'<br>";

		echo "Reference ID: '<b>".$orig_order_id."</b>'<br>";
		echo "Reference ID (post): '<b>".$_POST["in_Reference_ID"]."</b>'<br>";



	};

 


?>
</body>
</html>
