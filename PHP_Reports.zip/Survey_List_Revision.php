<?php
session_start();

require_once ('DB_Login.php');

$debug=0;

$DB_Conn = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); 
mssql_select_db ( $DB2_Database, $DB2_Conn );

If ($debug==1) {	
	IF (! $DB_Conn) {
		DIE ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Debug Mode: ON <br> Successfully connected to database. <br />";}
};

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$tbl_bgcolor="Yellow";

function get_list ($DB_Conn, $in_Category, $in_Room){

	if ($in_Room=='' OR $in_Room =='All Rooms'){
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" dbo.tbl_Sales_Teams.Site ='".$in_Room."'";
	}

	$query_AMEX="
		SELECT     TOP (100) PERCENT 
		CONVERT(CHAR(10), RDBFCMS.odr_date, 110) AS Order_Date, 
		RDBFCMS.[order] AS Order_ID, 
		RDBFCMS.custnum AS Cust_ID, 
		tDBFCUST.First_Name, 
		tDBFCUST.Last_Name, 
		RDBFCMS.sales_id, 
		(CASE 
		WHEN dbo.tbl_Sales_Teams.Site = 'Austin' THEN 'AU'
		WHEN dbo.tbl_Sales_Teams.Site = 'Beaumont' THEN 'BM'
		WHEN dbo.tbl_Sales_Teams.Site = 'C3' THEN 'C3'
		ELSE '' END) AS Room,
		tDBFCUST.Contact_Number,
		RDBFCMS.tb_merch,
		dbo.tbl_Sales_Teams.Name,
		tDBFCUST.Contact_Number2
		FROM         dbo.Results_DBF_CMS AS RDBFCMS 
		INNER JOIN dbo.tbl_DBF_Cust AS tDBFCUST 
		ON RDBFCMS.custnum = tDBFCUST.Cust_ID 
		INNER JOIN dbo.tbl_Sales_Teams 
		ON RDBFCMS.sales_id = dbo.tbl_Sales_Teams.Login
		WHERE     (RDBFCMS.cardtype IN ('AE', 'A2', 'A3')) 
		AND (RDBFCMS.odr_date >= dbo.Get_TheDate(GETDATE() - 3))
		AND (".$SQL_Room.")
		AND RDBFCMS.[order] NOT IN (Select Order_ID From tbl_Survey)
		GROUP BY RDBFCMS.odr_date, 
		RDBFCMS.[order], 
		RDBFCMS.custnum, 
		tDBFCUST.First_Name, 
		tDBFCUST.Last_Name, 
		RDBFCMS.sales_id, 
		tDBFCUST.Contact_Number, 
		dbo.tbl_Sales_Teams.Site,
		RDBFCMS.tb_merch,
		dbo.tbl_Sales_Teams.Name,
		tDBFCUST.Contact_Number2
		ORDER BY RDBFCMS.tb_merch DESC
		";

	$query_Pending="
		SELECT     TOP (100) PERCENT 
		CONVERT(CHAR(10), dbo.tbl_DBF_CMS.Order_Date, 110) AS Order_Date, 
		dbo.tbl_DBF_CMS.Order_ID, 
		dbo.tbl_DBF_CMS.Cust_ID, 
		dbo.tbl_DBF_Cust.First_Name, 
		dbo.tbl_DBF_Cust.Last_Name, 
		dbo.tbl_DBF_CMS.Sales_ID, 
		(CASE 
		WHEN dbo.tbl_Sales_Teams.Site = 'Austin' THEN 'AU'
		WHEN dbo.tbl_Sales_Teams.Site = 'Beaumont' THEN 'BM'
		WHEN dbo.tbl_Sales_Teams.Site = 'C3' THEN 'C3'
		ELSE '' END) AS Room,
		dbo.tbl_DBF_Cust.Contact_Number, 
		dbo.tbl_DBF_CMS.Order_Total,
		dbo.tbl_Sales_Teams.Name,
		dbo.tbl_DBF_Cust.Contact_Number2
		FROM         dbo.tbl_DBF_CMS 
		INNER JOIN dbo.tbl_DBF_Cust 
		ON dbo.tbl_DBF_CMS.Cust_ID = dbo.tbl_DBF_Cust.Cust_ID 
		INNER JOIN dbo.tbl_Sales_Teams 
		ON dbo.tbl_DBF_CMS.Sales_ID = dbo.tbl_Sales_Teams.Login
		WHERE     (dbo.tbl_DBF_CMS.Order_Date >= dbo.Get_TheDate(GETDATE()) - 3) 
		AND (dbo.tbl_DBF_CMS.Ttl_Billed_Merch = 0) 
		AND (dbo.tbl_DBF_CMS.Order_Total > 1000)
		AND (".$SQL_Room.")
		AND (dbo.tbl_DBF_CMS.Order_ID NOT IN (Select Order_ID From tbl_Survey))
		ORDER BY dbo.tbl_DBF_CMS.Order_Total DESC
		";

	$query_Good_Money="
		SELECT     TOP (100) PERCENT 
		CONVERT(CHAR(10), dbo.tbl_DBF_CMS.Order_Date, 110) AS Order_Date, 
		dbo.tbl_DBF_CMS.Order_ID, 
		dbo.tbl_DBF_CMS.Cust_ID, 
		dbo.tbl_DBF_Cust.First_Name, 
		dbo.tbl_DBF_Cust.Last_Name, 
		dbo.tbl_DBF_CMS.Sales_ID, 
		(CASE 
		WHEN dbo.tbl_Sales_Teams.Site = 'Austin' THEN 'AU'
		WHEN dbo.tbl_Sales_Teams.Site = 'Beaumont' THEN 'BM'
		WHEN dbo.tbl_Sales_Teams.Site = 'C3' THEN 'C3'
		ELSE '' END) AS Room,
		dbo.tbl_DBF_Cust.Contact_Number, 
		dbo.tbl_DBF_CMS.Ttl_Billed_Merch,
		dbo.tbl_Sales_Teams.Name,
		dbo.tbl_DBF_Cust.Contact_Number2
		FROM         dbo.tbl_DBF_CMS 
		INNER JOIN dbo.tbl_DBF_Cust 
		ON dbo.tbl_DBF_CMS.Cust_ID = dbo.tbl_DBF_Cust.Cust_ID 
		INNER JOIN dbo.tbl_Sales_Teams 
		ON dbo.tbl_DBF_CMS.Sales_ID = dbo.tbl_Sales_Teams.Login
		WHERE     (dbo.tbl_DBF_CMS.Order_Date >= dbo.Get_TheDate(GETDATE()) - 3) 
		AND (dbo.tbl_DBF_CMS.Order_ID IN
		                          (SELECT     Order_ID
		                            FROM          dbo.vw_Sales_Orders_Pending)) 
		AND (dbo.tbl_DBF_CMS.Ttl_Billed_Merch >= 1000)
		AND (".$SQL_Room.")
		AND (dbo.tbl_DBF_CMS.Order_ID NOT IN (Select Order_ID From tbl_Survey))
		ORDER BY dbo.tbl_DBF_CMS.Ttl_Billed_Merch DESC
		";

	
	if ($in_Category=='Good Money'){
		$query= $query_Good_Money;
	}

	if ($in_Category=='AMEX'){
		$query= $query_AMEX;
	}
	
	if ($in_Category=='Pending'){
		$query= $query_Pending;
	}

	$result=mssql_query($query, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Asset_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$textout[0][$i]=mssql_result($result, $i, 0);//Order_Date
		$textout[1][$i]=mssql_result($result, $i, 1);//Order_ID
		$textout[2][$i]=mssql_result($result, $i, 2);//Cust_ID
		$textout[3][$i]=mssql_result($result, $i, 3);//First_Name
		$textout[4][$i]=mssql_result($result, $i, 4);//Last_Name
		$textout[5][$i]=mssql_result($result, $i, 5);//Sales_Rep
		$textout[6][$i]=mssql_result($result, $i, 6);//Room
		$textout[7][$i]=mssql_result($result, $i, 7);//Contact_Number
		$textout[8][$i]=mssql_result($result, $i, 8);//Order_Value
		$textout[9][$i]=mssql_result($result, $i, 9);//Sales_Rep
		$textout[10][$i]=mssql_result($result, $i, 10);//Alternate_Number
		
	}
	Return $textout;
}

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" bgcolor="');
	global $tbl_bgcolor;
	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}


?>

<html>
<title>USRCBR Customer Service Quality Assurance</title>
<head>

<script type="text/javascript">
	function show_asset(Index_ID){
	<!--
	str_redirect='./Survey_Add.php?$orig_index='+Index_ID
	window.open (str_redirect, 'Asset_Window_'+Index_ID, config='height=800, width=800, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}

	function show_new_survey(){
	<!--
	str_redirect2='./Survey_Add_New.php'
	window.open (str_redirect2, 'Asset_Window_', config='height=800, width=800, toolbar=yes, menubar=yes, scrollbars=yes, resizable=yes, location=yes, directories=yes, status=yes')
	-->
	}
</script>

<script src="JS_Sort_Table.js"></script>

</head>
	
<body>
<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_SESSION['$in_category']='';
	$_SESSION['$in_room']='';
	$_POST["in_Category"]='';
	$_POST["in_Room"]='';
	$_POST["in_Surveyor"]='';
}


If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}

		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";
	};

if ($_POST["in_Category"]==''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
		<h2 align=center>Customer Service: Surveyable Call List</h2>

		<table align="center">
		<form action="./Survey_Report.php" >
		<input type="submit" value="Reporting">
		</form>
		</table>

		<table align="center">
		<tr onClick="show_new_survey()" >
		<input type="submit" value="Blank Survey">
		</tr>
		</table>

		<table align="center">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" method="POST">
		<tr>

		<td valign="top" align="center">
		<label>1) Surveyor: <br>
		<select name="in_Surveyor">
		<option>'.$_POST["in_Surveyor"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="LB">LB</option>
		<option value="SK">SK</option>
		<option value="CM">CM</option>
		<option value="TN">TN</option>
		</td>

		<td valign="top" align="center">
		<label>2) Category: <br>
		<select name="in_Category" onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option>AMEX</option>
		<option>Good Money</option>
		<option>Pending</option>
		</td>

		<td valign="top" align="center">
		<label>3) Room: <br>
		<select name="in_Room" onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="All Rooms">All Rooms</option>
		<option value="Austin">Austin</option>
		<option value="Beaumont">Beaumont</option>
		<option value="C3">C3</option>
		</td>
		<td valign="top" align="left"><br>
		<input type="submit" name="Clear" value=" Clear All " />
		</td>


		</tr>
		<tr></tr>
		</form>
		</table>
	
		<table align="center" class="sortable">
		<tr>');
	format_tbl_header("Index", 50, left);
	format_tbl_header("Order Date", 125, center);
	format_tbl_header("Order ID", 125, center);
	format_tbl_header("Customer ID", 150, center);
	format_tbl_header("First Name", 150, center);
	format_tbl_header("Last Name", 150, center);
	format_tbl_header("Sales Rep", 150, center);
	format_tbl_header("Room", 50, center);
	format_tbl_header("Contact Number", 150, center);
	format_tbl_header("Order Value", 150, center);
	echo ('</tr></table>');

	$_SESSION['$in_category']=$_POST["in_Category"];
	$_SESSION['$in_room']=$_POST["in_Room"];
	$_SESSION['$in_surveyor']=$_POST["in_Surveyor"];

}//	if ($_POST["in_Category"]=='' AND $_POST["in_Room"]=='')
else {
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
		<h2 align=center>Customer Service: Surveyable Call List</h2>

		<table align="center">
		<form action="./Survey_Report.php" >
		<input type="submit" value="Reporting">
		</form>
		</table>

		<table align="center">
		<tr onClick="show_new_survey()" >
		<input type="submit" value="Blank Survey">
		</tr>
		</table>

		<table align="center">
		<form action="'.$php_page.'"  onSubmit="'.$php_page.'" method="POST">
		<tr>

		<td valign="top" align="center">
		<label>1) Surveyor: <br>
		<select name="in_Surveyor">
		<option>'.$_POST["in_Surveyor"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="ALL">ALL</option>
		<option value="LB">LB</option>
		<option value="SK">SK</option>
		<option value="CM">CM</option>
		<option value="TN">TN</option>
		</td>
		
		<td valign="top" align="center">
		<label>2) Category: <br>
		<select name="in_Category" onChange="submit()">
		<option>'.$_POST["in_Category"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option>AMEX</option>
		<option>Good Money</option>
		<option>Pending</option>

		</td>
		<td valign="top" align="center">
		<label>3) Room: <br>
		<select name="in_Room" onChange="submit()">
		<option>'.$_POST["in_Room"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="All Rooms">All Rooms</option>
		<option value="Austin">Austin</option>
		<option value="Beaumont">Beaumont</option>
		<option value="C3">C3</option>
		</td>
		<td valign="top" align="left"><br>
		<input type="submit" name="Clear" value=" Clear All " />
		</td></tr>
		<tr></tr>
		</form>
		</table>
	
		<table align="center" class="sortable">
		<tr>');
	format_tbl_header("Index", 50, left);
	format_tbl_header("Order Date", 125, center);
	format_tbl_header("Order ID", 125, center);
	format_tbl_header("Customer ID", 150, center);
	format_tbl_header("First Name", 150, center);
	format_tbl_header("Last Name", 150, center);
	format_tbl_header("Sales Rep", 150, center);
	format_tbl_header("Room", 50, center);
	format_tbl_header("Contact Number", 150, center);
	format_tbl_header("Order Value", 150, center);
	echo ('</tr>');

	$_SESSION['$in_category']=$_POST["in_Category"];
	$_SESSION['$in_room']=$_POST["in_Room"];
	$_SESSION['$in_surveyor']=$_POST["in_Surveyor"];
};




	$asset_list=get_list($DB_Conn, $_POST["in_Category"], $_POST["in_Room"]);
	$_SESSION['Asset_List']=$asset_list;

	for ($i=0; $i<$_SESSION['Asset_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}



	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_asset('.($asset_list[0][$i]).')">');
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index
	format_tbl_content($asset_list[0][$i], 125, center, $row_bgcolor);	//Order_Date
	
	format_tbl_content($asset_list[1][$i], 125, center, $row_bgcolor);	//Order_ID
	
	format_tbl_content($asset_list[2][$i], 150, center, $row_bgcolor);	//Cust_ID
	format_tbl_content($asset_list[3][$i], 150, left, $row_bgcolor);	//First_Name
	format_tbl_content($asset_list[4][$i], 150, left, $row_bgcolor);	//Last_Name
	format_tbl_content($asset_list[5][$i], 150, center, $row_bgcolor);	//Sales_Rep
	format_tbl_content($asset_list[6][$i],  50, center, $row_bgcolor);	//Room
	format_tbl_content($asset_list[7][$i], 150, center, $row_bgcolor);	//Contact_Number
	echo ('<td align="right" bgcolor='.$row_bgcolor.'>$ '.number_format($asset_list[8][$i], 2).'</td>');//Order_Value
	echo ('</tr>');
	}

	echo ('	</table>');


	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}


		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";
	};
	
	//}; //	if ($_POST["in_Category"]=='') AND ($_POST["in_Room"]=='')

	 

?>
</body>
</html>
