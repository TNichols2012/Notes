<?php
session_start();

require_once ('DB_Login.php');

$debug=0;

$DB_Conn = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); 
mssql_select_db ( $DB2_Database, $DB_Conn );

$contact_phone	= $_GET['$orig_index'];

$orig_inventory='';

If ($debug==1) {	
	if (! $DB_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database. <br />";}

	echo ('<br>GET index: '.$_GET['$orig_index']);	
	echo ('<br>DB Host: '.$DB2_Host);	
	echo ('<br>DB Used: '.$DB2_Database);	
	echo ('<br>DB User: '.$DB2_UserName);	
	echo ('<br>Surveyor Session: <b>'.$_SESSION['$in_surveyor'].'</b>');
	echo ('<br>**************************************************************************************');

};


define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$tbl_bgcolor="Yellow";

function get_list ($DB_Conn, $in_contact_phone, $debug){


	if ($in_Room=='' OR $in_Room =='All Rooms'){
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" dbo.tbl_Sales_Teams.Site ='".$in_Room."'";
	}

	$query_call_history="
		SELECT     
		Contact_Number, 
		Call_Start_Time, 
		Call_Disposition, 
		Sales_Rep, 
		Call_Seconds, 
		MP3_File_Name_2, 
		RIGHT(MP3_File_Name_2, 37) AS File_Name
		FROM	tbl_Survey_Calls
		WHERE	Contact_Number='".$in_contact_phone."'
		ORDER BY Call_Start_Time DESC
		";

	$result=mssql_query($query_call_history, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['List_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$textout[0][$i]=mssql_result($result, $i, 0);//Contact Number
		$textout[1][$i]=mssql_result($result, $i, 1);//Call_Start_Time
		$textout[2][$i]=mssql_result($result, $i, 2);//Call_Disposition
		$textout[3][$i]=mssql_result($result, $i, 3);//Sales_Rep
		$textout[4][$i]=mssql_result($result, $i, 4);//Call_Seconds
		$textout[5][$i]=mssql_result($result, $i, 5);//New_File_Name
		$textout[6][$i]=mssql_result($result, $i, 6);//File_Name
	}


	if ($debug==1){
		echo ('<br>in Function get_list');
		echo ('<br>Database connection is: '.$DB_Conn);
		echo ('<br>Query call histoy: '.$query_call_history);
		echo ('<br>result is: '.$result);
		echo ('<br>List count is: '.$_SESSION['List_Count']);
		echo ('<br>Numrows is: '.$numrows);
		//echo ('<br>result is: '.$result);


	}


	Return $textout;
}


function Survey_Call_Lookup ($DB_Conn, $in_contact_phone, $debug)
	{
        $sp = mssql_init ( 'usp_Survey_Call_Lookup', $DB_Conn ); //init stored procedure  
	mssql_bind ( $sp, '@in_contact_phone', $in_contact_phone, SQLVARCHAR, false,false,3);

	mssql_execute ( $sp );


	return; 
} 

function format_tbl_Header ($in_label, $in_alignment, $in_width){
	echo ('<td valign="top" bgcolor="FFFF00" align="'.$in_alignment.'" width="'.$in_width.'"><b>'.$in_label.'</b></td>');

}

function format_tbl_content ($in_content, $in_alignment, $in_width, $in_row_bgcolor){
	echo ('<td align="'.$in_alignment.'" bgcolor="'.$in_row_bgcolor.'" width="'.$in_width.'">'.$in_content.'</td>');
}



?>

<html>
<title>USRCBR Customer Service Quality Assurance</title>

<body>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);


if($orig_inventory == 'Close')
{
?>
<script language=JavaScript>
window.close();
</script>
<?php
}


//'4404883985'
//<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
//
//$contact_phone
//
//$_SESSION['List_Count']
//$orig_inventory==''
//

$call_list= get_list($DB_Conn, $contact_phone, $debug);

if($_SESSION['List_Count']>=1){

echo ('	<h2 align=center>Quality Assurance: Call History Lookup</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>
	<br>Recorded Calls for: <b>'.$contact_phone.'</b><br>


	
	<form action="./Survey_Phone.php?$orig_index='.$orig_index.'" method="POST">


	<table align=center><tr>');

	format_tbl_header('Call Start Time', center, 150);
	format_tbl_header('Call Disposition', center, 150);
	format_tbl_header('Sales Rep', center, 250);
	format_tbl_header('Talk Time<br></b><small><i>(seconds)</i><b></small>', center,25);
	format_tbl_header('File Name', center, 250);
	format_tbl_header('Recording', center, 250);

echo ('</tr>');	


	for($i=0;$i<$_SESSION['List_Count'];$i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}

		echo ('<tr>');
		format_tbl_content($call_list[1][$i], center, 150, $row_bgcolor); //Call_Start_Time
		format_tbl_content($call_list[2][$i], center, 150, $row_bgcolor); //Call_Disposition
		format_tbl_content($call_list[3][$i], center, 250, $row_bgcolor); //Sales_Rep
		format_tbl_content($call_list[4][$i], center, 25, $row_bgcolor); //Talk_Time

		//echo ('<td><A href="mms:\\'.$call_list[5][$i].'" title="go to call" target="">'.$call_list[6][$i].'</A></td>');
		echo ('<td bgcolor="'.$row_bgcolor.'" align="center"><small>'.$call_list[6][$i].'</small></td>');//File Name

		//Windows 7, 9, 10, 11: 	classid="CLSID:6BF52A52-394A-11D3-B153-00C04F79FAA6"
		//Windows Media Player 6.4:	classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95"
		if (file_exists($call_list[5][$i])){

		//echo ('<td>'.$call_list[5][$i].'</td>');
		echo ('<td><A bgcolor="'.$row_bgcolor.'" href="file:///'.$call_list[5][$i].'" title="go to call" target="_blank">'.$call_list[6][$i].'</A></td>');
		
			//echo ('	<td><OBJECT ID="MediaPlayer'.$call_list[6][$i].'" 
			//		CLASSID="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" 
			//		CODEBASE="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701"
			//		width=300 height=45
			//		STANDBY="Loading Microsoft Windows Media Player components..." 
			//		TYPE="application/x-oleobject">
			//		<PARAM NAME="FileName"			VALUE="'.$call_list[5][$i].'">
			//		<PARAM NAME="TransparentAtStart"	Value="false">
			//		<PARAM NAME="AutoStart"			Value="false">
			//		<PARAM NAME="ClickToPlay"		Value="false">
			//		<PARAM NAME="AnimationatStart"		Value="false">
			//		<PARAM NAME="ShowControls"		Value="true">
			//		<PARAM NAME="ShowTracker"		Value="true">
			//		<PARAM NAME="ShowPositionControls"	Value="true">
			//		<PARAM NAME="autoSize"			Value="false">
			//		<PARAM NAME="DisplaySize"		Value="1">
			//		<PARAM NAME="CurrentPosition"		Value="true">
			//		<PARAM NAME="CurrentMarker" 		Value="true">
			//		<PARAM NAME="uiMode"			Value="full">
			//		<PARAM NAME="EnablePositionControls"	Value="true"> 
			//		<PARAM NAME="EnableFullScreenControls"	Value="true"> 
			//		<PARAM NAME="EnableTracker"		Value="true">
			//		<Embed type="application/x-mplayer2" 
			//			pluginspage="http://www.microsoft.com/Windows/MediaPlayer/"
			//			src="\\Usrc_fileserver\Amcat_Recordings\"
			//			Name=MediaPlayer'.$call_list[6][$i].'"
  			//			TransparentAtStart=0
			//			AutoStart=0
			//			ClickToPlay=0
			//			animationAtStart=0
			//			ShowControls=1
			//			ShowTracker=1
			//			ShowPositionControls=1
			//			AutoSize=0
			//			DisplaySize=0
			//			CurrentPosition=1
			//			CurrentMarker=1
			//			uiMode="Full"
			//			EnablePositionControls=1
			//			EnableFullScreenControls=1
			//			EnableTracker=1
			//			Width=300 Height=45>
  			//		</embed>
			//</OBJECT></td>');
		 
		}
		else {
			echo ('<td align=center bgcolor="'.$row_bgcolor.'">Recording Not Found</td>');

		}


		echo ('</tr>');
		
	}



echo ('</table></form><br>');

} // end if($inve_asset_tag==='')
else {

	echo ('	<h2 align=center>Quality Assurance: Call History Lookup</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>
	<br>Recorded Calls for: <b>'.$contact_phone.'</b><br>
	<br><b>No recordings found.</b>');
}

	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine. <br> First Pass. <br>";}


		echo "<br>calllist: '<b>".$call_list."</b>'<br>";
		echo "<br>calllist 1 0 : '<b>".$call_list[1][$i]."</b>'<br>";

	};

 


?>
</body>
</html>
