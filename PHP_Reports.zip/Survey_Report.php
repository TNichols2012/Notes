<?php
session_start();

require_once ('DB_Login.php');
require_once ('PHP_Functions.php');

$debug=0;

$DB_Conn = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); 
mssql_select_db ( $DB2_Database, $DB_Conn );

If ($debug==2) {	
	IF (! $DB_Conn) {
		DIE ("Debug Mode: ON <br>
			Could not connect to New Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Debug Mode: ON <br> Successfully connected to database. <br />";}
};

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");

$tbl_bgcolor="Yellow";

$_SESSION['List_Count']= 0;
$_SESSION['$sum_Surveys']= 0;
$_SESSION['$avg_Surveys']= 0;



function get_sales_rep ($DB_Conn, $in_Room, $debug){

	if ($in_Room=='' OR $in_Room =='All Rooms'){
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" vSR.Site ='".$in_Room."'";
	}

	
	$query_Sales_Rep= " 
		SELECT
		vSR.[Name]
		FROM dbo.vw_Survey_Review vSR
		WHERE vSR.Sales_ID <>'XXX'
		AND ".$SQL_Room."
		GROUP BY vSR.[Name]
		ORDER BY vSR.[Name]
		";

	$result=mssql_query($query_Sales_Rep, $DB_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Sales_Rep_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$textout[0][$i]=mssql_result($result, $i, 0);//Name
		
	}
	
	if ($debug==2) {
		if (! $DB_Conn) {
			die ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		else {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}

		echo "fct get sales rep POST in Room : '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "fct get sales rep in Room: '<b>".$in_Room."</b>'<br>";
		echo "fct get sales rep query: '<b>".$query_Sales_Rep."</b>'<br>";
		echo "fct get sales rep num rows: '<b>".$numrows."</b>'<br>";		


	}; // if ($debug==1)

	Return $textout;

} // function get_sales_rep

function get_list ($DB_Conn, $in_Room, $in_Sales_Rep, $in_Surveyor, $in_Start_Date, $in_Stop_Date, $debug){


	//	echo "<script>alert(\"Valid Date Entered.\");</script>";
	//
	if ($in_Start_Date==''){$SQL_Start_Date=" 1=1 ";}
	elseif (isDate($in_Start_Date)){$SQL_Start_Date=" vSR.Order_Date >='".$in_Start_Date."'";}
	else { echo "<script>alert(\"Invalid Start Date. Please re-enter.\");</script>";}

	if ($in_Stop_Date==''){$SQL_Stop_Date=" 1=1 ";}
	elseif (isDate($in_Stop_Date)){$SQL_Stop_Date=" vSR.Order_Date <='".$in_Stop_Date."'";}
	else { echo "<script>alert(\"Invalid Stop Date. Please re-enter.\");</script>";}

	if ($in_Sales_Rep =='All Sales Reps'){$SQL_Sales_Rep=" 1=1 ";}
	else {$SQL_Sales_Rep=" vSR.[Name] ='".$in_Sales_Rep."'";}

	if ($in_Room =='All Rooms'){$SQL_Room=" 1=1 ";}
	else {$SQL_Room=" vSR.Site ='".$in_Room."'";}

	if ($in_Surveyor =='All'){$SQL_Surveyor=" 1=1 ";}
	else {$SQL_Surveyor=" vSR.Surveyor ='".$in_Surveyor."'";}
	
	//OR $in_Surveyor ==''/

	$query_Survey_Review= " 
		SELECT
		vSR.[Name],
		vSR.Sales_ID,
		vSR.Order_ID,
		CONVERT(char(10), vSR.Order_Date, 110) AS Order_Date,
		vSR.Email_Requested,
		vSR.Gold_Owner,
		vSR.Collector_Type,
		vSR.Other_Companies,
		vSR.Specialist_Name,
		vSR.Level_One,
		vSR.Level_Two,
		vSR.Level_Three,
		vSR.Survey_Rating,
		vSR.Surveyor,
		CONVERT(text, vSR.Survey_Memo) AS Survey_Memo,
		vSR.Cust_ID,
		vSR.First_Name,
		vSR.Last_Name,
		vSR.Contact_Number1,
		vSR.Alternate_Number,
		vSR.Ttl_Billed_Merch,
		vSR.Survey_Minutes,
		CONVERT(char(10), vSR.Survey_Date, 110) AS Survey_Date
		FROM dbo.vw_Survey_Review vSR
		WHERE vSR.Sales_ID <>'XXX'
		AND ".$SQL_Room."
		AND ".$SQL_Sales_Rep."
		AND ".$SQL_Surveyor."
		AND ".$SQL_Start_Date."
		AND ".$SQL_Stop_Date."
		ORDER BY vSR.Survey_Date DESC
		";

	$query_Survey_Sum= " 
		SELECT
		SUM(vSR.Survey_Rating) AS Survey_Sum
		FROM dbo.vw_Survey_Review vSR
		WHERE vSR.Sales_ID <>'XXX'
		AND ".$SQL_Room."
		AND ".$SQL_Sales_Rep."
		AND ".$SQL_Surveyor."
		AND ".$SQL_Start_Date."
		AND ".$SQL_Stop_Date."
		";

	$result1=mssql_query($query_Survey_Review, $DB_Conn);
	$result2=mssql_query($query_Survey_Sum, $DB_Conn);

	$numrows1=mssql_num_rows($result1);
	$_SESSION['List_Count']= intval($numrows1);
	$textout2[0][0]= mssql_result($result2, 0, 0);//Survey Sum


	$_SESSION['$sum_Surveys']= intval($textout2[0][0]);
	$_SESSION['$avg_Surveys']= ($_SESSION['$sum_Surveys']) / ($_SESSION['List_Count']);

	for($i=0.0;$i<$numrows1;$i+=1.0){
		$textout[0][$i]=mssql_result($result1, $i, 0);//Name
		$textout[1][$i]=mssql_result($result1, $i, 1);//Sales_ID
		$textout[2][$i]=mssql_result($result1, $i, 2);//Order_ID
		$textout[3][$i]=mssql_result($result1, $i, 3);//Order_Date
		$textout[4][$i]=mssql_result($result1, $i, 4);//Email Requested
		$textout[5][$i]=mssql_result($result1, $i, 5);//Gold Owner
		$textout[6][$i]=mssql_result($result1, $i, 6);//Collector Type
		$textout[7][$i]=mssql_result($result1, $i, 7);//Other Companies
		$textout[8][$i]=mssql_result($result1, $i, 8);//Specialist Name
		$textout[9][$i]=mssql_result($result1, $i, 9);//Level 1
		$textout[10][$i]=mssql_result($result1, $i, 10);//Level 2 
		$textout[11][$i]=mssql_result($result1, $i, 11);//Level 3
		$textout[12][$i]=mssql_result($result1, $i, 12);//Survey Rating
		$textout[13][$i]=mssql_result($result1, $i, 13);//Surveyor
		$textout[14][$i]=mssql_result($result1, $i, 14);//Survey Suggestion
		$textout[15][$i]=mssql_result($result1, $i, 15);//Cust_ID
		$textout[16][$i]=mssql_result($result1, $i, 16);//First_Name
		$textout[17][$i]=mssql_result($result1, $i, 17);//Last_Name
		$textout[18][$i]=mssql_result($result1, $i, 18);//Contact_Number
		$textout[19][$i]=mssql_result($result1, $i, 19);//Alternate_Number
		$textout[20][$i]=mssql_result($result1, $i, 20);//Ttl_Billed_Merch
		$textout[21][$i]=mssql_result($result1, $i, 21);//Survey Minute
		$textout[22][$i]=mssql_result($result1, $i, 22);//Survey Date

		//$_SESSION['$sum_Surveys']=$_SESSION['$sum_Surveys'] + number_format($asset_list[12][$i], 2);	
	}

	if ($debug==1) {
		if (! $DB_Conn) {
			die ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		else {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}

		echo "<br></br>";
		echo "Session Survey Sum : '<b>".$_SESSION['$sum_Surveys']."</b>'<br>";
		echo "Session List Count : '<b>".$_SESSION['List_Count']."</b>'<br>";
		echo "Session Sum: '<b>".$_SESSION['List_Count'] * $_SESSION['$sum_Surveys']."</b>'<br>";
		echo "Session Avg: '<b>".$_SESSION['$sum_Surveys'] / $_SESSION['List_Count']."</b>'<br>";


		echo "Session Survey Query : '<b>".$query_Survey_Sum."</b>'<br>";
		echo "Session Survey Query Review: '<b>".$query_Survey_Review."</b>'<br>";

		echo "Session result2 : '<b>".$result2."</b>'<br>";
		echo "Session textout2 [0][0] : '<b>".$textout2[0][0]."</b>'<br>";
		echo "Session S Count : '<b>".$_SESSION['List_Count']."</b>'<br>";

	
	}; // if ($debug==1)


	Return $textout;
} // function get_list

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" valign="bottom" bgcolor="');
	global $tbl_bgcolor;
	echo $tbl_bgcolor.'"';

	if ($width !=-1){echo (' width="'.$width.'"><b>'.$label.'</b></td>');}
	else {echo ('><b>'.$label.'</b></td>');}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){
	echo ('<td align="'.$alignment.'" bgcolor="');
	echo $row_bgcolor.'"';

	if ($width !=-1){echo (' width="'.$width.'">'.$content.'</td>');}
	else {echo ('>'.$content.'</td>');}
}


?>

<html>
<title>USRCBR Customer Service Quality Assurance</title>
<head>

<script type="text/javascript">
	function show_asset(Index_ID){
	<!--
	str_redirect='./Survey_Update.php?$orig_index='+Index_ID
	window.open (str_redirect, 'Asset_Window_'+Index_ID, config='height=900, width=800, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}
</script>

<script src="JS_Sort_Table.js"></script>

</head>
	
<body>
<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_SESSION['$in_room']='';
	$_SESSION['$in_sales_rep']='';
	$_SESSION['$in_surveyor']='';
	$_SESSION['$in_Start_Date']='';
	$_SESSION['$in_Stop_Date']='';

	$_SESSION['List_Count']=0;
	$_SESSION['$sum_Surveys']= 0;
	$_SESSION['$avg_Surveys']= 0;

	$_POST["in_Room"]='';
	$_POST["in_Sales_Rep"]='';
	$_POST["in_Surveyor"]='';
	$_POST["in_Start_Date"]='';
	$_POST["in_Stop_Date"]='';
}


if ($debug==2) {
		if (! $DB_Conn) {
			die ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		else {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}

		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "POST Sales ID: '<b>".$_POST["in_Sales_ID"]."</b>'<br>";		
		echo "POST Start Time: '<b>".$_POST["in_Start"]."</b>'<br>";
		echo "POST Stop Time: '<b>".$_POST["in_Stop"]."</b>'<br>";
	};

if ($_POST["in_Room"]==''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
		<h2 align=center>Customer Service: Survey Reports</h2>


		<table align="center">
		<form action="./Survey_List.php" >
		<input type="submit" value="Survey List">
		</form>
		</table>

		<table align="center">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" method="POST">
		<tr>

		<td valign="top" align="center">
		<label>1) Room: <br>
		<select name="in_Room" onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="All Rooms">All Rooms</option>
		<option value="Austin">Austin</option>
		<option value="Beaumont">Beaumont</option>
		<option value="C3">C3</option>
		</td>

		<td valign="top" align="center">
		<label>2) Sales Rep: <br>
		<select name="in_Sales_Rep" value="'.$_POST["in_Sales_Rep"].'" onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		</td>

		<td valign="top" align="center">
		<label>3) Surveyor: <br>
		<select name="in_Surveyor" value="'.$_POST["in_Surveyor"].'"onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="All">All</option>
		<option value="PLV">PLV</option>
		<option value="LB">LB</option>
		<option value="SK">SK</option>
		</td>


		<td align="center" valign="top">
		<label>Start Date:<i><small> ( 01/01/2008 ) </i></small><br>
		<input type="text" style="text-align:center" name="in_Start_Date" value="'.$_POST["in_Start_Date"].'" align="center" onChange="submit()"/>
		</td>

		<td align="center" valign="top">
		<label>Stop Date:<i><small> ( Today )</small></i><br>
		<input type="text" style="text-align:center" name="in_Stop_Date" value="'.$_POST["in_Stop_Date"].'" align="center" onChange="submit()"/>
		</td>

		<td valign="top" align="left"><br>
		<input type="submit" name="Clear" value="Clear All" />
		</td>

		<td valign="top" align="left"><br>
		<input type="submit" name="Refresh" value="Refresh" />
		</td></tr>

		<tr><td></td><td></td><td></td><td colspan=2 align="center"><i>(MM/DD/YYYY)</i></td></tr>
		
		</form>
		</table>');
	
	echo ('	<h3 align="center">'.number_format($_SESSION['List_Count'], 0).' Surveys, Average Survey Rating: '.number_format($_SESSION['$avg_Surveys'], 2).'
		</h3>');

	echo ('	<table align="center" class="sortable">
		<tr>');
		format_tbl_header("Index", 50, left);			//	1
		format_tbl_header("Sales Rep Name", 200, center);	//	2
		format_tbl_header("Order ID", 100, center);		//	3
		format_tbl_header("Order Date", 90, center);		//	4
		format_tbl_header("Email?", 30, center);		//	5
		format_tbl_header("Gold?", 30, center);			//	6
		format_tbl_header("Level<br>I", 30, center);		//	7
		format_tbl_header("Level<br>II", 30, center);		//	8
		format_tbl_header("Level<br>III", 30, center);		//	9
		format_tbl_header("Survey<br>Rating", 50, center);	//	10
		format_tbl_header("Order<br>Value", 100, center);	//	10
		format_tbl_header("Surveyor", 10, center);		//	11
		format_tbl_header("Survey Minutes", 10, center);	//	12
		format_tbl_header("Survey Date", 90, center);		//	13


	echo ('</tr></table>');

	$_SESSION['$in_room']=$_POST["in_Room"];
	$_SESSION['$in_sales_rep']=$_POST["in_Sales_Rep"];
	$_SESSION['$in_surveyor']=$_POST["in_Surveyor"];


}//	if ($_POST["in_Room"]=='')
else { 
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
		<h2 align=center>Customer Service: Survey Reports</h2>');

	$_SESSION['$in_room']=$_POST["in_Room"];
	$_SESSION['$in_sales_rep']=$_POST["in_Sales_Rep"];
	$_SESSION['$in_surveyor']=$_POST["in_Surveyor"];

	$sales_reps=get_sales_rep($DB_Conn, $_POST["in_Room"], $debug);

	$asset_list=get_list($DB_Conn, $_POST["in_Room"], $_POST["in_Sales_Rep"], $_POST["in_Surveyor"], $_POST["in_Start_Date"], $_POST["in_Stop_Date"], $debug);

	$_SESSION['Report_List']=$asset_list;

	echo ('	<table align="center">
		<form action="./Survey_List.php" >
		<input type="submit" value="Survey List">
		</form>
		</table>

		<table align="center">
		<form action="'.$php_page.'"  onSubmit="'.$php_page.'" method="POST">
		<tr>

		<td valign="top" align="center">
		<label>1) Room: <br>
		<select name="in_Room" onChange="submit()">
		<option>'.$_POST["in_Room"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="All Rooms">All Rooms</option>
		<option value="Austin">Austin</option>
		<option value="Beaumont">Beaumont</option>
		<option value="C3">C3</option>
		</td>

		<td valign="top" align="center">
		<label>2) Sales Rep: <br>
		<select name="in_Sales_Rep" onChange="submit()">
		<option>'.$_POST["in_Sales_Rep"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>
		<option value="All Sales Reps">All Sales Reps</option>');	

		for($i=0;$i<$_SESSION['Sales_Rep_Count'];$i+=1){
			echo ('<option value="'.$sales_reps[0][$i].'">'.$sales_reps[0][$i].'</option>  ');
		}
	
		echo ('</td>

		<td valign="top" align="center">
		<label>3) Surveyor: <br>
		<select name="in_Surveyor" onChange="submit()">
		<option>'.$_POST["in_Surveyor"].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>	
		<option value="All">All</option>
		<option value="PLV">PLV</option>
		<option value="LB">LB</option>
		<option value="SK">SK</option>
		</td>

		<td align="center" valign="top">
		<label>Start Date:<i><small> ( 01/01/2008 ) </i></small><br>
		<input type="text" style="text-align:center" name="in_Start_Date" value="'.$_POST["in_Start_Date"].'" align="center" onChange="submit()"/>
		</td>

		<td align="center" valign="top">
		<label>Stop Date:<i><small> ( Today )</small></i><br>
		<input type="text" style="text-align:center" name="in_Stop_Date" value="'.$_POST["in_Stop_Date"].'" align="center" onChange="submit()"/>
		</td>

		<td valign="top" align="left"><br>
		<input type="submit" name="Clear" value="Clear All" />
		</td>

		<td valign="top" align="left"><br>
		<input type="submit" name="Refresh" value="Refresh" />
		</td></tr>

		<tr><td></td><td></td><td></td><td colspan=2 align="center"><i>(MM/DD/YYYY)</i></td></tr>
		</tr>
		</form>
		</table>');

	echo ('	<h3 align="center">
		'.number_format($_SESSION['List_Count'], 0).' Surveys, 
		Average Survey Rating: '.number_format($_SESSION['$avg_Surveys'], 2).'
		</h3>');

	echo ('	<table class="sortable" align="center">
		<tr>');
		format_tbl_header("Index", 50, left);			//	1
		format_tbl_header("Sales Rep Name", 200, center);	//	2
		format_tbl_header("Order ID", 100, center);		//	3
		format_tbl_header("Order Date", 90, center);		//	4
		format_tbl_header("Email?", 30, center);		//	5
		format_tbl_header("Gold?", 30, center);			//	6
		format_tbl_header("Level<br>I", 30, center);		//	7	
		format_tbl_header("Level<br>II", 30, center);		//	8
		format_tbl_header("Level<br>III", 30, center);		//	9
		format_tbl_header("Survey<br>Rating", 50, center);	//	10
		format_tbl_header("Order<br>Value", 100, center);	//	10
		format_tbl_header("Surveyor", 10, center);		//	11
		format_tbl_header("Survey<br>Minutes", 10, center);	//	12
		format_tbl_header("Survey<br>Date", 90, center);		//	13

	echo ('</tr>');


	for ($i=0; $i<$_SESSION['List_Count']; $i+=1){
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}

	echo ('<tr onClick="show_asset('.($i).')">');
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index
	format_tbl_content($asset_list[0][$i], 200, left, $row_bgcolor);	//Name
	format_tbl_content($asset_list[2][$i], 100, center, $row_bgcolor);	//Order_ID
	format_tbl_content($asset_list[3][$i], 90, center, $row_bgcolor);	//Order_Date

	format_tbl_content($asset_list[4][$i], 30, left, $row_bgcolor);		//Email
	format_tbl_content($asset_list[5][$i], 30, left, $row_bgcolor);		//Gold

	if($asset_list[9][$i]<>''){
		format_tbl_content("Yes", 30, center, $row_bgcolor);		//Level I
	}
	else {
		format_tbl_content("No", 30, center, $row_bgcolor);		//Level I
	}

	if($asset_list[10][$i]<>''){
		format_tbl_content("Yes", 30, center, $row_bgcolor);		//Level II
	}
	else {
		format_tbl_content("No", 30, center, $row_bgcolor);		//Level II
	}

	if($asset_list[11][$i]<>''){
		format_tbl_content("Yes", 30, center, $row_bgcolor);		//Level III
	}
	else {
		format_tbl_content("No", 30, center, $row_bgcolor);		//Level III
	}

	echo ('<td align="right" bgcolor='.$row_bgcolor.'>'.number_format($asset_list[12][$i], 0).'</td>');//Survey Rating
	echo ('<td align="right" bgcolor='.$row_bgcolor.'>$ '.number_format($asset_list[20][$i], 2).'</td>');//Survey Rating
	//format_tbl_content($asset_list[20][$i], 100, right, $row_bgcolor);	//Order Value
	format_tbl_content($asset_list[13][$i], 10, right, $row_bgcolor);	//Surveyor
	format_tbl_content($asset_list[21][$i], 10, center, $row_bgcolor);	//Survey Minutes
	format_tbl_content($asset_list[22][$i], 90, center, $row_bgcolor);	//Survey Date


	echo ('</tr>');
	} // 	for ($i=0; $i<$_SESSION['List_Count']; $i+=1)

	echo ('	</table>');


	if ($debug==1) {
		if (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		else {echo "<br>Debug Mode: ON <br>Still Connected Fine. <br />";}


		echo "POST Category: '<b>".$_POST["in_Category"]."</b>'<br>";
		echo "POST Room: '<b>".$_POST["in_Room"]."</b>'<br>";
		echo "SESSION Category: '<b>".$_SESSION['$in_category']."</b>'<br>";
		echo "SESSION Room: '<b>".$_SESSION['$in_room']."</b>'<br>";
		echo "Sales Rep Count: '<b>".$_SESSION['Sales_Rep_Count']."</b>'<br>";

	}; //if ($debug==1)

//};// if isDate($_POST["in_Start_Date"])


}; // else 



?>
</body>
</html>
