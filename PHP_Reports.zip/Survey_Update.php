<?php
session_start();

require_once ('DB_Login.php');

$debug=0;

$DB_Conn = mssql_connect($DB2_Host, $DB2_UserName, $DB2_Password); 
mssql_select_db ( $DB2_Database, $DB_Conn );

$orig_list		= $_SESSION['Report_List'];
$orig_index		= $_GET['$orig_index'];
$orig_name		= $orig_list[0][$_GET['$orig_index']];	// Name
$orig_sales_id		= $orig_list[1][$_GET['$orig_index']];	// Sales_ID
$orig_order_id		= $orig_list[2][$_GET['$orig_index']];	// Order_ID
$orig_order_date	= $orig_list[3][$_GET['$orig_index']];	// Order_Date
$orig_email_requested	= $orig_list[4][$_GET['$orig_index']];	// Email_Requested
$orig_gold_owner	= $orig_list[5][$_GET['$orig_index']];	// Gold_Owner
$orig_collector_type	= $orig_list[6][$_GET['$orig_index']];	// Collector_Type
$orig_other_companies	= $orig_list[7][$_GET['$orig_index']];	// Other_Companies
$orig_specialist_name	= $orig_list[8][$_GET['$orig_index']];	// Specialist_Name
$orig_level_1		= $orig_list[9][$_GET['$orig_index']];	// Level 1
$orig_level_2		= $orig_list[10][$_GET['$orig_index']];	// Level 2
$orig_level_3		= $orig_list[11][$_GET['$orig_index']];	// Level 3
$orig_survey_rating	= $orig_list[12][$_GET['$orig_index']];	// Survey Rating
$orig_surveyor		= $orig_list[13][$_GET['$orig_index']];	// Surveyor
$orig_survey_comments	= $orig_list[14][$_GET['$orig_index']];	// Survey Suggestion
$orig_cust_id		= $orig_list[15][$_GET['$orig_index']];	// Cust_ID
$orig_first_name	= $orig_list[16][$_GET['$orig_index']];	// First_Name
$orig_last_name		= $orig_list[17][$_GET['$orig_index']];	// Last_Name
$orig_contact_number	= $orig_list[18][$_GET['$orig_index']];	// Contact_Number
$orig_alternate_number	= $orig_list[19][$_GET['$orig_index']];	// Alternate_Number
$orig_ttl_billed_merch	= $orig_list[20][$_GET['$orig_index']];	// ttl_Billed_Merch
$orig_survey_minutes	= $orig_list[21][$_GET['$orig_index']];	// Survey Minutes

if (rtrim($orig_alternate_number)=='') {
	$orig_alternate_number='None';
}


$orig_inventory='';

If ($debug==1) {	
	if (! $DB_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to database. <br />";}

	echo ('<br>GET index: '.$_GET['$orig_index']);	
	echo ('<br>Original Order Date: '.$orig_order_date);	
	echo ('<br>Original Cust ID: '.$orig_customer_id);
	echo ('<br>Original Contact Number: '.$orig_contact_number);
	echo ('<br>DB Host: '.$DB2_Host);	
	echo ('<br>DB Used: '.$DB2_Database);	
	echo ('<br>DB User: '.$DB2_UserName);	
	echo ('<br>Surveyor Session: <b>'.$_SESSION['$in_surveyor'].'</b>');


	echo ('<br>**************************************************************************************');

};
	
function Submit_Record_Update ($DB_Conn, $in_Sales_ID, $in_Order_ID, $in_Email_Requested, $in_Gold_Owner, $in_Collector_Type, $in_Other_Companies, $in_Specialist_Name, $in_Level_One, $in_Level_Two, $in_Level_Three, $in_Survey_Rating, $in_Surveyor, $in_Survey_Minutes, $in_Comments, $debug)
	{
        $sp = mssql_init ( 'usp_Survey_Update', $DB_Conn ); //init stored procedure  
	mssql_bind ( $sp, '@in_Sales_ID', $in_Sales_ID, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Order_ID', $in_Order_ID, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Email_Request', $in_Email_Requested, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Gold_Owner', $in_Gold_Owner, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Collector_Type', $in_Collector_Type, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Other_Companies', $in_Other_Companies, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Specialist_Name', $in_Specialist_Name, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Level_One', $in_Level_One, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Level_Two', $in_Level_Two, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Level_Three', $in_Level_Three, SQLVARCHAR, false,false,50);
	mssql_bind ( $sp, '@in_Survey_Rating', $in_Survey_Rating, SQLINT1, false,false,50);
	mssql_bind ( $sp, '@in_Surveyor', $in_Surveyor, SQLVARCHAR, false,false,3);
	mssql_bind ( $sp, '@in_Survey_Minutes', $in_Survey_Minutes, SQLINT1, false,false,50);
	mssql_bind ( $sp, '@in_Comments', $in_Comments, SQLTEXT, false,false,5000);

	mssql_execute ( $sp );

	if ($debug==2){
		echo ('<br>Update sent');
		echo ('<br>Database connection is: '.$DB_Conn);
		echo ('<br>Updated asset tag is: '.$inve_asset_tag);
		echo ('<br>Updated hardware type is: '.$inve_hardware_type);
		echo ('<br>Updated serial number is: '.$inve_serial_number);
		echo ('<br>Updated purchase date is: '.$inve_purchase_date);
		echo ('<br>Updated status is: '.$inve_status);
		echo ('<br>Updated manufacturer is: '.$inve_manufacturer);
		echo ('<br>Updated model number is: '.$inve_model_number);
		echo ('<br>Updated warranty is: '.$inve_warranty);
		echo ('<br>Updated location is: '.$inve_location);
		echo ('<br>Updated assigned to is: '.$inve_assigned_to);
		echo ('<br>Updated MAC address is: '.$inve_mac_address);
		echo ('<br>Updated IP address is: '.$inve_ip_address); 
		echo ('<br>Updated Comment is: '.$inve_comments);
	}
	return; 
	} 

function get_list ($DB_Conn, $in_contact_phone1, $in_contact_phone2, $debug){

	if($in_contact_phone1==''){$in_contact_phone1='None';} 
	if($in_contact_phone2==''){$in_contact_phone2='None';} 

	$query_call_history1="
		SELECT     
		Contact_Number, 
		Call_Start_Time, 
		Call_Disposition, 
		Sales_Rep, 
		Call_Seconds, 
		MP3_File_Name_2 AS MP3_File_Name, 
		RIGHT(MP3_File_Name_2, 37) AS File_Name
		FROM	tbl_Survey_Calls
		WHERE	Contact_Number='".$in_contact_phone1."'
		OR	Contact_Number='".$in_contact_phone2."'
		ORDER BY Call_Start_Time DESC
		";

	$result1=mssql_query($query_call_history1, $DB_Conn);
	$numrows=mssql_num_rows($result1);
	$_SESSION['List_Count_A']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$textout[0][$i]=mssql_result($result1, $i, 0);//Contact Number
		$textout[1][$i]=mssql_result($result1, $i, 1);//Call_Start_Time
		$textout[2][$i]=mssql_result($result1, $i, 2);//Call_Disposition
		$textout[3][$i]=mssql_result($result1, $i, 3);//Sales_Rep
		$textout[4][$i]=mssql_result($result1, $i, 4);//Call_Seconds
		$textout[5][$i]=mssql_result($result1, $i, 5);//New_File_Name
		$textout[6][$i]=mssql_result($result1, $i, 6);//File_Name
	}


	if ($debug==1){
		echo ('<br>in Function get_list');
		echo ('<br>Database connection is: '.$DB_Conn);
		echo ('<br>Query call history1: '.$query_call_history1);
		echo ('<br>result is: '.$result);
		echo ('<br>List count is: '.$_SESSION['List_Count_A']);
		echo ('<br>Numrows is: '.$numrows);
		//echo ('<br>query1: '.$query_call_history1);
	}

	Return $textout;
}


function send_alert($DB_Conn, $orig_index, $orig_list, $debug){

	$phone_list=get_list ($DB_Conn, $orig_list[18][$orig_index], $orig_list[19][$orig_index], $debug);

	$mail_body_links='';

	if($_SESSION['List_Count_A']>0){
		for($i=0;$i<$_SESSION['List_Count_A'];$i+=1){
			if (file_exists($phone_list[5][$i])){
				//$mail_body_links .= '<br>'.$phone_list[5][$i];
				$mail_body_links .= '<a href="'.$phone_list[5][$i].'" >'.$phone_list[6][$i].'</a><br>';
			}
			else {
				$mail_body_link .='Recording No Longer Available.';
			
			} // end if (file_exists($phone_list[5][$i]))
		} // end for($i=0;$i<$_SESSION['List_Count_A'];$i+=1)
	} //if($_SESSION['List_Count_A']>0)
	else {$mail_body_links='None';}
 
 	$mail_sender='qa@usmoneyreserve.com';

	//if ($_SESSION['$in_surveyor']=='TN'){$mail_sender='tnichols@usmoneyreserve.com';}
	//if ($_SESSION['$in_surveyor']=='SK'){$mail_sender='skyser@usmoneyreserve.com';}
	//if ($_SESSION['$in_surveyor']=='LB'){$mail_sender='lbraddock@usmoneyreserve.com';}

	if (($_POST["in_Collector_Type"])==''){$upd_Collector_Type='None';} else {$upd_Collector_Type=$_POST["in_Collector_Type"];}
	if (($_POST["in_Other_Companies"])==''){$upd_Other_Companies='None';} else {$upd_Other_Companies=$_POST["in_Other_Companies"];}
	if (($_POST["in_Specialist_Name"])==''){$upd_Specialist_Name='None';} else {$upd_Specialist_Name=$_POST["in_Specialist_Name"];}
	if (($_POST["in_Level_One"])==''){$upd_Level_One='None';} else {$upd_Level_One=$_POST["in_Level_One"];}
	if (($_POST["in_Level_Two"])==''){$upd_Level_Two='None';} else {$upd_Level_Two=$_POST["in_Level_Two"];}
	if (($_POST["in_Level_Three"])==''){$upd_Level_Three='None';} else {$upd_Level_Three=$_POST["in_Level_Three"];}
	if (($_POST["in_Comments"])==''){$upd_Comments='None';} else {$upd_Comments=$_POST["in_Comments"];}

	//ini_set (sendmail_from, 'tnichols@usmoneyreserve.com');
	ini_set (sendmail_from, $mail_sender);

	if (($_POST["in_Email_Address"])=='') {$mail_to='tnichols@usmoneyreserve.com';} else {$mail_to=$_POST["in_Email_Address"];}

	
	
	$mail_cc ='MIME-Version: 1.0'."\r\n";
	$mail_cc.='Content-type: text/html; charset=iso-8859-1'."\r\n";
	$mail_cc.='cc:lbraddock@usmoneyreserve.com, skyser@usmoneyreserve.com, jjordan@usmoneyreserve.com';
	$mail_subject='Survey Alert: '.$orig_list[0][$_GET['$orig_index']];
	$mail_body='';

	$mail_body='
		<html>
		Please review the recent survey for Sales Rep <b>'.$orig_list[0][$_GET['$orig_index']].'</b><br>
		It scored <b>'.$orig_list[12][$_GET['$orig_index']].'%</b> for...<br> 
		<table align=center>
		<tr>
		<td style="width=150px" align=left valign=top>
		<label>Customer ID:<br><b>'.$orig_list[15][$_GET['$orig_index']].'</b></label>
		</td>
		<td style="width=150px" align=center valign=top>
		<label>Customer Name:<br><b>'.$orig_list[16][$_GET['$orig_index']].' '.$orig_list[17][$_GET['$orig_index']].'</b></label>
		</td>
		<td style="width=150px" align=center valign=top>
		<label>Order ID<br><b>'.$orig_list[2][$_GET['$orig_index']].'</b></label>
		</td>
		<td style="width=150px" align=center valign=top>
		<label>Contact Number<br><b>'.$orig_list[18][$_GET['$orig_index']].'</b></label>
		</td>
		<td style="width=150px" align=center valign=top>
		<label>Alternate Number<br><b>'.$orig_list[19][$_GET['$orig_index']].'</b></label>
		</td>
		<td style="width=150px" align=right valign=top>
		<label>Order Value<br><b>$ '.number_format($orig_list[20][$_GET['$orig_index']], 2).'</b></label>
		</td>
		</tr>
		</table>';

	$mail_body .='<br><br>Request eMail?<br>'.$_POST["in_Email_Requested"].'
		<br><br>Gold Owner?<br>'.$_POST["in_Gold_Owner"].'
		<br><br>Collector Type:<br>'.$upd_Collector_Type.'
		<br><br>Other Companies:<br>'.$upd_Other_Companies;

	//$mail_body .='<br><br>Specialist Name:<br>'.$upd_Specialist_Name;
	$mail_body .='<br><br>Level One Offense?<br>'.$upd_Level_One.'
		<br><br>Level Two Offense?<br>'.$upd_Level_Two.'
		<br><br>Level Three Offense?<br>'.$upd_Level_Three.'
		<br><br>Other Observations?<br>'.$upd_Comments;
	
	$mail_body .='<br><br>Available Recordings:<br>';
 
	$mail_body .= $mail_body_links;
	$mail_body .= '</html>';
 
	$success = mail($mail_to, $mail_subject, $mail_body, $mail_cc);


	if ($debug==1){

		if($success){	
			echo ('<br>Mail Successful');
			$mail_error_to='tnichols@usmoneyreserve.com';
			$mail_error_subject='Email Succeeded';
			$mail_error_body='';
			$send = mail($mail_error_to, $mail_error_subject, $mail_error_body);
		}
		else {
			echo ('<br>Mail Failure');
			$mail_error_to='tnichols@usmoneyreserve.com';
			$mail_error_subject='Email Failed';
			$mail_error_body='';
			$send = mail($mail_error_to, $mail_error_subject, $mail_error_body);
		}

		echo ('<br>in the mail section');
		echo ('<br>mail body looks like: '.$mail_body);
		echo ('<br>');

	}

}


?>

<html>
<title>USRCBR Customer Service Quality Assurance</title>
<head>

<script type="text/javascript">
	function show_asset(Phone_ID){
	<!--
	str_redirect='./Survey_Phone.php?$orig_index='+Phone_ID
	window.open (str_redirect, 'Asset_Window_'+Phone_ID, config='height=400, width=1200, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}
</script>


</head>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

//$test=get_list ($DB_Conn, $orig_list[18][$orig_index], $orig_list[19][$orig_index], $debug);

if ($_POST['Send']){
	$orig_inventory='notClose';
	send_alert($DB_Conn, $orig_index, $orig_list, $debug);
	
}

if ($_POST['Update']){
	//$orig_inventory='Close';
	
	$upd_Email_Requested	=($_POST["in_Email_Requested"]);
	$upd_Gold_Owner		=($_POST["in_Gold_Owner"]);
	$upd_Collector_Type	=($_POST["in_Collector_Type"]);
	$upd_Other_Companies	=($_POST["in_Other_Companies"]);
	$upd_Specialist_Name	=($_POST["in_Specialist_Name"]);
	$upd_Level_One		=($_POST["in_Level_One"]);
	$upd_Level_Two		=($_POST["in_Level_Two"]);
	$upd_Level_Three	=($_POST["in_Level_Three"]);
	$upd_Comments		=($_POST["in_Comments"]);
	$upd_Survey_Minutes	=($_POST["in_Survey_Minutes"]);
	
	$upd_Survey_Rating=100;

	if($upd_Email_Requested=='No'){
		$upd_Survey_Rating=$upd_Survey_Rating-5;
	}

	if($upd_Gold_Owner=='No'){
		$upd_Survey_Rating=$upd_Survey_Rating-5;
	}

	if(rtrim($upd_Level_One!='')){
		$upd_Survey_Rating=$upd_Survey_Rating-20;
	}

	if(rtrim($upd_Level_Two!='')){
		$upd_Survey_Rating=$upd_Survey_Rating-30;
	}

	if(rtrim($upd_Level_Three!='')){
		$upd_Survey_Rating=$upd_Survey_Rating-40;
	}

Submit_Record_Update($DB_Conn, $orig_sales_id, $orig_order_id, $upd_Email_Requested, $upd_Gold_Owner, $upd_Collector_Type, $upd_Other_Companies, $upd_Specialist_Name, $upd_Level_One, $upd_Level_Two, $upd_Level_Three, $upd_Survey_Rating, $orig_surveyor, $upd_Survey_Minutes, $upd_Comments, $debug);

	$orig_inventory='Close';

	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine. <br> Second Pass. <br>";}


		echo "Email: '<b>".$_POST["in_Email_Requested"]."</b>'<br>";
		echo "Gold?: '<b>".$_POST["in_Gold_Owner"]."</b>'<br>";
		echo "Collector: '<b>".$_POST["in_Collector_Type"]."</b>'<br>";
		echo "Company: '<b>".$_POST["in_Other_Companies"]."</b>'<br>";
		echo "Name: '<b>".$_POST["in_Specialist_Name"]."</b>'<br>";
		echo "Level 1: '<b>".$_POST["in_Level_One"]."</b>'<br>";
		echo "Level 2: '<b>".$_POST["in_Level_Two"]."</b>'<br>";
		echo "Level 3: '<b>".$_POST["in_Level_Three"]."</b>'<br>";
		echo "Suggestions to Sales Reps: '<b>".$_POST["in_Comments"]."</b>'<br>";
		echo "rating: '<b>".$in_Survey_Rating."</b>'<br>";
		echo "Surveyor: '<b>".$in_Surveyor."</b>'<br>";
		echo "upd comments: '<b>".$upd_Comments."</b>'<br>";
		echo "POST Comments: '<b>".$_POST["in_Comments"]."</b>'<br>";

	};

}


if($orig_inventory == 'Close')
{
?>
<script language=JavaScript>
window.close();
</script>
<?php
}

if($orig_inventory==''){
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Customer Service: Survey Selection Confirmation</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>

	<br>Survey for: <b>'.$orig_name.'</b>
	<br>Rating: <b>'.$orig_survey_rating.'</b>
	<br>By: <b>'.$orig_surveyor.'<b>
	<br>
	<br>
	<table align=center>
	<tr>
	<td style="width=150px" align=left valign=top>
	<label>Customer ID:<br><b>'.$orig_cust_id.'</b></label>
	</td>
	
	<td style="width=150px" align=center valign=top>
	<label>Customer Name:<br><b>'.$orig_first_name.' '.$orig_last_name.'</b></label>
	</td>

	<td style="width=150px" align=center valign=top>
	<label>Order ID<br><b>'.$orig_order_id.'</b></label>
	</td>

	<td onClick="show_asset('.$orig_contact_number.')" style="width=150px" align=center valign=top>
	<label>Contact Number<br><b>'.$orig_contact_number.'</b></label>
	</td>

	<td onClick="show_asset('.$orig_alternate_number.')" style="width=150px" align=center valign=top>
	<label>Alternate Number<br><b>'.$orig_alternate_number.'</b></label>
	</td>

	<td style="width=150px" align=right valign=top>
	<label>Order Value<br><b>$ '.number_format($orig_ttl_billed_merch, 2).'</b></label>
	</td>
	</tr>
	</table>
	<br>

	<form action="./Survey_Update.php?$orig_index='.$orig_index.'" method="POST">
	<table align=center>

	<tr>
	<td style="width=100px" align=left>
	<fieldset>');

	if ($orig_email_requested=="Yes"){
	echo ('	<label>Yes<input type="radio" name="in_Email_Requested" value="Yes" checked="checked"></label>
		<label>No<input type="radio" name="in_Email_Requested" value="No"></label>');
	}
	else {
	echo ('	<label>Yes<input type="radio" name="in_Email_Requested" value="Yes"></label>
		<label>No<input type="radio" name="in_Email_Requested" value="No" checked="checked"></label>');
	}

	echo ('</fieldset>
	</td>
	<td colspan=4 align=left>
	 (5 Points) Email Requested?
	</td>
	</tr>

	<tr>
	<td style="width=100px" align=left>
	<fieldset>');

	if ($orig_gold_owner=="Yes"){
		echo ('	<label>Yes<input type="radio" name="in_Gold_Owner" value="Yes" checked="checked"></label>
			<label>No<input type="radio" name="in_Gold_Owner" value="No"></label>');
	}
	else {
		echo ('	<label>Yes<input type="radio" name="in_Gold_Owner" value="Yes"></label>
			<label>No<input type="radio" name="in_Gold_Owner" value="No" checked="checked"></label>');
	}

echo ('
	</fieldset>
	</td>
	<td colspan=4>
	(5 Points) Did they ask if the potential customer owned gold? 
	</td>
	</tr>

	<tr>
	<td>
	</td>
	<td colspan=4>
	What type of coins did they collect? <i>(if applicable)</i><br>
	<select name="in_Collector_Type">
	<option>'.$orig_collector_type.'</option>
	<option value="Not Applicable">Not Applicable</option>
	<option value="None">None</option>
	<option value="Bullion">Bullion</option>
	<option value="Numismatic">Numismatic</option>
	<option value="Combo">Combo</option>
	</td>
	</tr>

	<tr>
	<td valign="bottom">Survey
	</td>
	<td colspan=4>
	<label>What company or companies have they worked with? <br>
	<input type="text" name="in_Other_Companies" size=50 align=left value="'.$orig_other_companies.'"></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td>
	<label>Minutes? <br>
	<input type="text" name="in_Survey_Minutes" size="5" align=center value="'.$orig_survey_minutes.'"></label>
	</td>
	<td colspan=4>
	<label>Did they know the name of their Gold Specialist? <br>
	<input type="text" name="in_Specialist_Name" size=50 align=left value="'.$orig_gold_specialist.'"></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(20 Points) Level I Offense <br>
	<input type="text" name="in_Level_One" size=80 align=left value="'.$orig_level_1.'"></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(30 Points) Level II Offense <br>
	<input type="text" name="in_Level_Two" size=80 align=left value="'.$orig_level_2.'"></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(40 Points) Level III Offense<br>
	<input type="text" name="in_Level_Three" size=80 align=left value="'.$orig_level_3.'"></label>	
	</td>
	<td>
	</td>
	</tr>

	<tr><td colspan=5>
	<label>Suggestions to Sales Reps:<br>
	<textarea name="in_Comments" cols=60 rows=5 align=center>'.$orig_survey_comments.'</textarea></label>
	</td></tr>

	<tr><td colspan=5 align=center>
	<input type="submit" name="Update" value="Update" />
	</td>
	
	<tr></tr>
	
	<tr>
	<td align="center" colspan=5>
	Send Alert To:<br>
	<select name="in_Email_Address">
	<option>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</option>
	<option value="tnichols@usmoneyreserve.com">Tony Nichols</option>
	<option value="brollings@usmoneyreserve.com;tcarifa@usmoneyreserve.com">Ben Rollings</option>
	<option value="rraben@usmoneyreserve.com;tcarifa@usmoneyreserve.com">Robert Raben</option>
	<option value="rcastillo@usmoneyreserve.com;tcarifa@usmoneyreserve.com">Remmy Castillo</option>
	<option value="sdominguez@usmoneyreserve.com;tcarifa@usmoneyreserve.com">Steve Dominguez</option>
	<option value="lkuykendall@usmoneyreserve.com">Larry Kuykendall</option>
	<option value="jdurham@usmoneyreserve.com">JohnPaul Durham</option>
	<option value="msorensen@usmoneyreserve.com">Malayna Sorensen</option>
	<option value="tcarifa@usmoneyreserve.com">Tony Carifa</option>
	<option value="qa@usmoneyreserve.com">QA Team</option>
	<option value="skyser@usmoneyreserve.com">Susan Kyser</option>
	<option value="lbraddock@usmoneyreserve.com">Leah Braddock</option>
	</td>
	</tr>

	<tr><td align="center" colspan=5>
	<input type="submit" name="Send" value="Send" />
	</td>
	</tr>


	</table></form>');
	echo "<br>";


} // end if($inve_asset_tag==='')
else {
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Customer Service: Survey Selection Confirmation</h2>
	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>

	<br>Survey for: <b>'.$orig_name.'</b>
	<br>Rating: <b>'.$upd_Survey_Rating.'</b>
	<br>By: <b>'.$in_Surveyor.'<b>
	<br>
	<br>
	<table align=center>
	<tr>
	<td style="width=150px" align=left valign=top>
	<label>Customer ID:<br><b>'.$orig_cust_id.'</b></label>
	</td>
	
	<td style="width=150px" align=left valign=top>
	<label>Customer Name:<br><b>'.$orig_first_name.' '.$orig_last_name.'</b></label>
	</td>

	<td style="width=150px" align=left valign=top>
	<label>Order ID<br><b>'.$orig_order_id.'</b></label>
	</td>

	<td style="width=150px" align=left valign=top>
	<label>Contact Number<br><b>'.$orig_contact_number.'</b></label>
	</td>

	<td style="width=150px" align=left valign=top>
	<label>Alternate Number<br><b>'.$orig_alternate_number.'</b></label>
	</td>

	<td style="width=150px" align=left valign=top>
	<label>Order Value<br><b>$ '.number_format($orig_ttl_billed_merch, 2).'</b></label>
	</td>
	</tr>
	</table>
	<br>

	<form action="./Survey_Update.php?$orig_index='.$orig_index.'" method="POST">
	<table align=center>

	<tr>
	<td style="width=100px" align=left>
	<fieldset>');

	if ($_POST["in_Email_Requested"]=="Yes"){
	echo ('	<label>Yes<input type="radio" name="in_Email_Requested" value="Yes" checked="checked"></label>
		<label>No<input type="radio" name="in_Email_Requested" value="No"></label>');
	}
	else {
	echo ('	<label>Yes<input type="radio" name="in_Email_Requested" value="Yes"></label>
		<label>No<input type="radio" name="in_Email_Requested" value="No" checked="checked"></label>');
	}

	echo ('</fieldset>
	</td>
	<td colspan=4 align=left>
	 (5 Points) Email Requested?
	</td>
	</tr>

	<tr>
	<td style="width=100px" align=left>
	<fieldset>');

	if ($_POST["in_Gold_Owner"]=="Yes"){
		echo ('	<label>Yes<input type="radio" name="in_Gold_Owner" value="Yes" checked="checked"></label>
			<label>No<input type="radio" name="in_Gold_Owner" value="No"></label>');
	}
	else {
		echo ('	<label>Yes<input type="radio" name="in_Gold_Owner" value="Yes"></label>
			<label>No<input type="radio" name="in_Gold_Owner" value="No" checked="checked"></label>');
	}

echo ('
	</fieldset>
	</td>
	<td colspan=4>
	(5 Points) Did they ask if the potential customer owned gold? 
	</td>
	</tr>

	<tr>
	<td>
	</td>
	<td colspan=4>
	What type of coins did they collect? <i>(if applicable)</i><br>
	<select name="in_Collector_Type">
	<option>'.$_POST["in_Collector_Type"].'</option>
	<option value="Not Applicable">Not Applicable</option>
	<option value="None">None</option>
	<option value="Bullion">Bullion</option>
	<option value="Numismatic">Numismatic</option>
	<option value="Combo">Combo</option>
	</td>
	</tr>

	<tr>
	<td valign="bottom">Survey
	</td>
	<td colspan=4>
	<label>What company or companies have they worked with? <br>
	<input type="text" name="in_Other_Companies" size=50 align=left value="'.$_POST["in_Other_Companies"].'"></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td>
	<label>Minutes?<br>
	<input type="text" name="in_Survey_Minutes" size="5" align=center value="'.$_POST["in_Survey_Minutes"].'"></label>
	</td>
	<td colspan=4>
	<label>Did they know the name of their Gold Specialist? <br>
	<input type="text" name="in_Specialist_Name" size=50 align=left value="'.$_POST["in_Specialist_Name"].'"></label>
	</td>
	<td>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(20 Points) Level I Offense <br>
	<input type="text" name="in_Level_One" size=80 align=left value="'.$_POST["in_Level_One"].'"></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(30 Points) Level II Offense <br>
	<input type="text" name="in_Level_Two" size=80 align=left value="'.$_POST["in_Level_Two"].'"></label>
	</td>
	</tr>

	<tr>
	<td colspan=5>
	<label>(40 Points) Level III Offense<br>
	<input type="text" name="in_Level_Three" size=80 align=left value="'.$_POST["in_Level_Three"].'"></label>	
	</td>
	<td>
	</td>
	</tr>

	<tr><td colspan=5>
	<label>Suggestions to Sales Reps:<br>
	<textarea name="in_Comments" cols=60 rows=3 align=center>'.$_POST["in_Comments"].'</textarea></label>
	</td></tr>

	<tr><td colspan=5 align=center>
	<input type="submit" name="Update" value="Update" />
	</td>

	</table></form>');
	echo "<br>";

}; //else ($orig_inventory<>'')


	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine. <br> First Pass. <br>";}


		echo "Email: '<b>".$_POST["in_Email_Requested"]."</b>'<br>";
		echo "Gold?: '<b>".$_POST["in_Gold_Owner"]."</b>'<br>";
		echo "Collector: '<b>".$_POST["in_Collector_Type"]."</b>'<br>";
		echo "Company: '<b>".$_POST["in_Other_Companies"]."</b>'<br>";
		echo "Name: '<b>".$_POST["in_Specialist_Name"]."</b>'<br>";
		echo "Level 1: '<b>".$_POST["in_Level_One"]."</b>'<br>";
		echo "Level 2: '<b>".$_POST["in_Level_Two"]."</b>'<br>";
		echo "Level 3: '<b>".$_POST["in_Level_Three"]."</b>'<br>";
		echo "Suggestions to Sales Reps: '<b>".$_POST["in_Comments"]."</b>'<br>";
		echo "rating: '<b>".$in_Survey_Rating."</b>'<br>";


	};

 


?>

</html>
