<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='Vault Returns Manager' || $securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Vault Management Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');

	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<center>WELCOME to the Vault Management Toolsite. The currently options available are: </center><br/>');

	echo ('<table align="center">');

	echo ('<tr><td></td><td><a href="./VaultMgmt_Review.php">SIMS Sales Return Review</td></tr>');
	echo ('<tr><td></td><td><a href="./VaultMgmt_Returns.php">Issues Register</td></tr>');
	echo ('<tr><td></td><td><a href="./VaultMgmt_Search_Cust_ID.php">Loadbook Editor using Customer IDs</td></tr>');
	echo ('<tr><td></td><td><a href="./VaultMgmt_Search_Loadbook.php">Loadbook Editor using Wildcard Searches</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales ID</td></tr>');
	echo ('<tr><td></td><td><a href="./BSS_Verification_List.php">Verification Follow-Up List</td></tr>');

	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
