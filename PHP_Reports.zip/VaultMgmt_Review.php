<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $securitygroup=='Executive') 
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}
/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////
require ('DB_Login.php');
require ('PHP_Functions.php');


$DB1_Conn = mssql_connect ( $DB0_Host, $DB0_UserName, $DB0_Password, TRUE ); //connect to USRCAPPSRVR01 SIMS
$DB2_Conn = mssql_connect ( $DB2_Host, $DB2_UserName, $DB2_Password, TRUE ); //connect to USRCREP02

IF ($debug==1){
	IF (! $DB1_Conn) {
		DIE ("Could not connect to Swordfish Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to USRCAPPSRVR01 SIMS Database. <br />";}
	IF (! $DB2_Conn) {
		DIE ("Could not connect to USRCREP02 Database. <br/>Please contact IT Administrator for assistance. <br/>");
	}
	ELSE {echo "Connected to USRCREP02 Database. <br />";}

}

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";

function get_ReturnReasons($DB1_Conn, $debug) {

	$query="SELECT 
		ReturnReason
		FROM [SIMS].dbo.InventoryReturnsTable VRT
		INNER JOIN [SIMS].dbo.LoginTable LT
		ON VRT.SalesName=LT.RealName
		GROUP BY ReturnReason";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Return_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Manager
	}

	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
		}
		echo ('<br>Return Reason Query Looks Like:<br> '.$query);
		echo ('<br>Return Count Query Looks Like:'.$_SESSION['Return_Count']);
		echo ('<br>');
	}
	Return $answer;

};

function get_Room($DB1_Conn, $debug) {

	$query="
		SELECT SecurityLevel AS Room
		FROM [SIMS].dbo.LoginTable
		WHERE (SecurityLevel IS NOT NULL) 
		AND (SecurityLevel <> 'Johnpaul Durham')
		AND (SecurityLevel <> 'Austin Sales')
		AND (SecurityLevel <> 'Beaumont Sales')
		AND (SecurityLevel <> 'C3 Sales')		
		AND (SecurityLevel Like '%sales%')
		GROUP BY SecurityLevel
		";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Room_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Manager
	}

	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}
		echo ('<br>Room Query Looks Like:<br> '.$query);
		echo ('<br>');
	}
	Return $answer;

};

function get_Managers($DB1_Conn, $room, $debug) {

	
	if ($room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" SecurityLevel='".$room."'";
	};
	 
	$query="SELECT Manager FROM [SIMS].dbo.LoginTable
		WHERE (Manager IS NOT NULL OR Manager <>'') 
		AND (Manager <> 'Johnpaul Durham')
		AND (SecurityLevel Like '%sales%')
		AND (".$SQL_Room.")
		AND (SecurityLevel <> 'Austin Sales')
		AND (SecurityLevel <> 'Beaumont Sales')
		AND (SecurityLevel <> 'C3 Sales')		
		GROUP BY Manager";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['Manager_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Manager
	}

	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to Login Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to Login Database. <br />";
			echo ('<br>');
		}

		echo ('<br>Manager Query Looks Like:<br> '.$query);
		echo ('<br>');
	}
	Return $answer;
};

function get_SalesRep($DB1_Conn, $room, $manager, $debug) {

	if ($room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}
	else {
		$SQL_Room=" 1=1 ";
		//$SQL_Room=" SecurityLevel='".$room."'";
	}

	if ($room=='Austin Sales Manager') {
		$SQL_Room=" Manager IN ('Ben Rollings (BN)', 'Robert Raben (RN)') ";
	}

	if ($room=='Beaumont Sales Manager') {
		$SQL_Room=" Manager IN ('Johnpaul Durham (JP)', 'Larry Kuykendall (LK)') ";
	}

	if ($room=='C3 Sales Manager') {
		$SQL_Room=" Manager IN ('Brad Remmington (RBC)') ";
	}

	if ($manager=='All Sales Managers') {
		$SQL_Sales_Manager=" 1=1 ";
	}
	else {
		$SQL_Sales_Manager=" Manager='".$manager."'";
	}

	$query="SELECT RealName 
		FROM [SIMS].dbo.LoginTable
		WHERE ( RealName IS NOT NULL ) 
		AND ( RealName LIKE '%(%)' ) 
		AND ( ".$SQL_Room." ) 		
		AND ( ".$SQL_Sales_Manager." ) 
		AND ( RealName NOT LIKE '%Austin%' )
		AND ( RealName NOT LIKE '%Beaumont%' )
		AND ( RealName NOT LIKE '%C3%' )
		AND ( RealName <> 'Customer Service Manager (MG)' )
		AND ( RealName <> 'Generic Manager Account (GMA)' )
		AND ( RealName <> 'Inventory Training (INVTRAIN)' )
		AND ( RealName <> 'Michael Koch (Administrator Role)' )
		AND ( RealName <> 'Sales Training (SALTRAIN)' )
		AND ( RealName <> 'Adam Steward (AS1)' )
		GROUP BY RealName";

	//AND ( SecurityLevel LIKE '%Sales%' ) 
	//
	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['SalesRep_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i]=mssql_result($result, $i, 0);//Sales_Rep
	}

	if ($debug==1){
		echo ('<br>Sales Rep query Looks Like:<br> '.$query);
		echo ('<br>');
		echo ('<br>Result is : '.$result);
		echo ('<br>Numrows are: '.$numrows);
		echo ('<br>');
	}

	Return $answer;

}; // end function get_SalesRep()
 
function get_History($DB1_Conn, $in_Room, $in_Manager, $in_SalesRep, $in_Return_Reason, $in_StartDate, $in_StopDate, $debug){


	if ($in_Return_Reason =='All Return Reasons') {
		$SQL_Reason=" 1=1 ";
	}
	else {
		$SQL_Reason=" ReturnReason='".$in_Return_Reason."'";
	}

	if ($in_Room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}

	if ($in_Room=='Austin Sales Manager') {
		$SQL_Room=" Manager IN ('Ben Rollings (BN)', 'Robert Raben (RN)') ";
	}

	if ($in_Room=='Beaumont Sales Manager') {
		$SQL_Room=" Manager IN ('Johnpaul Durham (JP)', 'Larry Kuykendall (LK)') ";
	}

	if ($in_Room=='C3 Sales Manager') {
		$SQL_Room=" Manager IN ('Brad Remmington (RBC)') ";
	}

	if ($in_Manager=='All Sales Managers') {
		$SQL_Sales_Manager=" 1=1 ";
	}
	else {
		$SQL_Sales_Manager=" Manager='".$in_Manager."'";
	}

	if($in_SalesRep=='All Sales Reps'){
		$SQL_Sales_Rep=" 1=1 ";
	}
	else {
		$SQL_Sales_Rep=" Realname='".$in_SalesRep."'";
	}

	$query1="
		SELECT 
		ReturnReason,
		[DateTime],
		RealName,
		CustomerName,
		SalesID,
		MOMOrderNumber,
		[Value],
		Notes,
		Notes
		FROM [SIMS].dbo.vw_Sales_Returns_Review
		WHERE ( ".$SQL_Sales_Rep." ) 
		AND ( ".$SQL_Sales_Manager." )
		AND ([DateTime] >= (CONVERT(datetime, '".$in_StartDate."')))
		AND ([DateTime] < (CONVERT(datetime, '".$in_StopDate."')))
		AND ( ".$SQL_Room." )
		AND ( ".$SQL_Reason." )
		ORDER BY SalesName,
		[DateTime]
		";

	$query2="
		SELECT 
		RealName
		FROM [SIMS].dbo.vw_Sales_Returns_Review
		WHERE ( ".$SQL_Sales_Rep." ) 
		AND ( ".$SQL_Sales_Manager." )
		AND ([DateTime] >= (CONVERT(datetime, '".$in_StartDate."')))
		AND ([DateTime] < (CONVERT(datetime, '".$in_StopDate."')))
		AND ( ".$SQL_Room." )
		AND ( ".$SQL_Reason." )
		GROUP BY RealName
		";

	$query3="
		SELECT 
		CustomerName
		FROM [SIMS].dbo.vw_Sales_Returns_Review
		WHERE ( ".$SQL_Sales_Rep." ) 
		AND ( ".$SQL_Sales_Manager." )
		AND ([DateTime] >= (CONVERT(datetime, '".$in_StartDate."')))
		AND ([DateTime] < (CONVERT(datetime, '".$in_StopDate."')))
		AND ( ".$SQL_Room." )
		AND ( ".$SQL_Reason." )
		GROUP BY CustomerName
		";

	$result1=mssql_query($query1, $DB1_Conn);
	$numrows1=mssql_num_rows($result1);
	$_SESSION['SalesRep_Order_Count']=$numrows1;

	$result2=mssql_query($query2, $DB1_Conn);
	$numrows2=mssql_num_rows($result2);
	$_SESSION['SalesRep_Count']=$numrows2;

	$result3=mssql_query($query3, $DB1_Conn);
	$numrows3=mssql_num_rows($result3);
	$_SESSION['SalesRep_Customers']=$numrows3;

	$_SESSION['SalesRep_Order_Total']= 0;

	for($i=0;$i<$numrows1;$i+=1){
		$answer[0][$i]=mssql_result($result1, $i, 0); //ReturnReason
		$answer[1][$i]=mssql_result($result1, $i, 1); //DateTime
		$answer[2][$i]=mssql_result($result1, $i, 2); //SalesName
		$answer[3][$i]=mssql_result($result1, $i, 3); //CustomerName
		$answer[4][$i]=mssql_result($result1, $i, 4); //SalesID
		$answer[5][$i]=mssql_result($result1, $i, 5); //MOMOrderNumber
		$answer[6][$i]=mssql_result($result1, $i, 6); //Value
		$answer[7][$i]=mssql_result($result1, $i, 7); //Notes
		$answer[8][$i]=mssql_result($result1, $i, 8); //Notes
		$_SESSION['SalesRep_Order_Total']=$_SESSION['SalesRep_Order_Total']+$answer[6][$i];
	}

	if ($debug==1){
		echo ('<br><b>Get_History Function</b><br>');
		echo ('<br>Order Detail <b>query1</b> Looks Like:<br> '.$query1);
		echo ('<br>Order Detail <b>query2</b> Looks Like:<br> '.$query2);
		echo ('<br>Order Detail <b>query3</b> Looks Like:<br> '.$query3);
		echo ('<br>Order Detail <b>query4</b> Looks Like:<br> '.$query4);
		echo ('<br>Result is : '.$result);
		echo ('<br>Anwser is : '.$answer);
		echo ('<br>Numrows are: '.$numrows);
		echo ('<br>out_Return_Reasons looks like: '.$_SESSION['out_Return_Reasons'][0][0]);
		echo ('<br>count of out_Return_Reasons: '.$_SESSION['Return_Reasons_Count']);
	}

	Return $answer;
};

function get_Summary($DB1_Conn, $in_Room, $in_Manager, $in_SalesRep, $in_Return_Reason, $in_StartDate, $in_StopDate, $debug){


	if ($in_Return_Reason =='All Return Reasons') {
		$SQL_Reason=" 1=1 ";
	}
	else {
		$SQL_Reason=" ReturnReason='".$in_Return_Reason."'";
	}

	if ($in_Room=='All Sales Rooms') {
		$SQL_Room=" 1=1 ";
	}

	if ($in_Room=='Austin Sales Manager') {
		$SQL_Room=" Manager IN ('Ben Rollings (BN)', 'Robert Raben (RN)') ";
	}

	if ($in_Room=='Beaumont Sales Manager') {
		$SQL_Room=" Manager IN ('Johnpaul Durham (JP)', 'Larry Kuykendall (LK)') ";
	}

	if ($in_Room=='C3 Sales Manager') {
		$SQL_Room=" Manager IN ('Brad Remmington (RBC)') ";
	}

	if ($in_Manager=='All Sales Managers') {
		$SQL_Sales_Manager=" 1=1 ";
	}
	else {
		$SQL_Sales_Manager=" Manager='".$in_Manager."'";
	}

	if($in_SalesRep=='All Sales Reps'){
		$SQL_Sales_Rep=" 1=1 ";
	}
	else {
		$SQL_Sales_Rep=" Realname='".$in_SalesRep."'";
	}

	$query4="
		SELECT 
		ReturnReason,
		Count(*) AS Reason_Count,
		SUM ([Value]) AS [Value]
				FROM [SIMS].dbo.vw_Sales_Returns_Review
		WHERE ( ".$SQL_Sales_Rep." ) 
		AND ( ".$SQL_Sales_Manager." )
		AND ([DateTime] >= (CONVERT(datetime, '".$in_StartDate."')))
		AND ([DateTime] < (CONVERT(datetime, '".$in_StopDate."')))
		AND ( ".$SQL_Room." )
		AND ( ".$SQL_Reason." )
		GROUP BY ReturnReason
		ORDER BY Count(*) DESC, SUM ([Value]) DESC
		";

	$result4=mssql_query($query4, $DB1_Conn);
	$numrows4=mssql_num_rows($result4);
	// $_SESSION['out_Return_Reasons']=$result4;
	$_SESSION['Return_Reasons_Count']=$numrows4;

	for($i=0;$i<$numrows4;$i+=1){
		$answer[0][$i]=mssql_result($result4, $i, 0); //ReturnReason
		$answer[1][$i]=mssql_result($result4, $i, 1); //Count
		$answer[2][$i]=mssql_result($result4, $i, 2); //Sum of Value
	}

	if ($debug==2){
		echo ('<br>Order Detail query Looks Like:<br> '.$query4);
		echo ('<br>Result is : '.$result4);
		echo ('<br>Anwser is : '.$answer4);
		echo ('<br>Numrows are: '.$numrows4);
		echo ('<br>out_Return_Reasons looks like: '.$_SESSION['out_Return_Reasons'][0][0]);
		echo ('<br>count of out_Return_Reasons: '.$_SESSION['Return_Reasons_Count']);
	}

	Return $answer;
};


function show_History($good_money, $debug){

	for($i=0;$i<$_SESSION['SalesRep_Order_Count'];$i+=1){


		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
		echo ('<tr onClick="show_detail('.($i).')">');
		//echo ('<tr>');
		echo ('<td align="left" bgcolor="'.$row_bgcolor.'">'.$good_money[1][$i].'</td>'); // DateTime
		echo ('<td bgcolor="'.$row_bgcolor.'">'.$good_money[2][$i].'</td>'); // Sales Rep
		echo ('<td bgcolor="'.$row_bgcolor.'">'.$good_money[3][$i].'</td>'); // Customer Name
		echo ('<td bgcolor="'.$row_bgcolor.'">'.$good_money[0][$i].'</td>'); // Return Reason
		echo ('<td bgcolor="'.$row_bgcolor.'">'.$good_money[5][$i].'</td>'); // Order ID
		echo ('<td align="right" bgcolor="'.$row_bgcolor.'">$'.number_format($good_money[6][$i], 2).'</td>'); // Order Value
		echo ('</tr>');
	} // end for loop
}; // end function show_History()


?>
<html>

<head>

<script type="text/javascript">
	function show_detail(Index_ID){
	<!--
	str_redirect='./VaultMgmt_Review_Detail.php?$Index_ID='+Index_ID
//	str_redirect='http://usrc_primary/inventorymatrixweb/default.htm?MOMCustNum='+Cust_ID
//	str_redirect='./SIMS_Sales_Returns_Review_Detail.php?$Index_ID='+Index_ID
//	str_redirect='http://tnichols/Inventory/Inventory_Change.php'//?$inve_asset_tag='"+Index_ID+"'"
	window.open (str_redirect, 'Asset_Window_'+Index_ID, config='height=600, width=500, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->

	}

</script>

<script src="JS_Sort_Table.js"></script>

</head>

<title>USRCBR Vault Management Sales Return Review</title>

<?php
$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_Room"]="";
	$_POST["in_Manager"]="";
	$_POST["in_SalesRep"]="";
	$_POST["in_Return_Reason"]="";
	$_POST["in_Enter_Date"]="";
	$_POST["in_Stop_Date"]="";	
	$_SESSION['$in_sales_room']="";
	$_SESSION['$in_sales_manager']="";
	$_SESSION['$in_sales_rep']="";
	$_SESSION['$in_return_reason']="";
	$_SESSION['$in_enter_date']="";
	$_SESSION['$in_stop_date']="";
	$_SESSION['out_Return_Reasons']="";
	$_SESSION['Return_Reasons_Count']="";
	$_SESSION['SalesRep_Order_Total']="";

}

$in_sales_room=htmlentities($_POST["in_Room"]);
$in_sales_manager=htmlentities($_POST["in_Manager"]);
$in_sales_rep=htmlentities($_POST["in_SalesRep"]);
$in_return_reason=htmlentities($_POST["in_Return_Reason"]);
$in_enter_date=htmlentities($_POST["in_Enter_Date"]);
$in_stop_date=htmlentities($_POST["in_Stop_Date"]);

$_SESSION['$in_sales_room']=$in_sales_room;
$_SESSION['$in_sales_manager']=$in_sales_manager;
$_SESSION['$in_sales_rep']=$in_sales_rep;
$_SESSION['$in_return_reason']=$in_return_reason;
$_SESSION['$in_enter_date']=$in_enter_date;
$_SESSION['$in_stop_date']=$in_stop_date;

if ($debug==1){
	echo ('<br>Posted Sales Room : '.$_POST["in_Room"]);
	echo ('<br>Posted Sales Manager : '.$_POST["in_Manager"]);
	echo ('<br>Posted Sales Rep : '.$_POST["in_SalesRep"]);
	echo ('<br>Posted enter date : '.$_POST["in_Enter_Date"]);
	echo ('<br>Session Sales Room : '.$_SESSION['$in_sales_room']);
	echo ('<br>Session Sales Manager : '.$_SESSION['$in_sales_manager']);
	echo ('<br>Session Sales Rep : '.$_SESSION['$in_sales_rep']);
	echo ('<br>Session enter date : '.$_SESSION['$in_enter_date']);
	echo ('<br>local Sales Room : '.$in_sales_room);
	echo ('<br>local Sales Manager : '.$in_sales_manager);
	echo ('<br>local Sales Rep : '.$in_sales_rep);
	echo ('<br>local enter Date : '.$in_enter_date);
	echo ('<br>');
}

/***************MAIN CODE STARTS HERE ********************/

if ($_POST["in_Room"]==''){
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

echo ('	<h2 align=center>Vault Returns Management: Sales Review </h2>');

	$return_reasons=get_ReturnReasons($DB1_Conn, $debug);
	$room=get_Room($DB1_Conn, $debug);
	$managers=get_Managers($DB1_Conn, $_SESSION['$in_sales_room'], $debug);
	$sales_reps=get_SalesRep($DB1_Conn, $_SESSION['$in_sales_room'], $_SESSION['$in_sales_manager'], $debug);

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<label>Room:<br>
		<select name="in_Room" onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>
		<option value="All Sales Rooms">All Sales Rooms</option>');

	for($i=0;$i<$_SESSION['Room_Count'];$i+=1){
		echo ('<option value="'.$room[$i].'">'.$room[$i].'</option>  ');
	}
	echo ('	</td><td>
		<label>Sales Manager:<br>
		<select name="in_Manager" onChange="submit()">
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>
		</option><option value="All Sales Managers">All Sales Managers</option>');
	for($i=0;$i<$_SESSION['Manager_Count'];$i+=1){
		echo ('<option value="'.$managers[$i].'">'.$managers[$i].'</option>  ');
	}
	echo ('	</td>');
	echo (' <td valign="top">
		<label>Sales Representative: <br>
		<select name="in_SalesRep" >
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
		</option>
		</option><option value="All Sales Reps">All Sales Reps</option>');				
	for($i=0;$i<$_SESSION['SalesRep_Count'];$i+=1){
		echo ('<option value="'.$sales_reps[$i].'">'.$sales_reps[$i].'</option>  ');
	}
	echo ('	</td>');

	echo (' <td valign="top">
		<label>Return Reason: <br>
		<select name="in_Return_Reason" >
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
		</option>
		</option><option value="All Return Reasons">All Return Reasons</option>');				
	for($i=0;$i<$_SESSION['Return_Count'];$i+=1){
		echo ('<option value="'.$return_reasons[$i].'">'.$return_reasons[$i].'</option>  ');
	}
	echo ('	</td>');


	echo (' <td align="center" valign="top">
		<label>Enter Start Date: <br>
		<input type="text" style="text-align:center" align="center" name="in_Enter_Date" value="'.$_SESSION['$in_enter_date'].'" >');
	echo ('	</td>');
	echo (' <td align="center" valign="top">
		<label>Enter Stop Date: <br>
		<input type="text" style="text-align:center" align="center" name="in_Stop_Date" value="'.$_SESSION['$in_stop_date'].'" >');
	echo ('	</td></tr>');

	echo (' <tr><td></td><td></td><td valign="top" align="right">
		<input type="submit" value="Show Me" />
		</td><td valign="top" align="left">
		<input type="submit" name="Clear" value="Clear All" />
		</td><td align="center"><i>(MM/DD/YYYY)</i>
		</td><td align="center"><i>(MM/DD/YYYY)</i></td>
		</tr></form></table><br><br>');

} // end if ($in_sales_manager==='')
else {
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('<h2 align=center>Vault Returns Management: Sales Review</h2>');

	$return_reasons=get_ReturnReasons($DB1_Conn, $debug);
	$room=get_Room($DB1_Conn, $debug);
	$managers=get_Managers($DB1_Conn, $_SESSION['$in_sales_room'], $debug);
	$sales_reps=get_SalesRep($DB1_Conn, $_SESSION['$in_sales_room'], $_SESSION['$in_sales_manager'], $debug);

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<label>Room:<br>
		<select name="in_Room" onChange="submit()">
		<option>'.$_SESSION['$in_sales_room'].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>
		<option value="All Sales Rooms">All Sales Rooms</option>');
	for($i=0;$i<$_SESSION['Room_Count'];$i+=1){
		echo ('<option value="'.$room[$i].'">'.$room[$i].'</option>  ');
	}
	echo ('	</td><td>
		<label>Sales Manager:<br>
		<select name="in_Manager" onChange="submit()">
		<option>'.$_SESSION['$in_sales_manager'].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>
		<option value="All Sales Managers">All Sales Managers</option>');
	for($i=0;$i<$_SESSION['Manager_Count'];$i+=1){
		echo ('<option value="'.$managers[$i].'">'.$managers[$i].'</option>  ');
	}
	echo ('	</td>');

	echo (' <td valign="top">
		<label>Sales Representative: <br>
		<select name="in_SalesRep" onChange="submit()">
		<option>'.$_SESSION['$in_sales_rep'].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		</option>
		<option value="All Sales Reps">All Sales Reps</option>');
		
	for($i=0;$i<$_SESSION['SalesRep_Count'];$i+=1){
		echo ('<option value="'.$sales_reps[$i].'">'.$sales_reps[$i].'</option>  ');
	}

	echo (' <td valign="top">
		<label>Return Reason: <br>
		<select name="in_Return_Reason" >
		<option>'.$_SESSION['$in_return_reason'].'</option>
		<option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
		</option>
		</option><option value="All Return Reasons">All Return Reasons</option>');				
	for($i=0;$i<$_SESSION['Return_Count'];$i+=1){
		echo ('<option value="'.$return_reasons[$i].'">'.$return_reasons[$i].'</option>  ');
	}
	echo ('	</td>');

	echo ('	</td>');
	echo (' <td align="center" valign="top">
		<label>Enter Start Date: <br>
		<input type="text" style="text-align:center" 
		align="center" name="in_Enter_Date" value="'.$_SESSION['$in_enter_date'].'" >');
	echo (' <td align="center" valign="top">
		<label>Enter Stop Date: <br>
		<input type="text" style="text-align:center" 
		align="center" name="in_Stop_Date" value="'.$_SESSION['$in_stop_date'].'" >');
	echo ('	</td></tr>');
	echo (' <tr><td></td><td></td><td valign="top" align="right">
		<input type="submit" value="Show Me" />
		</td><td valign="top" align="left">
		<input type="submit" name="Clear" value="Clear All" />
		</td><td valign="top" align="center"><i>( MM/DD/YYYY )</i>
		</td><td align="center"><i>(MM/DD/YYYY)</i></td>
		</tr></form></table><br>');

	if ($_POST["in_Enter_Date"]<>''){
	
		if(isDate($_POST["in_Enter_Date"])){
			if(isDate($_POST["in_Stop_Date"])){
			
				if($debug==1){
					echo ('<br>Valid Date<br><br>');
				}

				$good_money=get_History($DB1_Conn, $_POST['in_Room'], $_POST['in_Manager'], 
					$_POST['in_SalesRep'], $_POST["in_Return_Reason"], $_POST["in_Enter_Date"], $_POST["in_Stop_Date"], $debug);

				$reason_summary=get_Summary($DB1_Conn, $_POST['in_Room'], $_POST['in_Manager'], 
					$_POST['in_SalesRep'], $_POST["in_Return_Reason"], $_POST["in_Enter_Date"], $_POST["in_Stop_Date"], $debug);

				$_SESSION['Returns_Detail']=$good_money;
		
				echo ('	<h3 align="center">
					'.$_SESSION['SalesRep_Order_Count'].' Orders Returned, 
					'.$_SESSION['SalesRep_Count'].' Sales Reps,
					'.$_SESSION['SalesRep_Customers'].' Customers, $
					'.number_format($_SESSION['SalesRep_Order_Total'], 2).' Total Value.
					</h3>');

				echo ('<table align ="center">');

				// Grid Header
				echo ('<tr><td align="center"><i>Reason</i></td><td align="center" ><i>Count</i></td><td align="center"><i>Value</i></td></tr>');

				// Grid Detail
				for($i=0;$i<$_SESSION['Return_Reasons_Count'];$i+=1){
					echo ('<tr><td>'.$reason_summary[0][$i].'</td>
						<td>'.$reason_summary[1][$i].'</td>
						<td align="right">$ '.number_format($reason_summary[2][$i], 2).'</td></tr>'
					);
				}

				echo ('</table>');
				
				// Grid Header
				echo (' <table class="sortable" align="center">');
				echo (' <tr>
					<td align="center" bgcolor="'.$hdr_bgcolor.'">
					<b>Date</b></td>');
				echo (' <td align="center" bgcolor="'.$hdr_bgcolor.'">
					<b>Sales Rep</b></td>');
				echo (' <td align="center" bgcolor="'.$hdr_bgcolor.'">
					<b>Customer Name</b></td>');
				echo (' <td align="center" bgcolor="'.$hdr_bgcolor.'">
					<b>Return Reason</b></td>');
				echo (' <td align="center" bgcolor="'.$hdr_bgcolor.'">
					<b>Order ID</b></td>');
				echo (' <td align="center" bgcolor="'.$hdr_bgcolor.'">
					<b>Value</b></td></tr>');

				// Grid Detail
				show_History($good_money, $debug);
				echo ('</table>');
			} 
			else {
				echo ('<h3 align="center">INVALID STOP DATE ENTERED. Please re-enter a valid date.</h3><br>');
			}// end else: if(isDate($_POST["in_Stop_Date"])){
		}
		else {
			echo ('<h3 align="center">INVALID START DATE ENTERED. Please re-enter a valid date.</h3><br>');
		}  // end else:	if ($_POST["in_Enter_Date"]<>'')
	
	} // end if ($_POST["in_Enter_Date"]<>'')

} //end else: if ($in_sales_manager==='')


	If ($debug==1) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB1_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB1_UserName.'</b><br>');
			echo ('Database: <b>'.$DB1_Database.'</b><br>');
			echo ('Manager is: <b>'.$managers.'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>
