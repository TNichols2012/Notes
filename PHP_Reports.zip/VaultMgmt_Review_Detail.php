<?php
session_start();
$debug=0;
/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}
/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require_once ('DB_Login.php');

$DB3_Conn = mssql_connect($DB3_Host, $DB3_UserName, $DB3_Password); 

mssql_select_db ( $DB3_Database, $DB3_Conn );

$orig_returns_detail	=$_SESSION['Returns_Detail'];

$orig_returns_index	= $orig_returns_detail[0][$_GET['$Index_ID']]; // Primary Key
$orig_datetime		= $orig_returns_detail[1][$_GET['$Index_ID']]; // DateTime
$orig_user_name		= $orig_returns_detail[2][$_GET['$Index_ID']]; // Username
$orig_customer_name	= $orig_returns_detail[3][$_GET['$Index_ID']]; // Customer Name
$orig_customer_ID	= $orig_returns_detail[4][$_GET['$Index_ID']]; // Customer Number
$_SESSION['User_ID']	= $orig_returns_detail[4][$_GET['$Index_ID']]; // Customer Number
$orig_order_ID		= $orig_returns_detail[5][$_GET['$Index_ID']]; // Order Number
$orig_dollar_amount	= $orig_returns_detail[6][$_GET['$Index_ID']]; // Dollar Amount
$orig_issue		= $orig_returns_detail[7][$_GET['$Index_ID']]; // Issue
$orig_issue		= str_replace ( "\n", '<br>',$orig_issue);
$orig_manager_notes	= $orig_returns_detail[8][$_GET['$Index_ID']]; // Manager Notes
$orig_manager_notes	= str_replace ( "\n", '<br>',$orig_manager_notes);
$orig_returns		='';

$_SESSION['Index_ID']=$_GET['$Index_ID'];

$sp1 = mssql_init ( '[USRC_Main].dbo.usp_GetLoadBookNotes', $DB3_Conn ); 
$sp1_custnum=$orig_customer_ID;

mssql_bind ($sp1, '@custnum', $sp1_custnum, SQLVARCHAR, false, false, 10);

$result1 = mssql_execute ( $sp1 ); 
$loadbook_notes=mssql_result($result1, 0, 0);
$loadbook_notes = str_replace ( "\n", '<br>',$loadbook_notes);


If ($debug==1) {	
	if (! $DB3_Conn) {
		die ("Debug Mode: ON <br>
			Could not connect to AMCAT USRC Main Database. <br/>
			Please contact IT Administrator for assistance. <br/>");
	}
	else {echo "Debug Mode: ON <br> Successfully connected to AMCAT USRC Main database. <br />";}

	echo ('<br>GET asset tag looks like: '.$_GET['$orig_asset_tag']);	
	echo ('<br>Original asset list looks like: '.$orig_asset_list);	
	echo ('<br>Original asset tag looks like: '.$orig_asset_tag);
	echo ('<br>Original Comments look like: '.$orig_comments);
	echo ('<br>Original Loadbook Notes look like: '.$loadbook_notes);

	
	echo ('<br>**************************************************************************************');

};
	

?>

<html>
<title>USRCBR IT Inventory Submission</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);

if ($_POST['Update']){
$orig_inventory='Confirm';
}
$inve_asset_tag=$orig_asset_tag;
$inve_hardware_type=htmlentities($_POST["in_Hardware_Type"]);
$inve_serial_number=htmlentities($_POST["in_Serial_Number"]);
$inve_purchase_date=htmlentities($_POST["in_Purchase_Date"]);
$inve_status=htmlentities($_POST["in_Status"]);
$inve_manufacturer=htmlentities($_POST["in_Manufacturer"]);
$inve_model_number=htmlentities($_POST["in_Model_Number"]);
$inve_warranty=htmlentities($_POST["in_Warranty"]);
$inve_location=htmlentities($_POST["in_Location"]);
$inve_assigned_to=htmlentities($_POST["in_Assigned_To"]);
$inve_mac_address=htmlentities($_POST["in_MAC_Address"]);
$inve_ip_address=htmlentities($_POST["in_IP_Address"]);
$inve_comments=htmlentities($_POST["in_Comments"]);

if ($_POST['Confirm']){
Submit_Update_Record($DB1_Conn, $inve_asset_tag, $inve_hardware_type, $inve_serial_number, $inve_purchase_date, $inve_status, $inve_manufacturer, $inve_model_number, $inve_warranty, $inve_location, $inve_assigned_to, $inve_mac_address, $inve_ip_address, $inve_comments, $debug);
$orig_inventory='Close';
}

if($orig_inventory == 'Close')
{
?>
<script language=JavaScript>
window.close();
</script>
<?php
}


if($orig_returns==''){
echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>
	<h2 align=center>Vault Returns Detail</h2>
	<table align="center">
	<button  onclick="window.close()">Close</button>
	</table>
	<br>Sales Return for: <b>'.$orig_user_name.'<br><br>
	<table align=center>
	<form action="'.$php_page.'?$orig_returns_index='.$orig_returns_index.'" method="POST">
	<tr>
	<td style="width=150px" align=left>
	<label>Return Date:<br>
	<b>'.$orig_datetime.'</b></label>
	</td>
	<td style="width=150px" align=left>
	<label>Customer Name:<br>
	<b>'.$orig_customer_name.'</b></label>
	</td>
	<td style="width=150px" align=left>
	<label>Return Value:<br>
	<b>$ '.number_format($orig_dollar_amount, 2).'</b></label>
	</td></tr>
	<tr><td colspan=4>
	<label><br>MOM Order ID(s):<br>
       	<b>'.$orig_order_ID.'</b></label>
	</td></tr>
	
	<tr align="center"><td colspan=4>
	<label><br><u>Return Notes</u> (<i>if any</i>):</label></td></tr>

	<tr><td colspan=4>
	<label>'.$orig_issue.'</label>
	</td></tr>
	
		
	</form>
	</table>');
	echo "<br>";
} // end if($inve_asset_tag==='')


	If ($debug==2) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "Debug Mode: ON <br>Still Connected Fine. <br />";}


		echo "Hardware Type: '<b>".$inve_hardware_type."</b>'<br>";
		echo "Asset tag #: '<b>".$inve_asset_tag."</b>'<br>";
		echo "Serial Number: '<b>".$inve_serial_number."</b>'<br>";
		echo "Purchase Date: '<b>".$inve_purchase_date."</b>'<br>";
		echo "Status: '<b>".$inve_status."</b>'<br>";
		echo "Manufacturer: '<b>".$inve_manufacturer."</b>'<br>";
		echo "Model #: '<b>".$inve_model."</b>'<br>";
		echo "Warranty: '<b>".$inve_warranty."</b>'<br>";
		echo "Location: '<b>".$inve_location."</b>'<br>";
		echo "Assigned To: '<b>".$inve_assigned_to."</b>'<br>";
		echo "MAC Address (<i>if any</i>): '<b>".$inve_mac_address."</b>'<br>";
		echo "IP Address (<i>if any</i>): '<b>".$inve_ip_address."</b>'<br>";
		echo "Comments: '<b>".$inve_comments."</b>'  ";
	};




?>

</html>
