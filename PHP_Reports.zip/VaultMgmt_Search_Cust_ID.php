<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $login=='sdk' || $login=='SDK' || $login=='MJM' || $login=='mjm')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB20_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";

if ($debug==1){
	if (! $DB1_Conn) {
		DIE ("Could not connect to AmcatSQL Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to AmcatSQL Database. <br />";
	}
}

function get_Notes($DB1_Conn, $keyword, $debug) {

	$query="SELECT
		tMC.Cust_ID,
		ISNULL(tLN.Notes1, 'No Loadbook Notes Found.') AS Notes,
		tMC.First_Name + ' ' + tMC.Last_Name AS FullName
		FROM tbl_MOM_Cust tMC
		LEFT JOIN tbl_Loadbook_Notes tLN
		ON tMC.Cust_ID=tLN.Cust_ID
		WHERE tMC.Cust_ID = '".$keyword."'
		";

	$result=mssql_query($query, $DB1_Conn);
	$numrows=mssql_num_rows($result);
	$_SESSION['List_Count']=$numrows;

	for($i=0;$i<$numrows;$i+=1){
		$answer[$i][0]=mssql_result($result, $i, 0);//custnum
		$answer[$i][1]=mssql_result($result, $i, 1);//notes
		$answer[$i][2]=mssql_result($result, $i, 2);//fullname
	}

	if ($numrows == 0) {
		$answer[$i][0]='0';
		$answer[$i][1]='No Loadbook Notes Found.';
		$answer[$i][2]='No Customer Record Found.';
	}
 
	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to AmcatSQL USRC_Main Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to AmcatSQL USRC_Main Database. <br />";
		}
		echo ('<br>Loadbook Search Query Looks Like:<br> '.$query);
	}
	Return $answer;
};


?>

<html>

<head>

</head>
<title>USRCBR Vault Management Loadbook Editor</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);

if($_POST['Clear']){
	$_POST["in_LB_Search"]='';
}

if ($debug==1){
	echo ('<br>local enter Date : '.$in_enter_date);
}

/***************MAIN CODE STARTS HERE ********************/


if ($_POST["in_LB_Search"]==''){
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($login=='SDK' || $login=='sdk' || $login=='MJM' || $login=='mjm'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}


	echo ('	<h2 align=center>Business Support Services: Loadbook Notes Editor</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>Customer ID Search: <br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></tr></form></table><br><br>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<textarea name="in_Loadbook_Notes" cols=80 rows=20 align=center></textarea>
		</td></tr>
		<tr align="center"><td colspan=4>
		<input type="submit" name="Update" value="Update" />');
	echo ('	</td></tr></tr></form></table><br><br>');

} // end if ($_POST["in_LB_Search"]=='')
else {
	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($login=='SDK' || $login=='sdk'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="BSS_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}


	echo ('	<h2 align=center>Business Support Services: Loadbook Notes Editor</h2>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<td align="center" valign="top">
		<label>Customer ID Search: <br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center" value="'.$_POST["in_LB_Search"].'"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></tr></form></table><br><br>');

	$list=get_Notes($DB1_Conn, $_POST["in_LB_Search"], $debug);
	$_SESSION['List']=$list;
	$_SESSION['Search_ID']=$_POST["in_LB_Search"];


	echo (' <table align="center">
		<tr align="center"><td colspan=4 align="center"><b>'.$list[0][2].'</b></td></tr>
		<tr><td valign="top">
		<form action="VaultMgmt_Search_Cust_ID_Update.php" method="POST">
		<td align="center" valign="top">
		<textarea name="in_Loadbook_Notes" cols=80 rows=20 align=center>'.$list[0][1].'</textarea>
		</td></tr>
		<tr align="center"><td colspan=4>
		<input type="submit" name="Update" value="Update" />');
	echo ('	</td></tr></tr></form></table><br><br>');



} //end else: if ($_POST["in_LB_Search"]=='')

	If ($debug==1) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB3_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB3_UserName.'</b><br>');
			echo ('Database: <b>'.$DB3_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>



