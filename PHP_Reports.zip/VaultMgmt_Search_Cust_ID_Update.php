<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator' || $login=='sdk' || $login=='SDK')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB20_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";

if ($debug==1){
	if (! $DB1_Conn) {
		DIE ("Could not connect to AmcatSQL Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to AmcatSQL Database. <br />";
	}
}
	if ($debug==1){
		if (! $DB1_Conn) {
			DIE ("Could not connect to AmcatSQL USRC_Main Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to AmcatSQL USRC_Main Database. <br />";
		}
		echo ('<br>Loadbook Search Query Looks Like:<br> '.$query);
	}

	$loadbook_notes_update = htmlentities($_POST["in_Loadbook_Notes"]);
	$sp2 = mssql_init ( '[USRCSQLCLS1].Data_Warehouse.dbo.usp_Loadbook_Request_Notes_Update', $DB1_Conn ); 
	$sp2_custnum=$_SESSION['List'][0][0];
	$sp2_notes=$loadbook_notes_update;
	mssql_bind ($sp2, '@in_Cust_ID', $sp2_custnum, SQLVARCHAR, false, false, 10);
	mssql_bind ($sp2, '@in_Notes', $sp2_notes, SQLTEXT, false, false, -1);
	$result2 = mssql_execute ( $sp2 );

/***************MAIN CODE STARTS HERE ********************/
	echo ('
		<html>
		<head>
		</head>
		<title>USRCBR Vault Management Loadbook Editor</title>');

	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Vault Returns Manager'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="VaultMgmt_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Vault Returns Management: Loadbook Search Tool</h2>');



	echo (' <table align="center"><tr><td valign="top">
		<form action="VaultMgmt_Search_Cust_ID.php" method="POST">
		<td align="center" valign="top">
		<label>Customer ID Search: <br>
		<input type="text" style="text-align:center" name="in_LB_Search" align="center" value="'.$_SESSION['Search_ID'].'"><br/>
		<input type="submit" name="Search" value="Search" />');
	echo ('	</td></tr></tr></form></table><br><br>');

	echo (' <table align="center"><tr><td valign="top">
		<form action="'.$php_page.'" onSubmit="'.$php_page.'" onReset="'.$php_page.'" method="POST">
		<tr align="center"><td colspan=4 align="center"><b>'.$_SESSION['List'][0][2].'</b></td></tr>
		<td align="center" valign="top">
		<textarea name="in_Loadbook_Notes" cols=80 rows=20 align=center>'.$loadbook_notes_update.'</textarea>
		</td></tr>
		<tr align="center"><td colspan=4>
		<input type="submit" name="Update" value="Update" />');
	echo ('	</td></tr></tr></form></table><br><br>');

	echo (' </html>');

?>

