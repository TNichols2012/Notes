<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

IF ($securitygroup=='Vault Returns Manager' || $securitygroup=='Developer' || $securitygroup=='Administrator')
//IF ($securitygroup=='Administration')
//IF ($securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB3_Conn = mssql_connect ( $DB20_Host, $DB20_UserName, $DB20_Password, TRUE ); //connect to USRCSQLCLS1
mssql_select_db ( $DB20_Database, $DB3_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
$hdr_bgcolor="Yellow";
$php_page=htmlentities($_SERVER['PHP_SELF']);

	if ($debug==1){
		if (! $DB3_Conn) {
			DIE ("Could not connect to AmcatSQL USRC_Main Database. 
				<br/>Please contact IT Administrator for assistance. <br/>");
		}
		else {
			echo "Connected Fine to AmcatSQL USRC_Main Database. <br />";
		}
		echo ('<br>Loadbook Search Query Looks Like:<br> '.$query);
	}

/////////////////////////////////////////////////////////////////////
// Begin Session LIST Transfer Data Load
/////////////////////////////////////////////////////////////////////

$orig_detail	=$_SESSION['Notes_List'];

$orig_cust_id		= $orig_detail[0][$_GET['$orig_index']]; // Customer Number
$orig_notes		= $orig_detail[1][$_GET['$orig_index']]; // Issue
//$orig_notes		= str_replace ( "\n", '<br>',$orig_notes);
$orig_cust_name		= $orig_detail[2][$_GET['$orig_index']]; // Name
$orig_index		=$_GET['$orig_index'];

/////////////////////////////////////////////////////////////////////
// End Session List Transfer
/////////////////////////////////////////////////////////////////////

/*

	$sp2 = mssql_init ( '[USRC_Main].dbo.usp_UpdateLoadBookNotes', $DB3_Conn ); 
	$sp2_custnum=$orig_cust_id;
	$sp2_notes=$_SESSION['in_Loadbook_Notes'];
	mssql_bind ($sp2, '@custnum', $sp2_custnum, SQLVARCHAR, false, false, 10);
	mssql_bind ($sp2, '@notes', $sp2_notes, SQLTEXT, false, false, -1);
	$result2 = mssql_execute ( $sp2 );
*/


/***************MAIN CODE STARTS HERE ********************/
if ($_POST["in_Loadbook_Notes"]=='')
	{
	echo ('	<html>
		<head>
		</head>
		<title>USRCBR Vault Management Loadbook Editor</title>');

	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');
	echo ('	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>');
	echo ('	<h2 align=center>Vault Returns Management: Loadbook Search Tool</h2>');

	echo (' <table align="center" valign="top">
		<form action="VaultMgmt_Search_Loadbook_Update.php?$orig_index='.$orig_index.'" method="POST">
		<tr align="center"><td colspan=4 align="center"><b>'.$orig_cust_name.'</b></td></tr>
		<tr><td align="center" valign="top">
		<textarea name="in_Loadbook_Notes" cols=80 rows=20 align=center>'.$orig_notes.'</textarea>
		</td></tr>
		<tr align="center"><td colspan=4>
		<input type="submit" name="Update" value="Update" />');
	echo ('	</td></tr></form></table><br><br>');

	echo (' </html>');
	}
else 
		{
	echo ('	<html>
		<head>
		</head>
		<title>USRCBR Vault Management Loadbook Editor</title>');

	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');
	echo ('	<h3 align=center><button align=center onclick="window.close()">Close</button></h3>');
	echo ('	<h2 align=center>Vault Returns Management: Loadbook Search Tool</h2>');

	echo (' <table align="center" valign="top">
		<form action="VaultMgmt_Search_Loadbook_Update.php?$orig_index='.$orig_index.'" method="POST">
		<tr align="center"><td colspan=4 align="center"><b>'.$orig_cust_name.'</b></td></tr>
		<tr><td align="center" valign="top">
		<textarea name="in_Loadbook_Notes" cols=80 rows=20 align=center>'.$_POST["in_Loadbook_Notes"].'</textarea>
		</td></tr>
		<tr align="center"><td colspan=4>
		<input type="submit" name="Update" value="Update" />');
	echo ('	</td></tr></form></table><br><br>');

	echo (' </html>');

	$loadbook_notes_update = htmlentities($_POST["in_Loadbook_Notes"]);
	$sp2 = mssql_init ( '[USRCSQLCLS1].Data_Warehouse.dbo.usp_Loadbook_Request_Notes_Update', $DB3_Conn ); 
	$sp2_custnum=$orig_cust_id;
	$sp2_notes=$loadbook_notes_update;
	mssql_bind ($sp2, '@in_Cust_ID', $sp2_custnum, SQLVARCHAR, false, false, 10);
	mssql_bind ($sp2, '@in_Notes', $sp2_notes, SQLTEXT, false, false, -1);
	$result2 = mssql_execute ( $sp2 );
	
	if ($debug==1)
	{
		echo ('<br>Debug Mode ON:');
		echo ('<br>sp2_custnum: '.$sp2_custnum);
		echo ('<br>sp2_notes: '.$sp2_notes);
		echo ('<br>$result2: '.$result2);		
		echo ('<br>sp2: '.$sp2);
	}


	}
?>

