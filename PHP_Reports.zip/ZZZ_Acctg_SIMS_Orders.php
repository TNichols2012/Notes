<?php
session_start();
$debug=0;

/////////////////////////////////////////////////////////////////////
// BEGIN Test for Permissions
/////////////////////////////////////////////////////////////////////


$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];
$site=$_SESSION['Security_Site'];

IF ($securitygroup=='Executive' || $securitygroup=='Developer' || $securitygroup=='Administrator')
{}
ELSE 
{
		header('Location: ./Login_Invalid.php');
}


/////////////////////////////////////////////////////////////////////
// END Test for Permissions
/////////////////////////////////////////////////////////////////////

require ('DB_Login.php');
require ('PHP_Functions.php');

$DB1_Conn = mssql_connect ( $DB1_Host, $DB1_UserName, $DB1_Password, TRUE ); //connect to USRCREP02
mssql_select_db ( $DB1_Database, $DB1_Conn );

define("LightGreen", "99FF66");
define("LightGrey", "#C1C1C1");
define("Black", "000000");
define("Yellow", "FFFF00");
define("White", "FFFFFF");
define("Red", "FF3300");
$hdr_bgcolor=Yellow;

if ($debug==1){
	if (! $DB1_Conn) {
		DIE ("Could not connect to USRC_SIMSserver Database. 
			<br/>Please contact IT Administrator for assistance. <br/>");
	}
	else {
		echo "Connected Fine to USRC_SIMSserver Database. <br />";
	}
}


function get_SIMS_Orders($DB1_Conn, $login, $days_back, $debug){

	$sp1 = mssql_init ( '[SIMS].dbo.usp_SIMS_Orders', $DB1_Conn ); 

	$result1 = mssql_execute ( $sp1 );

	$numrows=mssql_num_rows($result1);
	$_SESSION['List_Count']=$numrows;


	for($i=0;$i<$numrows;$i+=1){
		$answer[0][$i]=mssql_result($result1, $i, 0);//Order_Date
		$answer[1][$i]=mssql_result($result1, $i, 1);//Order_ID
		$answer[2][$i]=mssql_result($result1, $i, 2);//Domestic
		$answer[3][$i]=mssql_result($result1, $i, 3);//Foreign

	}
	Return $answer;

	If ($debug==1) {
		IF (! $DB1_Conn) {
			DIE ("Debug Mode within Get_List function: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {echo "<br>Debug Mode: ON <br>Still Connected Fine while inside Get List Function. <br />";}

		echo "Rows Returned: '<b>".$numrows."</b>'<br>";
		echo "Days back: '<b>".$days_back."</b>'<br>";

	}
}

function format_tbl_header($label, $width, $alignment="center"){
	echo ('<td align="'.$alignment.'" bgcolor="'.$hdr_bgcolor);
//	global $tbl_bgcolor;
//	echo $tbl_bgcolor.'"';
	if ($width !=-1){
		echo (' width="'.$width.'"><b>'.$label.'</b></td>');
	}
	else {
		echo ('><b>'.$label.'</b></td>');
	}
}

function format_tbl_content($content, $width, $alignment="left", $row_bgcolor){

	echo ('<td align="'.$alignment.'" bgcolor="');
		
	echo $row_bgcolor.'"';

	if ($width !=-1){
		echo (' width="'.$width.'">'.$content.'</td>');
	}
	else {
		echo ('>'.$content.'</td>');
	}
}


?>

<html>

<head>
<script type="text/javascript">
	function show_detail(Index_ID){
	<!--
	str_redirect1='./Survey_Add.php?$orig_index='+Index_ID
	window.open (str_redirect1, 'Asset_Window_'+Index_ID, config='height=800, width=800, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}





</script>

<script src="JS_Sort_Table.js"></script>

</head>
<title>USRCBR Sales Rep UPS Tracking Info</title>

<?php

$php_page=htmlentities($_SERVER['PHP_SELF']);


	echo ('	<h1 align=center>United States Rare Coin and Bullion Reserve</h1>');

	if($securitygroup=='Executive'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Executive_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Administrator'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Administrator_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}

	echo ('	<h2 align=center>Executive Tools: SIMS Order Info</h2>');


	echo ('<table align="center" class="sortable"><tr>');
	format_tbl_header("Index", 50, center);
	format_tbl_header("Order Date", 200, center);
	format_tbl_header("Order ID", 100, center);
	format_tbl_header("US Retail", 125, center);
	format_tbl_header("UK Retail", 125, center);

	echo ('</tr><tr>');

	$SIMS_Order_List= get_SIMS_Orders($DB1_Conn, $login, '', $debug);

	for ($i=0; $i<$_SESSION['List_Count']; $i+=1){
		//Alternating Row Colors
		if ($i%2){
			$row_bgcolor=LightGreen;
		}
		else {
			$row_bgcolor=LightGrey;
		}
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index	
	format_tbl_content($SIMS_Order_List[0][$i], 200, center, $row_bgcolor);//Order_Date
	format_tbl_content($SIMS_Order_List[1][$i], 100, center, $row_bgcolor);//Order_ID
	echo ('<td width=125 align="right" bgcolor='.$row_bgcolor.'>$ '.number_format($SIMS_Order_List[2][$i], 2).'</td>');//Domestic Retail
	echo ('<td width=125 align="right" bgcolor='.$row_bgcolor.'>� '.number_format($SIMS_Order_List[3][$i], 2).'</td>');//Foreign Retail





	echo ('</tr>');

	}	
	echo ('</table>');	
/*
//	echo ('<tr onClick="show_asset('.($i).')">');
//	echo ('<tr onClick="show_detail('.($asset_list[0][$i]).')">');
echo ('<tr>');
	format_tbl_content($i+1, 50, center, $row_bgcolor);			//Index

	format_tbl_content($UPS_Tracking_List[2][$i], 125, center, $row_bgcolor);//Status


	echo ('</tr>');
	}
 


 */





	If ($debug==1) {
		IF (! $DB_Conn) {
			DIE ("Debug Mode: ON <br>
				Could not connect to Database. <br/>
				Please contact IT Administrator for assistance. <br/>");
		}
		ELSE {
			echo ('Debug Mode: ON <br>Still Connected Fine. <br />');
			echo ('DB Host Server: <b>'.$DB2_Host.'</b><br>');
			echo ('DB User Name: <b>'.$DB2_UserName.'</b><br>');
			echo ('Database: <b>'.$DB2_Database.'</b><br>');
//			echo ('List: <b>'.print_r($list).'</b><br>');
			echo ('Good Money is: <b>'.$good_money.'</b><br>');
			echo ('Query is: <b>'.$query.'</b><br>');
		};
	}


?>

</html>



