<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Developer')
//IF ($securitygroup=='Sales')
IF ($securitygroup=='BSS' || $securitygroup=='Developer' || $securitygroup=='Administrator')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Business Support Services Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');
	if($securitygroup=='Developer'){
		echo ('<table align="center"><tr><td align="center" valign="top">
		<form action="_Developer_.php" method="POST">
		<input type="submit" name="Back" value="Back to Menu" />
		</td></tr></form></table>');
	}


	echo ('<center>WELCOME to the Business Support Services (BSS) Toolsite.</center><br/>');
	echo ('<table align="center">');

	echo ('<tr><th COLSPAN=2>Available Options</th></tr>');

	echo ('<tr><td>1.</td><td><a href="./_BSS_Team_Roster_Active.php">Team Roster Manager</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td>3.</td><td><a href="./BSS_Call_History_DNIS.php">Call History: 800 Number</td></tr>');
	echo ('<tr><td>4.</td><td><a href="./BSS_Call_History_Campaign.php">Ad Code History: 800 Number</td></tr>');
	echo ('<tr><td>5.</td><td><a href="./BSS_Search_Order_ID_Approval_Codes.php">Order Approval Codes</td></tr>');
	echo ('<tr><td>6.</td><td><a href="./BSS_Verification_List.php">Verification Follow-Up List</td></tr>');
	echo ('<tr><td>7.</td><td><a href="./BSS_Spiff_Report.php">Spiff Report Request</td></tr>');	

	IF($login=='KLD' || $login=='TQN') {
	echo ('<tr><td>8.</td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales ID</td></tr>');
	}

	IF($login=='SDK' || $login=='TQN' || $login=='MJM') {
			echo ('<tr><td>8.</td><td><a href="./BSS_Search_Loadbook_Sales_ID.php">Loadbook Lookup</td></tr>');
			echo ('<tr><td>9.</td><td><a href="./VaultMgmt_Search_Cust_ID.php">Loadbook Editor using Customer IDs</td></tr>');
		}
	ELSE {}
	IF($login=='MS' || $login=='TQN' || $login=='ms' || $login=='tqn' || $login=='PLV' || $login=='plv' || $login=='RDL' || $login=='rdl' || $login=='HCE' || $login=='hce' )
		{
		echo ('<tr><td>9.</td><td><a href="./BSS_Inventory_Status_Request.php">Inventory Status Request</td></tr>');
		}
	ELSE {}


	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
