<?php
session_start();
$login=$_SESSION['User_ID'];
$securitylevel=$_SESSION['Security_Level'];
$securitygroup=$_SESSION['Security_Group'];

//IF ($securitygroup=='Developer')
//IF ($securitygroup=='Sales')
IF ($securitygroup=='Developer')
	{
	echo ('<html>');
	echo ('<head>');
	echo ('</head>');
	echo ('<title>USRCBR Developer Menu</title>');
	echo ('<h1><center>United States Rare Coin and Bullion Reserve</center></h1><br/>');
	echo ('<center><img src="./images/2006_$50_Buffalo_Proof.JPG"></center><br/>');
	echo ('<center>WELCOME to the Developer Toolsite. The currently options available are: </center><br/>');
	echo ('<table align="center">');

	echo ('<tr><th COLSPAN=2>Master Menu</th></tr>');
//	echo ('<tr><td>1.</td><td><a href="./Acctg_.php">Accounting</td></tr>');
	echo ('<tr><td>1.</td><td><a href="./BSS_.php">Business Support Services (BSS)</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./Executive_.php">Executive</td></tr>');
	echo ('<tr><td>3.</td><td><a href="./Marketing_.php">Marketing</td></tr>');
	echo ('<tr><td>4.</td><td><a href="./SalesRep_.php">Sales Reps</td></tr>');
	echo ('<tr><td>5.</td><td><a href="./VaultMgmt_.php">Vault Management</td></tr>');
	echo ('<tr><td>6.</td><td><a href="./Inventory_.php">Inventory</td></tr>');

	echo ('<tr><th COLSPAN=2>Business Support Services</th></tr>');
	echo ('<tr><td>1.</td><td><a href="./BSS_Team_Roster_Active.php">Team Roster Manager</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td>3.</td><td><a href="./BSS_Call_History_DNIS.php">Call History: 800 Number</td></tr>');
	echo ('<tr><td>4.</td><td><a href="./BSS_Call_History_Campaign.php">Ad Code History: 800 Number</td></tr>');
	echo ('<tr><td>5.</td><td><a href="./BSS_Search_Order_ID_Approval_Codes.php">Order Approval Codes</td></tr>');
	echo ('<tr><td>6.</td><td><a href="./BSS_Verification_List.php">Verification Follow-Up List</td></tr>');
	//echo ('<tr><td>3.</td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales ID</td></tr>');
	IF($login=='SDK' || $login=='TQN')
		{
			echo ('<tr><td>7.</td><td><a href="./BSS_Search_Loadbook_Sales_ID.php">Loadbook Lookup</td></tr>');
			echo ('<tr><td>8.</td><td><a href="./VaultMgmt_Search_Cust_ID.php">Loadbook Editor using Customer IDs</td></tr>');
		}
	ELSE {}
	IF($login=='MS' || $login=='TQN' || $login=='ms' || $login=='tqn' || $login=='PLV' || $login=='plv' || $login=='RDL' || $login=='rdl' )
		{
		echo ('<tr><td>9.</td><td><a href="./BSS_Inventory_Status_Request.php">Inventory Status Request</td></tr>');
		}
	ELSE {}

/*
	echo ('<tr><td>1.</td><td><a href="./BSS_Team_Roster.php">Team Roster</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td>3.</td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales ID</td></tr>');
	echo ('<tr><td>4.</td><td><a href="./BSS_Search_Loadbook_Sales_ID.php">Loadbook Lookup</td></tr>');
	echo ('<tr><td>5.</td><td><a href="./BSS_Search_Order_ID_Approval_Codes.php">Order Approval Codes</td></tr>');
 */
	echo ('<tr><th COLSPAN=2>Executive Report Options</th></tr>');
	echo ('<tr><td>1.</td><td><a href="./Acctg_SIMS_Orders.php">SIMS Order List</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./SalesRep_UPS_Tracking_Summary.php">UPS Order Tracking (All)</td></tr>');
	echo ('<tr><td>3.</td><td><a href="./SalesRep_UPS_Tracking_Manager.php">UPS Order Tracking Manager</td></tr>');
	echo ('<tr><td>4.</td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');
	echo ('<tr><td>5.</td><td><a href="./BSS_Call_History_DNIS.php">Call History: 800 Number</td></tr>');
	echo ('<tr><td>6.</td><td><a href="./BSS_Call_History_Sales_Rep.php">Call History: Sales ID</td></tr>');

	echo ('<tr><th COLSPAN=2>Marketing Report Options</th></tr>');
	echo ('<tr><td>1.</td><td><a href="./BSS_Call_History_DNIS.php">Call History: 800 Number</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./BSS_Call_History_ContactNumber.php">Call History: Contact Number</td></tr>');

	echo ('<tr><th COLSPAN=2>Sales Report Options</th></tr>');
	echo ('<tr><td>1.</td><td><a href="./SalesRep_Gold_Report_Tracking.php">Gold Report Follow-Up</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./SalesRep_UPS_Tracking_Summary.php">UPS Order Tracking</td></tr>');

	echo ('<tr><th COLSPAN=2>Vault Management Reports</th></tr>');
	echo ('<tr><td>1.</td><td><a href="./VaultMgmt_Review.php">SIMS Sales Return Review</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./VaultMgmt_Returns.php">Issues Register</td></tr>');
	echo ('<tr><td>3.</td><td><a href="./VaultMgmt_Search_Cust_ID.php">Loadbook Editor using Customer IDs</td></tr>');
	echo ('<tr><td>4.</td><td><a href="./VaultMgmt_Search_Loadbook.php">Loadbook Editor using Wildcard Searches</td></tr>');

	echo ('<tr><th COLSPAN=2>Inventory</th></tr>');
	echo ('<tr><td>1.</td><td><a href="./Inventory_Pending_Shipment_Summary.php">Pending Shipment</td></tr>');
	echo ('<tr><td>2.</td><td><a href="./Inventory_Variance_Report.php">Variance</td></tr>');
 
	echo ('</table></html>');
}
ELSE 
{
	header('Location: ./Login_Invalid.php');
}

?>
