<?php
session_start();
$str_Path=$_GET['str_Path'];
$str_Path1="http://usrcrep01/php_reports/SalesRep_Customer_Matrix.php?Custnum=212267";
$php_page=htmlentities($_SERVER['PHP_SELF']);

?>

<html>
<title>Open Limited View</title>
<head>

<script type="text/javascript">
	function show_limited_view(str_Path){
	<!--
	str_redirect=str_Path
	window.open (str_redirect, 'Asset_Window_'+str_redirect, config='height=400, width=1200, toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, directories=no, status=no')
	-->
	}

</script>
</head>



<?php
echo ('<body onload="show_limited_view('.$str_Path1.')">');

//echo $str_Path;

echo ('</body>');
?>


</html>
