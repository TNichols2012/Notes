<html>
html works.
</html>
<?php
phpinfo();
?>
